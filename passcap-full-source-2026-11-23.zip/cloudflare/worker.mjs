import {createHandler} from '../worker/runtime.mjs';
// Direct Cloudflare deployment: static assets and catalogue are not embedded in JS.
const handler=createHandler({},null);
export default {
 async scheduled(event,env,ctx){ctx.waitUntil(handler.newsletter(env,event.scheduledTime));},
 async fetch(request,env){
  const path=new URL(request.url).pathname;
  if(path==='/sitemap.xml'||path==='/evenements'||path.startsWith('/evenements/')||path.startsWith('/api/')||path==='/data.json'||path==='/map-data.json'||path==='/carte.html'||path.startsWith('/data/departments/'))return handler.fetch(request,{...env,CATALOG_REQUIRE_TOKEN:'true'});
  const response=await env.ASSETS.fetch(request),headers=new Headers(response.headers);
  headers.set('X-Content-Type-Options','nosniff');headers.set('Referrer-Policy','strict-origin-when-cross-origin');headers.set('Cross-Origin-Opener-Policy','same-origin-allow-popups');
  return new Response(response.body,{status:response.status,statusText:response.statusText,headers});
 }
};
