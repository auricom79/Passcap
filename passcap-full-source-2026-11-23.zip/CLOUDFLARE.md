# Pass Cap — direct Cloudflare release for passcap.org

This release is deployed directly to the owner’s Cloudflare account. The existing Sites audience and publication remain unchanged. Use the owner's existing Cloudflare account and the newly purchased domain; never reuse a Sites-owned D1 database or bucket identifier in a direct Cloudflare deployment.

## Architecture

- `cloudflare/worker.mjs`: direct Cloudflare Worker entry, ordinary ES modules; no Sites runtime required.
- Static assets through the `ASSETS` binding, not a multi-megabyte JavaScript blob.
- `DB`: dedicated D1 database for Google identities, opaque sessions, profile, private disability/accessibility choices, favorites, interest and discussions.
- `BUCKET`: dedicated R2 bucket for the public event catalogue. No member data is stored in the catalogue.
- Schema migrations: apply **all** SQL files in `drizzle/` in order. Do not create schemas during requests.
- The existing Sites build (`npm run build`) remains available but is not the direct Cloudflare release artifact.

## Configure after the domain is registered

1. Activate `passcap.org` in the intended Cloudflare account. DNS and TLS must be ready.
2. Create a D1 database named `passcap-community` and R2 bucket named `passcap-catalogue` (or reuse the exact names/IDs returned for resources created specifically for this project).
3. With the exact returned D1 `database_id`, run `node scripts/prepare-cloudflare.mjs --database-id <actual-id>`. Optional `--bucket <actual-name>` and `--domain <actual-domain>` must match the chosen resources. This creates ignored local release files under `.sites-runtime/cloudflare/`; it does not deploy or create resources. No invented cloud resource IDs are accepted.
4. Apply D1 migrations using the generated Wrangler configuration. Upload `.sites-runtime/cloudflare/catalogue.json.gz` to `passcap-catalogue/pass-cap/catalog/current.json.gz` before the first release. This is the same validated public catalogue as the current site.
5. Set `GOOGLE_CLIENT_ID` on the Worker and authorize `https://passcap.org` as a JavaScript origin in the corresponding **web** Google OAuth client. Google Identity Services uses the official popup button and a JavaScript credential callback, so no application callback URI/client secret is required. Only `openid` identity is needed; no Drive, Gmail or calendar access is requested. For local Google testing, authorize the exact localhost origin separately. The interface fails closed when no client ID is configured.
6. Set a dedicated random `CATALOG_UPDATE_TOKEN` secret, at least 32 characters. All public catalogue updates require this bearer token; a regular member cannot update the catalogue. The old Sites updater keeps its current private dispatch boundary. `scripts/push-data.py` accepts hidden stdin access for either the old Site URL or `https://passcap.org` and chooses the correct header; never print or commit the token.
7. Deploy using the generated `.sites-runtime/cloudflare/wrangler.json`. `workers.dev` and preview URLs are disabled; the route on the existing proxied domain is explicit. The existing parked apex A/AAAA records remain in place as fallbacks; the Worker route intercepts HTTP traffic, so no DNS record deletion is required. No account permissions are changed by the preparation script.
8. Verify a real Google sign-in round trip on `passcap.org`. Save pseudo/avatar, reload, save a favorite, opt in/out of visible interest, post and delete a message, sign out and reconnect. Local signed-token tests do not replace this real-provider acceptance step.
9. Appoint the moderator by configuring the verified Google `sub` as `COMMUNITY_ADMIN_GOOGLE_SUB`, server-side. It is not exposed by the member APIs. Moderation is denied by default without an explicit configured subject. Before opening discussions to the public, verify the report/hide/restore flow with this moderator.

## What was reused from MyWorkshops

The security principles and Google validation logic in `feedback-service/accounts.ts` were adapted: RS256/JWKS signature validation, issuer/audience/authorized-party/expiry checks, a browser-bound one-use nonce, opaque 256-bit HttpOnly sessions with server-side hashes, origin checks on writes, bound SQL, rate limits and raster-only avatars. There is no shared account database, email-based account linking, copied credential or MyWorkshops cookie. The chosen GIS flow needs only the public client ID plus the authorized new origin.

## Member behavior and privacy

Public: pseudo/avatar with comments and **explicitly opted-in** visible interest. Favorites are private; interest is anonymous by default. Email, Google subject, session tokens and disability/accessibility profile fields are never included in event/comment/participant responses. The six disability categories are optional, multi-select, require affirmative consent, and can be cleared; the event filter is enabled by default and can be disabled with a persisted private account preference. It requires a declared true adaptation for every selected need, excludes unknown values while active, and leaves place records and saved bookmarks available. No public badge is inferred from the profile. Consent time is retained with the selections and cleared with them.

Accounts can remove their own comments, report others, block/unblock members and delete their profile plus dependent rows. Permanent account deletion requires explicit typed confirmation and a Google login within the last 15 minutes. Expired sessions and login challenges fail closed. Google access/refresh tokens are neither requested nor persisted. No fictional community members or discussions are deployed. The explicitly labelled local QA account exists only in an in-memory preview database.

TOTP/passkeys, general forums, event reviews and transport matching remain outside this first release. Administrator MFA must be addressed before expanding administration access; no claim is made that Google sign-in alone enforces an application-level second factor.

## Local verification

`npm run test:community` uses Node 22's experimental SQLite API to execute the real schema and bound SQL through a small D1 contract adapter. Tests verify signed tokens and rejection/replay, private favorites, opt-in visibility, profile validation, comment ownership/pagination, block/report/moderation, deletion, throttling and private disability data. Actual Cloudflare D1 deployment and real Google acceptance are still required.

`npm run preview:community` serves localhost:8766 with a clearly labelled isolated QA account; `/__qa/signin` is local only and **not present** in the Worker bundle or public asset directory. It contains no real member data.


## Provisioned 15 November 2026

Cloudflare account `2ebbcf0c27553bccd651f05b74bb4bed`. Domain zone `e45778cdc03aa47d580f7174e82d034c` is created on the Free plan. IONOS confirmed the nameserver change to `dawn.ns.cloudflare.com` and `rodney.ns.cloudflare.com`. Original IONOS nameservers: `ns1038.ui-dns.org`, `ns1036.ui-dns.biz`, `ns1063.ui-dns.de`, `ns1085.ui-dns.com`.

D1 `passcap-community`: `dc425eab-1362-44cf-9937-5dc8a597c182`. All three schema migrations (0000–0002) were applied remotely and recorded in `d1_migrations`; no member fixture data was inserted. R2 `passcap-catalogue` contains `pass-cap/catalog/current.json.gz`. Worker `passcap` was uploaded through the documented Cloudflare direct asset-upload API. `workers.dev` and preview URLs are disabled. Route `passcap.org/*` has ID `5660af37a23e4cf3ab543d116f7a816b`. A dedicated catalogue update secret is configured server-side and is not stored in this repository.

Google project creation hit the account’s project quota. At the owner’s explicit request, the separate existing `gojusan-7f61c` project is being repurposed for Pass Cap. The Web client “Pass Cap — Connexion Web” was created with sole JavaScript origin `https://passcap.org`; public client ID `665894763674-m0plpkdh44nkju1pf4j0r26tcastdhar.apps.googleusercontent.com` is configured on the Worker. App branding is Pass Cap; Google audience was published to production. The unused client briefly created in MyWorkshops was deleted; existing MyWorkshops clients were untouched. Cloudflare is active (activated 15 November at 09:49 UTC). HTTPS and both address families return the Pass Cap Worker; a real signed-in Google browser round trip remains to be verified.

IONOS mail MX, SPF, DMARC, autodiscover and both DKIM CNAME records were preserved in Cloudflare. Mail-related CNAME records use DNS-only mode. Public NS queries already return dawn and rodney; Cloudflare’s status is active. Some local resolvers continued caching the original IONOS address during propagation.

`python3 scripts/deploy-cloudflare.py --config <generated-wrangler.json> --account-id <actual-account-id>` provides a documented API fallback when the local Wrangler command stalls. It reads an existing credential without printing it, uploads static assets and the four ES modules, preserves existing secret bindings and disables workers.dev/previews. The script intentionally does not alter domain routing, DNS, or Google configuration.


## Email accounts and weekly newsletter

The Google JWKS fetch now uses `redirect: manual` and rejects non-2xx responses. Cloudflare Workers does not implement `redirect: error`; the former option threw before the network request and incorrectly returned `google_unavailable`. The deployed diagnostic now rejects an intentionally invalid identity with 401 instead of 503. Signature and nonce validation remain mandatory.

Migrations 0003 and 0004 were applied remotely. Email/password authentication, branded HTML transactional messages and optional weekly newsletter were deployed as Worker version `c5f68005f8624651ba9fc313f2a84e57`. Public config returns google=true and email=true. Resend domain `passcap.org`, ID `988cb99c-3c3a-48e5-b19d-57c17fd3371c`, is verified in Ireland. Its public DKIM TXT and both return-path CNAME records were added to Cloudflare in DNS-only mode. Existing IONOS mail records and `mietwacht.de` were preserved. No key from another app is reused.

Email signup requires a mailbox confirmation before a member account is created. Passwords (12–128 characters) are HMAC-preprocessed with a separate server-side pepper then derived with PBKDF2 SHA-256, random salts and 100,000 iterations (the Workers runtime limit). Confirmation/reset tokens are random 256-bit, stored hashed, expire after 30 minutes, and are consumed atomically. Reset invalidates old sessions. Google members may add a password from their recently authenticated profile, confirming in the mailbox; registration never silently links accounts merely because an email matches. Identity, session cookies and accessibility choices retain their existing privacy boundary. Expired tokens and old delivery records are cleaned by the scheduled handler.

Required secrets: `RESEND_API_KEY` (sending access restricted to passcap.org), `PASSWORD_PEPPER` (generated on first deployment, never rotate casually because existing password checks and unsubscribe signatures depend on it). Plain configuration: `ACCOUNT_EMAIL_FROM=Pass Cap <bonjour@passcap.org>`, `NEWSLETTER_ENABLED=true`, existing APP_ORIGIN and GOOGLE_CLIENT_ID. Replies go to the existing contact@xavways.com address. Tracking is disabled for the Resend domain.

Newsletter subscriptions are off by default, require an authenticated member and explicit opt-in, and store department plus an independent profile-filter choice. The strict filter requires every saved need to have a true declared adaptation; no disability labels enter the mail payload. Up to six future/ongoing events in the next seven days link directly to their detail on the site. New upcoming events rank ahead of long-running ones. Thursday 18:00 Europe/Paris is the target send time; a five-minute cron drains batches and retries until 22:59, with leases and a weekly provider idempotency key. Opt-outs are rechecked immediately before sending. Each mail includes signed unsubscribe links and List-Unsubscribe one-click headers. GET links never unsubscribe automatically. All member subscription and delivery rows cascade on account deletion.

Verification: Google/community/filter tests plus email confirmation/reset/replay/expiry/failure tests and newsletter selection/consent/idempotence/unsubscribe tests pass. Local browser QA confirms the email signup form and newsletter preference persistence. A real confirmation mail was accepted by the deployed signup endpoint and marked Delivered by Resend to contact@xavways.com. The pending test registration was removed immediately; no member account was created and its test link is inactive. Real browser confirmation/reset and Google round trips remain to be verified on a network without stale IONOS DNS caching. Preview accounts and mocked mail transport are local only.


Production Resend sending key: `f49aac66-a7be-4dbf-b9b6-ea49a8c459aa` (“Pass Cap — Envoi production”), restricted to sending from passcap.org. Installed encrypted on Cloudflare; no value is stored in source. An earlier unused key `9ffe04a6-b253-49ac-a1f2-8a049d081ca7` was created during setup but was not used for sending; the initial masked value was corrected before publication. `PASSWORD_PEPPER` is generated and preserved server-side, and the weekly cron is configured. NEWSLETTER_ENABLED=true; zero production opt-ins existed at release, and no unsolicited newsletter was sent.

## 18 novembre 2026 — référencement et invitation membres

Déploiement `6acc948aea1f4fdc9bd06b1d10de9347` sur passcap.org.

- Métadonnées d’accueil, canonical, partage Open Graph, WebSite JSON-LD et contenu descriptif visible.
- `/evenements`, pages département paginées par 50 et fiches publiques rendues côté serveur, avec canonical et Event JSON-LD. Événements expirés absents du sitemap et fiches expirées en 404. Sitemap dynamique alimenté par le catalogue R2 (7 107 URL à la vérification), déclaré dans robots.txt. Aucune donnée membre sur ces pages.
- Invitation à créer un compte sur l’accueil et bénéfices expliqués : favoris, intérêt, discussions. Masquée après connexion.
- Proposition de newsletter après 30 secondes pour les visiteurs non connectés, hors parcours de confirmation et fiche ouverte ; ne recouvre pas un autre dialogue. Fermeture accessible, affichage mémorisé pendant 30 jours dans ce navigateur. Accès manuel depuis l’accueil.
- La proposition mène à la création de compte ; l’abonnement reste une action explicite dans les préférences existantes (département et tous les événements / profil). Aucun abonnement automatique.
- Vérification : 13 tests SEO / Cloudflare / communauté / newsletter réussis, aperçu local connecté et invité, formulaire d’inscription, popup et fermeture en production, HTTP 200 sitemap et fiche publique, analyse XML du sitemap. Google reste maître du calendrier d’indexation ; aucune soumission Search Console effectuée.

## 22 novembre 2026 — newsletter sans compte

Déploiement final `e7b8d5796dcf4c42a9480dcb4c086438` sur passcap.org. Migration D1 `0005_guest_newsletter.sql` appliquée avant publication.

Le popup propose désormais seulement e-mail et département, sans compte ni mot de passe. L’activation et les changements de département nécessitent un lien de confirmation valable 24 heures, à usage unique, dont seul le hash est conservé. La consultation du lien ne modifie rien ; un bouton confirme la demande par POST. Les envois passent par les mails HTML Pass Cap et le rendez-vous du jeudi existants, sans filtre de profil pour les abonnés sans compte. Le lien « Modifier mes choix » permet une nouvelle demande avec confirmation ; le lien de désinscription signé supprime l’abonnement sans compte et son journal d’envoi. Pas de doublon avec un abonnement membre actif pour la même adresse.

Les routes publiques restent protégées par contrôle d’origine, validation et limitation des demandes. Aucun utilisateur n’est créé par ce parcours. Les jetons expirés et anciens journaux sont nettoyés par le planificateur. La notice de confidentialité est mise à jour.

Validation : 19 tests réussis (authentification, communauté, Cloudflare, SEO et newsletter, dont consentement, expiration, rejeu, désinscription, doublons et échec du prestataire). Parcours formulaire → mail simulé → confirmation vérifié dans l’aperçu local ; aucun mail de test réel envoyé. Formulaire et sélection de département vérifiés en production ; routes de validation contrôlées avec données invalides. Le serveur d’aperçu capture les mails uniquement en mémoire et n’est jamais déployé.
