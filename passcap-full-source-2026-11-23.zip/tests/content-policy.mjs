import assert from 'node:assert/strict';
import {hasDeclaredNeed,isEmploymentContent,isEligibleRecord} from '../dist/content-policy.mjs';
import {filterRecords} from '../dist/logic.mjs';
const event=(title,description='',extra={})=>({type:'event',title,description,features:{motor:{value:true}},status:1,timings:[{start:'2030-01-01T12:00:00Z',end:'2030-01-01T18:00:00Z'}],...extra});
for(const record of [
 event('Forum Emploi Handicap'),event('Forum Job étudiant'),event("Tram de l'emploi"),
 event("Promo de recherche d’emploi collective et solidaire"),
 event('ORIANE TOUR','Des entreprises proposent des offres d’emploi lors de ce job dating.'),
 event('Atelier : je booste mon CV'),event('Rencontre','Trois postes à pourvoir, venez rencontrer nos recruteurs.'),
 event('Entreprise X recrute')
])assert.equal(isEmploymentContent(record),true,record.title);
for(const record of [
 event("Atelier d’écriture ludique, avec Zazie mode d’emploi"),event("PROUVÉ : Mode d'emploi"),
 event("La Boîte — l’entreprise s’improvise",'Une pièce de théâtre à propos d’un entretien d’embauche.'),
 event('Ilona — Grave','Son CV d’échecs universitaires fait rire.'),
 event('Guignol et le Château abandonné','Les marionnettistes jouent en alternance.'),
 event('Les Semaines d’Information sur la Santé Mentale','Parlons santé et emploi.',{producer:'Oriane'}),
 event('Visite du musée',"Tarif réduit pour les demandeurs d’emploi."),
 event('Exposition Architectures du réemploi en Franche-Comté'),
 event('CVN une exposition de Yohanne Lamoulère'),
 event('Café-débat : Emploi & insertions'),event("La Nuit de l’Orientation")
])assert.equal(isEmploymentContent(record),false,record.title);
const known=event('Concert accessible'),unknown=event('Sans informations','',{features:{motor:{value:null},visual:{value:false}}});
assert.equal(hasDeclaredNeed(unknown),false);assert.equal(hasDeclaredNeed({...known,features:{motor:{value:'true'}}}),false);
assert.equal(isEligibleRecord(event('Forum emploi')),false);
const base={tab:'all',city:'',age:'',need:'',query:'',unknown:true,period:'all'};
for(const state of [base,{...base,unknown:false},{...base,age:'child'},{...base,need:'visual'}]){
 const actual=filterRecords([known,unknown,event('Forum emploi')],state,new Date('2029-12-31'));
 assert.ok(actual.every(r=>r.title==='Concert accessible'));
}
assert.equal(filterRecords([known,unknown],base,new Date('2029-12-31')).length,1);
console.log('Content policy: declared adaptations, employment exclusions and cultural counterexamples passed.');
