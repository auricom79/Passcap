import assert from 'node:assert/strict';
import fs from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {createHandler} from '../worker/runtime.mjs';
const read=path=>JSON.parse(fs.readFileSync(new URL('../dist/'+path,import.meta.url)));
const catalog=read('data.json');
const snapshot={catalog,departments:Object.fromEntries(catalog.departments.map(d=>[d.code,read(d.file)])),mapData:read('map-data.json'),mapHtml:fs.readFileSync(new URL('../dist/carte.html',import.meta.url),'utf8')};
const compressed=()=>gzipSync(JSON.stringify(snapshot));
class Bucket{
 value=null;meta=null;etag=null;writes=0;conflict=false;
 async head(){return this.value?{etag:this.etag,httpEtag:'"'+this.etag+'"',customMetadata:this.meta}:null;}
 async get(key,options){
  const head=await this.head();if(!head)return null;
  if(options?.onlyIf?.etagDoesNotMatch===this.etag)return head;
  return {...head,body:true,arrayBuffer:async()=>this.value};
 }
 async put(key,value,options){
  if(this.conflict)return null;
  if(options.onlyIf.get('If-Match')&&options.onlyIf.get('If-Match')!=='"'+this.etag+'"')return null;
  if(options.onlyIf.get('If-None-Match')==='*'&&this.value)return null;
  this.value=value;this.meta=options.customMetadata;this.etag=createHash('sha256').update(Buffer.from(value)).digest('hex');this.writes++;return this.head();
 }
}
const bucket=new Bucket(),env={BUCKET:bucket},bootstrap=compressed().toString('base64');
const handler=createHandler({},bootstrap);
const get=(path,h=handler)=>h.fetch(new Request('https://test.example'+path),env);
const post=(body=compressed(),headers={})=>handler.fetch(new Request('https://test.example/api/catalog/update',{method:'POST',headers:{'Content-Type':'application/gzip','X-Pass-Cap-Update':'1',...headers},body}),env);
assert.equal((await (await get('/api/catalog/status')).json()).persisted,false);
assert.equal((await (await get('/data.json')).json()).totalPlaces,catalog.totalPlaces);
assert.equal((await post(compressed(),{Origin:'https://test.example'})).status,403);
assert.equal((await post(Buffer.from('not gzip'))).status,422);
const first=await post();assert.equal(first.status,200);const result=await first.json();assert.ok(result.ok);assert.equal(bucket.writes,1);
assert.equal((await (await post()).json()).unchanged,true);assert.equal(bucket.writes,1);
const fresh=createHandler({},bootstrap); // Read persisted bytes with no in-memory state.
assert.deepEqual(await (await get('/data/departments/974.json',fresh)).json(),snapshot.departments['974']);
assert.equal((await (await get('/api/catalog/status',fresh)).json()).sha256,result.sha256);
const savedDate=catalog.importedAt;
catalog.importedAt=new Date(Date.parse(savedDate)-86400000).toISOString();for(const d of Object.values(snapshot.departments))d.importedAt=catalog.importedAt;
assert.equal((await post()).status,409);assert.equal(bucket.writes,1);
catalog.importedAt=savedDate;for(const d of Object.values(snapshot.departments))d.importedAt=savedDate;
const removed=snapshot.departments['79'];delete snapshot.departments['79'];assert.equal((await post()).status,422);snapshot.departments['79']=removed;
const record=snapshot.departments['79'].records[0],features=record.features;record.features={};assert.equal((await post()).status,422);record.features=features;
assert.equal(bucket.writes,1);
assert.equal((await (await get('/data.json',fresh)).json()).importedAt,savedDate);
assert.equal((await get('/data/departments/999.json')).status,404);
console.log('Updater: bootstrap, persistent readback, CSRF, corrupt/partial/ineligible/old imports, idempotence and unchanged data on failure passed.');
