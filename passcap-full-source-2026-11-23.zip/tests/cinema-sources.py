import copy,datetime,importlib.util,json,pathlib,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
def module(name,path):
 s=importlib.util.spec_from_file_location(name,ROOT/'scripts'/path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
s=module('cinema_sources','cinema-sources.py');extra=module('event_sources','event-sources.py')
NOW=datetime.datetime(2026,11,14,10,tzinfo=datetime.timezone.utc);END=NOW+datetime.timedelta(days=90)
def row():return {'_id':'proof-1','cineid':3,'filmid':'17','showid':'100','filmtitle':'Film test','filmdirector':'Réalisatrice','cinenom':'Cinéma test','cineville':'Niort','cinecp':'79000','cineadresse':'1 rue du cinéma','filmaudio':'5.1 HI VI','filmversion':'VF','showstart':'2026-11-15T14:00:00+0100','showend':'2026-11-15T16:00:00+0100','showurl':'https://cinema.example/seance/100'}
class Cinema(unittest.TestCase):
 def parse(self,rows):return s.parse_rows(rows,{'79','75','2A','2B','971','974'},NOW,END,extra,NOW.isoformat())
 def test_only_declared_session_formats(self):
  r=self.parse([row()])[0]
  self.assertTrue(r['features']['visual']['value']);self.assertTrue(r['features']['hearing']['value'])
  self.assertIn('équipement',r['features']['visual']['label'])
  for k in ['motor','autism','mental','psychic']:self.assertIsNone(r['features'][k]['value'])
  self.assertTrue(r['features']['visual']['sourceUrl'].startswith(s.BASE+'/lines?'))
  for audio in ['5.1','ST','VOSTF','VI indisponible','sans VI','None',None,'5.1 HDMI']:
   e=row();e.update(filmaudio=audio,filmstoryline='Film avec audiodescription',description='Salle accessible PMR')
   self.assertEqual(self.parse([e]),[])
 def test_open_captions_are_not_ordinary_subtitles(self):
  e=row();e['filmaudio']='ST,OCAP';r=self.parse([e])[0]
  self.assertTrue(r['features']['hearing']['value']);self.assertIsNone(r['features']['visual']['value']);self.assertIn('à l’écran',r['features']['hearing']['label'])
 def test_group_same_film_and_profile_but_not_different_access(self):
  a=row();b={**a,'_id':'proof-2','showid':'101','showstart':'2026-11-16T14:00:00+0100','showend':'2026-11-16T16:00:00+0100','showurl':'https://cinema.example/seance/101'}
  c={**b,'_id':'proof-3','showid':'102','filmaudio':'ST,OCAP'}
  rows=self.parse([a,b,c,copy.deepcopy(a)])
  self.assertEqual(len(rows),2);self.assertEqual(len(rows[0]['timings']),2)
  self.assertEqual(rows[0]['timings'][1]['sourceUrl'],b['showurl'])
  self.assertNotEqual(rows[0]['id'],rows[1]['id'])
 def test_valid_local_timestamps_and_horizon(self):
  r=self.parse([row()])[0];self.assertEqual(r['timings'][0]['start'],'2026-11-15T14:00:00+01:00')
  for a,b in [('2026-11-15T14:00:00','2026-11-15T16:00:00'),('2026-11-15T14:00:00+0100','2026-11-15T13:00:00+0100'),('2026-11-13T14:00:00+0100','2026-11-13T16:00:00+0100'),('2027-11-15T14:00:00+0100','2027-11-15T16:00:00+0100')]:
   self.assertEqual(self.parse([{**row(),'showstart':a,'showend':b}]),[])
 def test_territories_cancellations_and_safe_contacts(self):
  for postal in ['1000','97150','97133','99999']:
   self.assertEqual(self.parse([{**row(),'cinecp':postal}]),[])
  r=self.parse([{**row(),'cinecp':'97400','showurl':'javascript:alert(1)'}])[0]
  self.assertEqual(r['timezone'],'Indian/Reunion');self.assertIsNone(r['website'])
  self.assertEqual(self.parse([{**row(),'evenement':'Séance annulée'}]),[])
  corsica={**row(),'cinecp':'20000','cineville':'Ajaccio'}
  self.assertIsNone(s.department(corsica,{'2A','2B'},[]))
  self.assertEqual(s.department(corsica,{'2A','2B'},[{'nom':'Ajaccio','codesPostaux':['20000'],'codeDepartement':'2A'}]),'2A')
 def test_pagination_without_repeated_total_and_no_partial_catalogue(self):
  next_url=s.BASE+'/lines?after=x'
  pages=[{'total':2,'results':[{'_id':'1'}],'next':next_url},{'results':[{'_id':'2'}]}]
  calls=[]
  def fetch(name,url):calls.append(url);return pages[len(calls)-1]
  self.assertEqual(len(s.fetch_pages(fetch)),2)
  for invalid in [{'total':2,'results':[{'_id':'1'}]},{'total':0,'results':[]},{'total':2,'results':[{'_id':'1'}],'next':'https://elsewhere.example/lines'}]:
   with self.assertRaises(ValueError):s.fetch_pages(lambda name,url:invalid)
  with self.assertRaises(ValueError):s.fetch_pages(lambda name,url:pages[0])
if __name__=='__main__':unittest.main()
