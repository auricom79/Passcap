import assert from 'node:assert/strict';
import {illustrationMarkup,imageURL,settleIllustration,illustrationKind,ambienceKind} from '../dist/media.mjs';
import {cardMarkup} from '../dist/signage.mjs';
const url='https://img.openagenda.com/main/test.base.image.jpg';
const r={title:'Un spectacle',type:'event',source:'OpenAgenda',sourceUrl:'https://openagenda.com/test/events/test',eventKind:'theatre',features:{motor:{value:true}},image:{url,credit:'<Auteur> & Co',policy:'oa'}};
const html=illustrationMarkup(r);
assert.ok(html.includes('loading="lazy"')&&html.includes('decoding="async"'));
assert.ok(html.includes('referrerpolicy="no-referrer"'));
assert.ok(illustrationMarkup(r,{detail:true}).includes('&lt;Auteur&gt; &amp; Co'));assert.ok(!html.includes('<figcaption'));assert.ok(!html.includes('<Auteur>'));
assert.ok(html.includes('width="640" height="360"'));
assert.ok(html.includes('alt=""'));// Redundant artwork does not repeat the heading to screen readers.
assert.ok(illustrationMarkup({...r,image:{...r.image,alt:'Un paysage <bleu>'}}).includes('alt="Un paysage &lt;bleu&gt;"'));
assert.ok(illustrationMarkup(r,{detail:true}).includes('Licence Ouverte'));
for(const input of ['https://img.openagenda.com.evil.example/a.jpg','javascript:alert(1)','http://img.openagenda.com/a.jpg','https://img.openagenda.com/a.svg?x=.jpg','https://x:y@img.openagenda.com/a.jpg'])assert.equal(imageURL(input),null);
for(const image of [null,{url,policy:'unknown'},{url:'https://elsewhere.example/a.jpg',policy:'oa'}]){
 const fallback=illustrationMarkup({...r,image});assert.ok(fallback.includes('<img'));assert.ok(fallback.includes('images.unsplash.com'));assert.ok(fallback.includes('Photo d’ambiance'));assert.ok(!fallback.includes('>Photo d’ambiance ·'));assert.ok(!fallback.includes('<figcaption'));assert.ok(illustrationMarkup({...r,image},{detail:true}).includes('>Photo d’ambiance ·'));assert.ok(!fallback.includes('<svg'));
}
const classes=new Set();const image={naturalWidth:0,hidden:false,closest:()=>({classList:{toggle:(name,on)=>on?classes.add(name):classes.delete(name)}})};
settleIllustration(image,false);assert.equal(image.hidden,true);assert.ok(classes.has('image-unavailable'));assert.ok(!classes.has('has-image'));
image.naturalWidth=640;settleIllustration(image,true);assert.equal(image.hidden,false);assert.ok(classes.has('has-image'));assert.ok(!classes.has('image-unavailable'));
assert.equal(illustrationKind({category:'Cinéma'}),'cinema');assert.equal(illustrationKind({category:'Musée'}),'exhibition');
assert.equal((cardMarkup(r).match(/<li class="need-sign/g)||[]).length,6);
console.log('Media: remote URLs, attribution, escaping, loading/failure fallback and accessible decorative artwork passed.');

assert.equal(ambienceKind({title:'Marché du dimanche',eventKind:'other'}),'market');assert.equal(ambienceKind({category:'Musée',eventKind:'visit'}),'exhibition');assert.equal(ambienceKind({title:'Projection ciné-débat'}),'cinema');assert.equal(ambienceKind({category:'Bibliothèque'}),'library');
