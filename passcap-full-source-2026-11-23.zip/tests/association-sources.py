"""Direct agenda contracts: rights, declared access, dates, territory and paging."""
import copy
import datetime
import importlib.util
import json
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
def module(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT/'scripts'/file)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result
s = module('institutional', 'association-sources.py')
helpers = module('event_helpers', 'event-sources.py')
NOW = datetime.datetime(2026,11,14,10,tzinfo=datetime.timezone.utc)
UNTIL = NOW+datetime.timedelta(days=90)

def event():
    return {'uid':123, 'title':{'fr':'Visite multisensorielle'}, 'status':1,
            'attendanceMode':1, 'canonicalUrl':'https://openagenda.com/museum/events/test',
            'rights':{'license':{'id':'etalab-2.0'},'licensor':{'name':'Musée test'}},
            'location':{'name':'Musée test', 'address':'21 rue de Metz 31000 Toulouse', 'city':'Toulouse','countryCode':'FR'},
            'accessibility':{'vi':True,'mi':False,'ii':True},
            'timings':[{'begin':'2026-11-21T10:00:00+01:00','end':'2026-11-21T11:00:00+01:00'}],
            'image':{'base':'https://img.openagenda.com/main/','filename':'test.base.image.jpg'},
            'imageCredits':'Musée test'}

class Institutional(unittest.TestCase):
    def parse(self, rows): return s.parse_events(rows, {'31','35','971','974','2A','2B'}, NOW, UNTIL, helpers)

    def test_event_declarations_only_and_unchecked_is_unknown(self):
        row = event(); row['location']['accessibility'] = {'mi':True}
        record = self.parse([row])[0]
        self.assertIsNone(record['features']['motor']['value'])
        self.assertIsNone(record['features']['autism']['value'])
        self.assertTrue(record['features']['mental']['value'])
        self.assertTrue(record['features']['visual']['value'])
        self.assertEqual(record['features']['visual']['sourceUrl'], row['canonicalUrl'])
        row['accessibility'] = {'mi':False,'vi':'true'}
        self.assertEqual(self.parse([row]), [])

    def test_open_licence_required_and_source_credit_preserved(self):
        row=event(); record=self.parse([row])[0]
        self.assertEqual(record['producer'],'Musée test')
        self.assertEqual(record['image']['policy'],'oa2')
        self.assertEqual(record['image']['credit'],'Musée test')
        for rights in [{}, {'license':{'id':'reserved'}}, {'license':{'name':'Licence Ouverte 2.0'}}]:
            row['rights']=rights
            self.assertEqual(self.parse([row]), [])

    def test_cancelled_full_online_and_invalid_links_are_excluded(self):
        for status in [3,4,5,6,None]:
            row=event();row['status']=status
            self.assertEqual(self.parse([row]),[])
        row=event();row['status']=2
        self.assertEqual(len(self.parse([row])),1)
        row['attendanceMode']=2
        self.assertEqual(self.parse([row]),[])
        row=event();row['canonicalUrl']='javascript:alert(1)'
        self.assertEqual(self.parse([row]),[])

    def test_exact_timings_not_a_fabricated_period(self):
        row=event();row['timings'] += [copy.deepcopy(row['timings'][0]),
            {'begin':'2026-11-13T10:00:00+01:00','end':'2026-11-13T11:00:00+01:00'},
            {'begin':'2027-03-01T10:00:00+01:00','end':'2027-03-01T11:00:00+01:00'},
            {'begin':'2026-11-22T10:00:00','end':'2026-11-22T11:00:00'},
            {'begin':'2026-11-28T10:00:00+01:00','end':'2026-11-28T11:00:00+01:00'}]
        record=self.parse([row])[0]
        self.assertEqual(len(record['timings']),2)
        self.assertEqual(record['timings'][1]['start'],'2026-11-28T10:00:00+01:00')

    def test_country_corsica_and_drom_do_not_guess(self):
        row=event();row['location'].update({'countryCode':'US','postalCode':'31000'})
        self.assertEqual(self.parse([row]),[])
        row=event();row['location'].update({'postalCode':'20000','address':'Ajaccio'})
        self.assertEqual(self.parse([row]),[])
        row['location']['insee']='2A004'
        self.assertEqual(self.parse([row])[0]['department'],'2A')
        row=event();row['location'].update({'postalCode':'97400','countryCode':'RE'})
        self.assertEqual(self.parse([row])[0]['timezone'],'Indian/Reunion')
        row['location'].update({'postalCode':'97150','countryCode':'FR'})
        self.assertEqual(self.parse([row]),[])

    def test_pagination_finishes_and_rejects_repeating_or_partial_export(self):
        calls=[]
        pages=[{'success':True,'total':2,'events':[{'uid':1}],'after':['x',1]},
               {'success':True,'total':2,'events':[{'uid':2}],'after':['x',2]}]
        def fetch(name,url):calls.append(url);return json.dumps(pages[len(calls)-1])
        rows=s.fetch_agenda('museum',NOW,UNTIL,fetch)
        self.assertEqual([r['uid'] for r in rows],[1,2])
        self.assertIn('after%5B%5D=x',calls[1])
        with self.assertRaises(ValueError):
            s.fetch_agenda('museum',NOW,UNTIL,lambda name,url:json.dumps(pages[0]))
        incomplete={**pages[0],'after':None}
        with self.assertRaises(ValueError):
            s.fetch_agenda('museum',NOW,UNTIL,lambda name,url:json.dumps(incomplete))

if __name__=='__main__': unittest.main()
