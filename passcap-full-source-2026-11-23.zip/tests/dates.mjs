import assert from 'node:assert/strict';
import {dateRange,filterRecords,nextSession,matchingSessions,sortRecords,sessionDate} from '../dist/logic.mjs';

const now=new Date('2026-11-13T10:00:00Z'); // Friday, 11:00 in Paris.
const state={tab:'event',city:'',age:'',need:'',query:'',unknown:true,period:'today'};
const timing=(start,end)=>({start,end});
const event=(id,timings,timezone='Europe/Paris')=>({id,title:id,type:'event',status:1,features:{motor:{value:true}},timezone,timings});
const today=event('today',[timing('2026-11-13T15:00:00+01:00','2026-11-13T17:00:00+01:00')]);
const tomorrow=event('tomorrow',[timing('2026-11-14T15:00:00+01:00','2026-11-14T17:00:00+01:00')]);
const sunday=event('sunday',[timing('2026-11-15T23:00:00+01:00','2026-11-15T23:30:00+01:00')]);
const monday=event('monday',[timing('2026-11-16T09:00:00+01:00','2026-11-16T10:00:00+01:00')]);
const ended=event('ended',[timing('2026-11-13T08:00:00+01:00','2026-11-13T09:00:00+01:00')]);
const records=[monday,tomorrow,today,sunday,ended];
const ids=s=>filterRecords(records,{...state,...s},now).map(r=>r.id);
assert.deepEqual(ids({}),['today']);
assert.deepEqual(ids({period:undefined}),['today']);
assert.deepEqual(ids({period:'tomorrow'}),['tomorrow']);
assert.deepEqual(ids({period:'week'}),['tomorrow','today','sunday']);
assert.deepEqual(ids({period:'date',date:'2026-11-15'}),['sunday']);
assert.deepEqual(ids({period:'range',dateFrom:'2026-11-14',dateTo:'2026-11-15'}),['tomorrow','sunday']);
assert.deepEqual(ids({period:'range',dateFrom:'2026-11-14',dateTo:'2026-11-14'}),['tomorrow']);
assert.equal(dateRange({period:'range',dateFrom:'2026-11-15',dateTo:'2026-11-14'},now),null);
assert.equal(dateRange({period:'date',date:'2026-02-30'},now),null);
assert.equal(dateRange({period:'date',date:''},now),null);
assert.deepEqual(dateRange({period:'week'},new Date('2026-11-15T10:00:00Z')),{start:'2026-11-15',end:'2026-11-15'});
assert.deepEqual(dateRange({period:'tomorrow'},new Date('2026-12-31T12:00:00Z')),{start:'2027-01-01',end:'2027-01-01'});

// An event with multiple sessions must use the matching session for order and display.
const recurring=event('recurring',[
 timing('2026-11-16T16:00:00+01:00','2026-11-16T17:00:00+01:00'),
 timing('2026-11-13T16:00:00+01:00','2026-11-13T17:00:00+01:00'),
 timing('2026-11-14T14:00:00+01:00','2026-11-14T15:00:00+01:00')
]);
const tomorrowState={...state,period:'tomorrow'};
assert.equal(nextSession(recurring,now,tomorrowState).start,'2026-11-14T14:00:00+01:00');
assert.deepEqual(sortRecords([tomorrow,recurring],'event',now,tomorrowState).map(r=>r.id),['recurring','tomorrow']);
assert.equal(matchingSessions(recurring,tomorrowState,now).length,1);

// Inclusive selected dates, overlapping multi-day events, and exclusive midnight end.
const exhibition=event('exhibition',[timing('2026-11-12T09:00:00+01:00','2026-11-16T18:00:00+01:00')]);
assert.equal(filterRecords([exhibition],tomorrowState,now).length,1);
assert.equal(sessionDate(nextSession(exhibition,now,tomorrowState),tomorrowState,'Europe/Paris',now),'2026-11-14');
const midnight=event('midnight',[timing('2026-11-13T21:00:00+01:00','2026-11-14T00:00:00+01:00')]);
assert.equal(filterRecords([midnight],state,now).length,1);
assert.equal(filterRecords([midnight],tomorrowState,now).length,0);

// DROM dates are local to the event, not to the visitor's computer.
const boundary=new Date('2026-11-14T01:00:00Z');
assert.deepEqual(dateRange(state,boundary,'America/Guadeloupe'),{start:'2026-11-13',end:'2026-11-13'});
assert.deepEqual(dateRange(state,boundary,'Indian/Reunion'),{start:'2026-11-14',end:'2026-11-14'});
const guadeloupe=event('guadeloupe',[timing('2026-11-13T22:00:00-04:00','2026-11-13T23:00:00-04:00')],'America/Guadeloupe');
assert.equal(filterRecords([guadeloupe],state,boundary).length,1);
assert.equal(filterRecords([guadeloupe],tomorrowState,boundary).length,0);

// Tomorrow is a calendar day even when the clock changes (23 or 25 hours).
for(const [clock,inside,outside] of [
 ['2026-03-28T22:30:00Z','2026-03-29T21:00:00Z','2026-03-29T23:00:00Z'],
 ['2026-10-24T21:30:00Z','2026-10-25T22:00:00Z','2026-10-25T23:30:00Z']
]){
 const a=event('inside',[timing(inside,new Date(Date.parse(inside)+600000).toISOString())]);
 const b=event('outside',[timing(outside,new Date(Date.parse(outside)+600000).toISOString())]);
 assert.deepEqual(filterRecords([a,b],tomorrowState,new Date(clock)).map(r=>r.id),['inside']);
}

// The mixed view filters events too, without inventing opening hours for places.
const place={id:'place',title:'place',type:'place',features:{motor:{value:true}}};
assert.deepEqual(filterRecords([today,tomorrow,place],{...state,tab:'all'},now).map(r=>r.id),['today','place']);
assert.deepEqual(filterRecords([today,place],{...state,tab:'place'},now).map(r=>r.id),['place']);
// A specific session on the requested date precedes a short stay and a long season.
const november30={...state,period:'date',date:'2026-11-30'};
const annual=event('annual',[{...timing('2026-01-01T00:00:00+01:00','2026-12-01T00:00:00+01:00'),dateOnly:true}]);
const weekend=event('weekend',[timing('2026-11-28T09:00:00+01:00','2026-11-30T18:00:00+01:00')]);
const lunch=event('lunch',[timing('2026-11-30T13:00:00+01:00','2026-11-30T14:00:00+01:00')]);
const evening=event('evening',[timing('2026-11-30T20:00:00+01:00','2026-12-01T00:00:00+01:00')]);
const monthly=event('monthly',[
 timing('2026-11-01T12:00:00+01:00','2026-11-01T13:00:00+01:00'),
 timing('2026-11-30T15:00:00+01:00','2026-11-30T16:00:00+01:00'),
 timing('2026-12-30T15:00:00+01:00','2026-12-30T16:00:00+01:00')
]);
const candidates=[annual,evening,weekend,monthly,lunch];
const order=(rows,s,clock=now,tab='event')=>sortRecords(filterRecords(rows,{...s,tab},clock),tab,clock,s).filter(r=>r.type==='event').map(r=>r.id);
const expected=['lunch','monthly','evening','weekend','annual'];
assert.deepEqual(order(candidates,november30),expected);
assert.deepEqual(order([...candidates,place],november30,now,'all'),expected);
assert.deepEqual(order(candidates,{...state,period:'today'},new Date('2026-11-30T08:00:00Z')),expected);
assert.deepEqual(order(candidates,{...state,period:'tomorrow'},new Date('2026-11-29T08:00:00Z')),expected);
assert.deepEqual(order(candidates,{...state,period:'range',dateFrom:'2026-11-30',dateTo:'2026-11-30'}),expected);
assert.deepEqual(candidates.map(r=>r.id),['annual','evening','weekend','monthly','lunch'],'Sorting must not mutate the catalogue');

// Multi-day searches retain chronological day headings and prioritize within a day.
const later=event('later',[timing('2026-12-01T09:00:00+01:00','2026-12-01T10:00:00+01:00')]);
const range={...state,period:'range',dateFrom:'2026-11-30',dateTo:'2026-12-01'};
assert.deepEqual(order([later,...candidates],range),[...expected,'later']);
assert.deepEqual(sortRecords([annual,lunch],'event',new Date('2026-11-30T08:00:00Z')).map(r=>r.id),['lunch','annual']);

// Count occupied local calendar days, not elapsed hours or dates in UTC.
const islandPeriod=event('island-period',[timing('2026-01-01T00:00:00-04:00','2026-12-01T00:00:00-04:00')],'America/Guadeloupe');
const islandSession=event('island-session',[timing('2026-11-30T22:00:00-04:00','2026-12-01T00:00:00-04:00')],'America/Guadeloupe');
assert.deepEqual(order([islandPeriod,islandSession],november30),['island-session','island-period']);
const autumn={...state,period:'date',date:'2026-10-25'};
const autumnNow=new Date('2026-10-24T12:00:00Z');
const shortAcrossMidnight=event('two-days',[timing('2026-10-25T23:00:00+01:00','2026-10-26T01:00:00+01:00')]);
const twentyFiveHours=event('one-local-day',[{...timing('2026-10-25T00:00:00+02:00','2026-10-26T00:00:00+01:00'),dateOnly:true}]);
assert.deepEqual(order([shortAcrossMidnight,twentyFiveHours],autumn,autumnNow),['one-local-day','two-days']);
console.log('Dates: filters, specific-day priority before overlapping periods, chronological groups, recurring sessions, exclusive midnight, DROM and daylight saving passed.');
