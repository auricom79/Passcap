import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {activeProfileNeeds,applyMemberProfile} from '../dist/profile-filter.mjs';
import {filterRecords} from '../dist/logic.mjs';
const base=JSON.parse(fs.readFileSync(new URL('../dist/data/departments/33.json',import.meta.url))).records.find(r=>r.type==='event');
const event=(id,features)=>({...structuredClone(base),id,timings:[{start:'2026-11-16T12:00:00Z',end:'2026-11-16T14:00:00Z'}],features:Object.fromEntries(['motor','hearing','visual','mental','autism','psychic'].map(k=>[k,{value:features[k]??null}]))});
const records=[event('both',{motor:true,autism:true}),event('one',{motor:true,autism:false}),event('unknown',{motor:true})];
const now=new Date('2026-11-15T08:00:00Z');
const filtered=()=>filterRecords(records,{tab:'event',period:'all',unknown:true,profileNeeds:activeProfileNeeds()},now).map(r=>r.id);
test('all saved needs must be declared; disabling restores records with false or unknown adaptations',()=>{
 applyMemberProfile({id:'a',needs:['motor','autism'],autoFilter:true});assert.deepEqual(filtered(),['both']);
 applyMemberProfile({id:'a',needs:['motor','autism'],autoFilter:false});assert.deepEqual(filtered(),['both','one','unknown']);
 applyMemberProfile({id:'a',needs:['motor'],autoFilter:true});assert.deepEqual(filtered(),['both','one','unknown']);
 applyMemberProfile(null);assert.deepEqual(activeProfileNeeds(),[]);assert.deepEqual(filtered(),['both','one','unknown']);
});
