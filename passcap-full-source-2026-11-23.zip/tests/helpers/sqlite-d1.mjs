// Local-only D1 contract adapter backed by real SQLite. Never bundled in the Worker.
import {DatabaseSync} from 'node:sqlite';
export function sqliteD1(path=':memory:'){
 const sqlite=new DatabaseSync(path);sqlite.exec('PRAGMA foreign_keys=ON');
 function statement(sql,params=[]){return {sql,params,bind(...values){return statement(sql,values);},async first(column){const r=sqlite.prepare(sql).get(...params);return column?r?.[column]??null:r??null;},async all(){return {results:sqlite.prepare(sql).all(...params),success:true};},async run(){const r=sqlite.prepare(sql).run(...params);return {success:true,meta:{changes:Number(r.changes),last_row_id:Number(r.lastInsertRowid)}};}};}
 return {prepare:statement,async batch(statements){sqlite.exec('BEGIN');try{const rows=[];for(const s of statements)rows.push(await s.run());sqlite.exec('COMMIT');return rows;}catch(e){sqlite.exec('ROLLBACK');throw e;}},exec:sql=>sqlite.exec(sql),close:()=>sqlite.close()};
}
