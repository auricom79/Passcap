import test from 'node:test';
import assert from 'node:assert/strict';
import {readdirSync,readFileSync} from 'node:fs';
import {sqliteD1} from './helpers/sqlite-d1.mjs';
import {createCommunityHandler} from '../worker/community.mjs';
import {selectNewsletterEvents,sendWeeklyNewsletter,unsubscribeNewsletter} from '../worker/newsletter.mjs';
const origin='https://passcap.org',now=new Date('2026-11-19T17:00:00Z'),userId='12345678-1234-4234-8234-123456789abc';
const base=JSON.parse(readFileSync(new URL('../dist/data/departments/33.json',import.meta.url),'utf8')).records.find(r=>r.type==='event');
const event=(id,motor)=>({...base,id,title:id,features:{motor:{value:motor},hearing:{value:true}},timings:[{start:'2026-11-20T10:00:00+01:00',end:'2026-11-20T12:00:00+01:00'}]});
const records=[event('adapted',true),event('unknown',null),{...event('place',true),type:'place'},{...event('past',true),timings:[{start:'2025-01-01T10:00:00Z',end:'2025-01-01T12:00:00Z'}]}];
const snapshot={departments:{'33':{records}}};
function fixture(){const DB=sqliteD1();for(const name of readdirSync(new URL('../drizzle',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())DB.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 const env={DB,APP_ORIGIN:origin,PASSWORD_PEPPER:'a-separate-test-only-pepper-longer-than-32',RESEND_API_KEY:'test',ACCOUNT_EMAIL_FROM:'Pass Cap <bonjour@passcap.org>',NEWSLETTER_ENABLED:'true'};
 return {DB,env};}
test('newsletter includes future events only; profile filtering excludes unknown adaptations',()=>{
 assert.deepEqual(selectNewsletterEvents(records,[],now).map(r=>r.id),['adapted','unknown']);assert.deepEqual(selectNewsletterEvents(records,['motor'],now).map(r=>r.id),['adapted']);
});
test('subscriptions require explicit consent and authenticated members; weekly sending is idempotent and unsubscribe is signed',async()=>{
 const f=fixture(),route=createCommunityHandler(),sessionToken='a'.repeat(64),hash=Buffer.from(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(sessionToken))).toString('hex');
 try{
  await f.DB.prepare("INSERT INTO community_users(id,google_sub,email,pseudo,created_at,needs_json) VALUES(?,?,'test@example.com','Test',?,?)").bind(userId,'test-sub',Date.now(),'["motor"]').run();
  await f.DB.prepare('INSERT INTO community_sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)').bind(hash,userId,Date.now(),Date.now()+3600000).run();
  const request=(body,cookie=true)=>route(new Request(origin+'/api/community/newsletter',{method:'PATCH',headers:{Origin:origin,'Content-Type':'application/json',...(cookie?{Cookie:'__Host-pc_session='+sessionToken}:{})},body:JSON.stringify(body)}),f.env,async()=>null);
  assert.equal((await request({enabled:true,department:'33',profileFilter:true,consent:true},false)).status,401);
  assert.equal((await request({enabled:true,department:'33',profileFilter:true})).status,400);
  assert.equal((await request({enabled:true,department:'33',profileFilter:true,consent:true})).status,200);
  const sent=[];globalThis.fetch=async(url,options)=>{assert.equal(url,'https://api.resend.com/emails');sent.push(JSON.parse(options.body));return Response.json({id:'mail-test'});};
  let loaded=false;assert.equal((await sendWeeklyNewsletter(f.env,()=>{loaded=true;return snapshot;},new Date('2026-11-19T12:00:00Z'))).sent,0);assert.equal(loaded,false);
  assert.equal((await sendWeeklyNewsletter(f.env,snapshot,now)).sent,1);assert.equal((await sendWeeklyNewsletter(f.env,snapshot,now)).sent,0);assert.equal(sent.length,1);
  assert.ok(sent[0].text.includes('adapted'));assert.ok(!sent[0].text.includes('unknown'));assert.ok(!sent[0].text.includes('motor'));assert.ok(sent[0].headers['List-Unsubscribe-Post']);
  const oneClick=sent[0].headers['List-Unsubscribe'].slice(1,-1);
  assert.equal((await unsubscribeNewsletter(new Request(oneClick),f.env)).status,405);
  assert.equal((await unsubscribeNewsletter(new Request(oneClick.replace(/signature=./,'signature=z'),{method:'POST'}),f.env)).status,400);
  assert.equal((await unsubscribeNewsletter(new Request(oneClick,{method:'POST'}),f.env)).status,200);
  assert.equal((await f.DB.prepare('SELECT enabled FROM community_newsletters').first()).enabled,0);
 }finally{f.DB.close();}
});
test('guest newsletter: no account, confirmed consent, single-use tokens, weekly send and signed deletion',async()=>{
 const f=fixture(),route=createCommunityHandler(),sent=[],savedFetch=globalThis.fetch;
 globalThis.fetch=async(url,options)=>{sent.push(JSON.parse(options.body));return Response.json({id:'test'});};
 const request=(action,data,headers={Origin:origin})=>route(new Request(origin+'/api/community/newsletter/'+action,{method:'POST',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify(data)}),f.env,async()=>null);
 try{
  assert.equal((await request('subscribe',{email:'test@example.com',department:'33',consent:true},{Origin:'https://evil.example'})).status,403);
  assert.equal((await request('subscribe',{email:'invalid',department:'33',consent:true})).status,400);
  assert.equal((await request('subscribe',{email:'test@example.com',department:'99',consent:true})).status,400);
  assert.equal((await request('subscribe',{email:'test@example.com',department:'33'})).status,400);
  const subscribe=()=>request('subscribe',{email:' Visitor@Example.com ',department:'33',consent:true});
  assert.equal((await subscribe()).status,200);
  assert.equal((await f.DB.prepare('SELECT count(*) n FROM community_users').first()).n,0);
  assert.equal((await f.DB.prepare('SELECT count(*) n FROM newsletter_guests').first()).n,0);
  assert.ok(sent[0].html.includes('Confirmer mon inscription'));
  const token=sent[0].text.match(/token=([a-f0-9]{64})/)[1];
  assert.notEqual((await f.DB.prepare('SELECT token_hash FROM newsletter_guest_tokens').first()).token_hash,token);
  assert.equal((await request('confirm',{token})).status,200);assert.equal((await request('confirm',{token})).status,400);
  const guest=await f.DB.prepare('SELECT * FROM newsletter_guests').first();assert.equal(guest.email,'visitor@example.com');assert.equal(guest.department,'33');
  assert.equal((await sendWeeklyNewsletter(f.env,snapshot,now)).sent,1);assert.equal((await sendWeeklyNewsletter(f.env,snapshot,now)).sent,0);
  const mail=sent[1];assert.ok(mail.text.includes('unknown'));assert.ok(mail.text.includes('#newsletter=subscribe'));assert.ok(!mail.text.includes('#account=newsletter'));
  const url=mail.headers['List-Unsubscribe'].slice(1,-1);assert.ok(url.includes('kind=guest'));
  assert.equal((await unsubscribeNewsletter(new Request(url),f.env)).status,405);
  assert.equal((await unsubscribeNewsletter(new Request(url.replace('kind=guest','kind=member'),{method:'POST'}),f.env)).status,400);
  assert.equal((await unsubscribeNewsletter(new Request(url,{method:'POST'}),f.env)).status,200);
  assert.equal((await f.DB.prepare('SELECT count(*) n FROM newsletter_guests').first()).n,0);
  assert.equal((await f.DB.prepare('SELECT count(*) n FROM newsletter_guest_deliveries').first()).n,0);
 }finally{globalThis.fetch=savedFetch;f.DB.close();}
});
test('guest confirmation expires and requesting a change preserves the confirmed department until confirmation',async()=>{
 const f=fixture(),route=createCommunityHandler(),sent=[],savedFetch=globalThis.fetch;
 globalThis.fetch=async(url,o)=>{sent.push(JSON.parse(o.body));return Response.json({id:'test'});};
 const post=(action,data)=>route(new Request(origin+'/api/community/newsletter/'+action,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(data)}),f.env,async()=>null);
 try{
  const subscribe=department=>post('subscribe',{email:'guest@example.com',department,consent:true});
  await subscribe('33');let token=sent.at(-1).text.match(/token=([a-f0-9]{64})/)[1];await post('confirm',{token});
  await subscribe('79');token=sent.at(-1).text.match(/token=([a-f0-9]{64})/)[1];assert.equal((await f.DB.prepare('SELECT department FROM newsletter_guests').first()).department,'33');
  await f.DB.prepare('UPDATE newsletter_guest_tokens SET expires_at=0').run();assert.equal((await post('confirm',{token})).status,400);assert.equal((await f.DB.prepare('SELECT department FROM newsletter_guests').first()).department,'33');
  await subscribe('79');token=sent.at(-1).text.match(/token=([a-f0-9]{64})/)[1];assert.equal((await post('confirm',{token})).status,200);assert.equal((await f.DB.prepare('SELECT department FROM newsletter_guests').first()).department,'79');
 }finally{globalThis.fetch=savedFetch;f.DB.close();}
});
test('guest mail is not duplicated when a member subscription uses the same email; failed confirmation mail leaves no token',async()=>{
 const f=fixture(),route=createCommunityHandler(),savedFetch=globalThis.fetch,sent=[];
 globalThis.fetch=async(url,o)=>{sent.push(JSON.parse(o.body));return Response.json({id:'test'});};
 try{
  await f.DB.prepare('INSERT INTO community_users(id,google_sub,email,pseudo,created_at) VALUES(?,?,?,?,?)').bind(userId,'test-google','same@example.com','Test',Date.now()).run();
  await f.DB.prepare('INSERT INTO community_newsletters(user_id,department,profile_filter,enabled,consent_at,updated_at) VALUES(?,?,0,1,?,?)').bind(userId,'33',Date.now(),Date.now()).run();
  await f.DB.prepare('INSERT INTO newsletter_guests(id,email,department,consent_at,updated_at) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),'same@example.com','33',Date.now(),Date.now()).run();
  assert.equal((await sendWeeklyNewsletter(f.env,snapshot,now)).sent,1);assert.equal(sent.length,1);
  globalThis.fetch=async()=>new Response('unavailable',{status:503});
  const r=await route(new Request(origin+'/api/community/newsletter/subscribe',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({email:'failed@example.com',department:'33',consent:true})}),f.env,async()=>null);
  assert.equal(r.status,503);assert.equal((await f.DB.prepare('SELECT count(*) n FROM newsletter_guest_tokens').first()).n,0);
 }finally{globalThis.fetch=savedFetch;f.DB.close();}
});
