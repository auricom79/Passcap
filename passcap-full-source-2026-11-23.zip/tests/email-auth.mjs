import test from 'node:test';
import assert from 'node:assert/strict';
import {readdirSync,readFileSync} from 'node:fs';
import {createCommunityHandler} from '../worker/community.mjs';
import {sqliteD1} from './helpers/sqlite-d1.mjs';
const origin='https://passcap.org',password='Une belle sortie 2026 !',replacement='Un nouveau joli départ !';
function fixture(){
 const DB=sqliteD1();for(const name of readdirSync(new URL('../drizzle',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())DB.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
 const env={DB,APP_ORIGIN:origin,RESEND_API_KEY:'test-only',ACCOUNT_EMAIL_FROM:'Pass Cap <bonjour@passcap.org>',PASSWORD_PEPPER:'test-only-pepper-with-32-characters-minimum'},route=createCommunityHandler();
 return {DB,env,request:(action,body,cookie='',method='POST')=>route(new Request(origin+'/api/community/'+action,{method,headers:{Origin:origin,'Content-Type':'application/json',Cookie:cookie,'CF-Connecting-IP':'192.0.2.2'},...(method!=='GET'?{body:JSON.stringify(body)}:{})}),env,async()=>null)};
}
const mails=[];let mailFails=false;
globalThis.fetch=async(url,options)=>{assert.equal(url,'https://api.resend.com/emails');assert.equal(options.redirect,'manual');const body=JSON.parse(options.body);mails.push(body);return Response.json({}, {status:mailFails?503:200});};
const token=()=>mails.findLast(m=>m.text.includes('&token='))?.text.match(/&token=([a-f0-9]{64})/)[1];
const session=r=>r.headers.get('set-cookie')?.split(';')[0]||'';
test('confirmed signup, password verification and reset are private, one-use and revoke previous sessions',async()=>{
 const f=fixture();try{
  assert.equal((await f.request('email/register',{email:'alice@example.com',password:'short'})).status,400);
  assert.equal((await f.request('email/register',{email:' Alice@Example.com ',password})).status,200);const signup=token();
  assert.equal((await f.DB.prepare('SELECT count(*) AS n FROM community_users').first()).n,0);
  const pending=await f.DB.prepare('SELECT * FROM community_email_tokens').first();assert.notEqual(pending.token_hash,signup);assert.notEqual(pending.password_hash,password);
  const verified=await f.request('email/verify',{token:signup});assert.equal(verified.status,200,await verified.clone().text());const cookie=session(verified),u=(await verified.json()).user;
  assert.equal(u.email,'alice@example.com');assert.equal(u.profileComplete,false);assert.equal((await f.request('email/verify',{token:signup})).status,400);
  assert.equal((await f.request('email/login',{email:u.email,password:'incorrect'})).status,401);
  const login=await f.request('email/login',{email:u.email,password});assert.equal(login.status,200);const second=session(login);
  assert.equal((await f.request('email/forgot',{email:u.email})).status,200);const reset=token();
  assert.equal((await f.request('email/verify',{token:reset})).status,400);
  assert.equal((await f.request('email/reset',{token:reset,password:replacement})).status,200);
  assert.equal((await (await f.request('me',null,cookie,'GET')).json()).user,null);assert.equal((await (await f.request('me',null,second,'GET')).json()).user,null);
  assert.equal((await f.request('email/reset',{token:reset,password})).status,400);
  assert.equal((await f.request('email/login',{email:u.email,password})).status,401);assert.equal((await f.request('email/login',{email:u.email,password:replacement})).status,200);
  const publicText=JSON.stringify(u);assert.ok(!publicText.includes('password_hash'));assert.ok(!publicText.includes('google_sub'));
 }finally{f.DB.close();}
});
test('unknown accounts, existing accounts, missing mail and delivery failures fail safely',async()=>{
 const f=fixture();try{
  const unknown=await f.request('email/forgot',{email:'unknown@example.com'});assert.deepEqual(await unknown.json(),{ok:true});
  assert.equal((await f.request('email/login',{email:'unknown@example.com',password})).status,401);
  mailFails=true;assert.equal((await f.request('email/register',{email:'bob@example.com',password})).status,503);mailFails=false;
  assert.equal((await f.DB.prepare('SELECT count(*) AS n FROM community_email_tokens').first()).n,0);
  f.env.PASSWORD_PEPPER='';assert.equal((await f.request('email/register',{email:'bob@example.com',password})).status,503);
 }finally{mailFails=false;f.DB.close();}
});
test('expired links cannot establish a password or session',async()=>{
 const f=fixture();try{
  await f.request('email/register',{email:'expired@example.com',password});const t=token();await f.DB.prepare('UPDATE community_email_tokens SET expires_at=0').run();
  assert.equal((await f.request('email/verify',{token:t})).status,400);assert.equal((await f.DB.prepare('SELECT count(*) AS n FROM community_users').first()).n,0);
 }finally{f.DB.close();}
});
