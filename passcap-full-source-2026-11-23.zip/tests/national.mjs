import fs from 'node:fs';
import {isEligibleRecord} from '../dist/content-policy.mjs';
import assert from 'node:assert/strict';
import {filterRecords,ageMatches,nextSession} from '../dist/logic.mjs';
const catalog=JSON.parse(fs.readFileSync(new URL('../dist/data.json',import.meta.url)));
const map=JSON.parse(fs.readFileSync(new URL('../dist/map-data.json',import.meta.url)));
assert.equal(catalog.departments.length,101);assert.equal(new Set(map.map(d=>d.code)).size,101);
assert.deepEqual(new Set(map.map(d=>d.code)),new Set(catalog.departments.map(d=>d.code)));
let events=0,places=0,known=0;const ids=new Set();
for(const dep of catalog.departments){
 const rows=JSON.parse(fs.readFileSync(new URL('../dist/'+dep.file,import.meta.url))).records;
 assert.equal(rows.filter(r=>r.type==='event').length,dep.events);
 assert.equal(rows.filter(r=>r.type==='place').length,dep.places);
 for(const r of rows){
  assert.ok(isEligibleRecord(r),r.id+' violates the selection policy');assert.equal(r.department,dep.code);assert.ok(!ids.has(r.id));ids.add(r.id);
  assert.ok(r.sourceUrl.startsWith('https://'));assert.ok([null,true,false].includes(r.features.autism.value));
  if(r.type==='event'){
   events++;assert.ok([1,2].includes(r.status));assert.ok(r.timings.length>0);
   assert.ok(r.timings.every(t=>new Date(t.end)>=new Date(catalog.importedAt)&&new Date(t.start)<=new Date(catalog.horizonEnd)));
   if(r.features.motor.value===true)known++;
  }else places++;
  if(dep.drom)assert.notEqual(r.timezone,'Europe/Paris');
 }
 // A department may legitimately have no record with a declared adaptation.
}
assert.equal(events,catalog.totalEvents);assert.equal(places,catalog.totalPlaces);assert.ok(known>1000);
assert.deepEqual(catalog.departments.filter(d=>d.drom).map(d=>d.code),['971','972','973','974','976']);
const base={tab:'all',city:'',age:'',need:'',query:'',unknown:true,period:'all'};
const g=JSON.parse(fs.readFileSync(new URL('../dist/data/departments/33.json',import.meta.url))).records;
const explicit=filterRecords(g,{...base,age:'child',need:'motor',unknown:false});assert.ok(explicit.length>0);assert.ok(explicit.every(r=>r.features.motor.value===true&&ageMatches(r,'child')===true));
assert.ok(filterRecords(g,{...base,city:'merignac'}).length>0);
assert.ok(filterRecords(g,{...base,need:'autism',unknown:false}).every(r=>r.features.autism.value===true));
assert.equal(filterRecords(g,{...base,tab:'event'},new Date('2040-01-01')).length,0);
assert.equal(new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit',timeZone:'America/Guadeloupe'}).format(new Date('2026-10-08T18:00:00Z')),'14:00');
assert.equal(new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit',timeZone:'Indian/Reunion'}).format(new Date('2026-10-08T18:00:00Z')),'22:00');
console.log(JSON.stringify({departments:101,events,places,eventsWithMotorAdaptations:known,combinedChildMotor:explicit.length,uniqueIds:ids.size,drom:catalog.departments.filter(d=>d.drom).map(d=>({name:d.nom,places:d.places,events:d.events}))}));
