"""Source contract tests: declared adaptations, exact sessions and honest times."""
import datetime,importlib.util,pathlib,unittest
spec=importlib.util.spec_from_file_location('sources',pathlib.Path(__file__).resolve().parents[1]/'scripts/event-sources.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
NOW=datetime.datetime(2026,11,13,10,tzinfo=datetime.timezone.utc)
END=NOW+datetime.timedelta(days=90)
class Sources(unittest.TestCase):
 def test_image_provenance_and_restrictions(self):
  image='https://img.openagenda.com/main/test.base.image.jpg'
  self.assertEqual(s.remote_image(image,'Ville de Nantes')['credit'],'Ville de Nantes')
  for bad in ['javascript:alert(1)','http://img.openagenda.com/test.jpg','https://evil.example/test.jpg','https://img.openagenda.com:bad/test.jpg','https://img.openagenda.com@evil.example/test.jpg','https://img.openagenda.com/test.svg?x=.jpg']:
   self.assertIsNone(s.remote_image(bad))
  for restricted in ['CC BY-NC 4.0','Tous droits réservés','Reproduction interdite']:
   self.assertIsNone(s.remote_image(image,restricted))
  paris='https://cdn.paris.fr/test.jpg'
  self.assertIsNone(s.remote_image(paris,'Photographe',policy='paris'))
  self.assertEqual(s.remote_image(paris,'CC0 Paris Musées',policy='paris')['policy'],'cc0')
  self.assertEqual(s.remote_image(paris,'Auteur CC BY-SA 4.0',policy='paris')['policy'],'cc-by-sa-4.0')
 def test_paris_does_not_invent_adaptations_or_daily_hours(self):
  row={'id':1,'title':'Projection','url':'https://www.paris.fr/evenements/test','address_zipcode':'75001','date_start':'2026-11-14T10:00:00+01:00','date_end':'2026-11-20T18:00:00+01:00','pmr':None,'blind':0,'deaf':1}
  r=s.parse_paris([row],{'75'},NOW,END)[0]
  self.assertIsNone(r['features']['motor']['value']);self.assertFalse(r['features']['visual']['value']);self.assertTrue(r['features']['hearing']['value'])
  self.assertIsNone(r['features']['autism']['value']);self.assertTrue(r['timings'][0]['dateOnly'])
 def test_nantes_cancelled_and_unknown_end(self):
  row={'id_manif':1,'nom':'Théâtre','code_postal':'44000','date':'2026-11-14','heure_debut':'20:00','h_moteur':'oui','h_intellectuel':'oui','lien_agenda':'https://metropole.nantes.fr/agenda/test'}
  r=s.parse_nantes([row],{'44'},NOW,END)[0]
  self.assertFalse(r['timings'][0]['endTimeKnown']);self.assertIsNone(r['features']['autism']['value'])
  for flag in ['annule','complet','reporte']:self.assertEqual(s.parse_nantes([{**row,flag:'oui'}],{'44'},NOW,END),[])
 def test_psg_home_and_confirmed_time_only(self):
  def card(home=True,hour='21:00'):
   return f'<article id="fixture-card-1"><h2>{"Paris Saint-Germain vs Roma" if home else "Roma vs Paris Saint-Germain"} - 25 novembre 2026 - {hour}</h2><time datetime="2026-11-25T20:00:00Z"></time>Parc des Princes<a href="/matchs/football-masculin/test">Match</a></article>'
  self.assertEqual(len(s.parse_psg(card(),NOW,END)),1)
  self.assertEqual(s.parse_psg(card(False),NOW,END),[]);self.assertEqual(s.parse_psg(card(hour='À confirmer'),NOW,END),[])
 def test_opera_access_is_scoped_to_session(self):
  def item(extra,venue='Palais Garnier'):
   return f'<li class="TicketingList__item"><div class="TicketingList__title"><a href="https://www.operadeparis.fr/saison/test"><h2 class="title-oeuvre">Opéra test</h2></a></div><div class="TicketingList__description">{venue} — 20h00</div>{extra}</li>'
  def page(extra,venue='Palais Garnier'):return '<ul class="TicketingList"><div class="PerformanceDate" title="samedi 14 novembre 2026"></div>'+item(extra,venue)+'</ul>'
  normal=s.parse_opera(page(''),NOW,END)[0][0];relax=s.parse_opera(page('Relax Audiodescription'),NOW,END)[0][0]
  self.assertIsNone(normal['features']['autism']['value']);self.assertIsNone(normal['features']['visual']['value'])
  self.assertTrue(relax['features']['autism']['value']);self.assertTrue(relax['features']['visual']['value'])
  self.assertFalse(normal['timings'][0]['endTimeKnown']);self.assertEqual(s.parse_opera(page('Complet'),NOW,END)[0],[])
  self.assertEqual(s.parse_opera(page('','Studio Bastille'),NOW,END)[0],[])
 def test_relax_no_film_no_event_and_no_inferred_wheelchair(self):
  e={'id':1,'date':'2026-11-14','time':'16:30:00','eventSessionType':'Movie','movie':{'title':'Film test'},'theater':{'name':'Cinéma','address':{'country':'france','zipCode':'79100','city':'Thouars'}},'organizer':{'slug':'test','name':'Ciné Relax'}}
  r=s.parse_relax({'movies':[e]}, {'79'},NOW,END)[0]
  self.assertEqual(r['eventKind'],'cinema');self.assertTrue(r['features']['autism']['value']);self.assertIsNone(r['features']['motor']['value']);self.assertFalse(r['timings'][0]['endTimeKnown'])
  self.assertEqual(s.parse_relax({'movies':[{**e,'movie':None}]},{'79'},NOW,END),[])
  foreign={**e,'theater':{'name':'Cinéma','address':{'country':'belgique','zipCode':'79100'}}}
  self.assertEqual(s.parse_relax({'movies':[foreign]},{'79'},NOW,END),[])
if __name__=='__main__':unittest.main()
