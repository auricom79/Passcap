import datetime as dt
import importlib.util
import pathlib
import unittest
import tempfile
import zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def module(name):
 s=importlib.util.spec_from_file_location(name,ROOT/'scripts'/(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
h,t=module('event-sources'),module('tourism-sources')
NOW=dt.datetime(2026,11,14,7,tzinfo=dt.timezone.utc);END=NOW+dt.timedelta(days=90)
def regional(**updates):
 r={'SyndicObjectID':'FMA123','NOMOFFRE':'Exposition test','COMMUNEINSEE':'79100','COMMUNE':'THOUARS','CP':'79100','DATESCOMPLET':'15/11/2026|15/11/2026|15:00|18:00|||','ACCESHANDI':'oui'};r.update(updates);return r
class Tourism(unittest.TestCase):
 def test_streamed_national_graph_keeps_only_direct_flags(self):
  rdf='\n'.join(['<https://data.datatourisme.fr/1/event> <https://www.datatourisme.fr/ontology/core#reducedMobilityAccess> "true" .','<https://data.datatourisme.fr/1/event> <http://purl.org/dc/elements/1.1/identifier> "FMA123" .','<https://data.datatourisme.fr/1/venue> <https://www.datatourisme.fr/ontology/core#reducedMobilityAccess> "false" .','<https://data.datatourisme.fr/1/other> <https://example.org/ontology#reducedMobilityAccess> "true" .'])
  with tempfile.TemporaryDirectory() as folder:
   file=pathlib.Path(folder)/'data.zip'
   with zipfile.ZipFile(file,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('nested/data.nt',rdf)
   index=t.extract_access_index(file)
  self.assertEqual(index['values'],{'https://data.datatourisme.fr/1/event':True,'https://data.datatourisme.fr/1/venue':False})
  self.assertEqual(index['identifiers']['https://data.datatourisme.fr/1/event'],'FMA123')
 def test_pmr_is_event_specific_and_unknown_is_excluded(self):
  r=t.parse_sirtaqui([regional()],{'79'},NOW,END,h,{})[0]
  self.assertTrue(r['features']['motor']['value']);self.assertIsNone(r['features']['autism']['value'])
  self.assertEqual(t.parse_sirtaqui([regional(ACCESHANDI=None)],{'79'},NOW,END,h,{}),[])
  self.assertEqual(t.parse_sirtaqui([regional(ACCESHANDI='non')],{'79'},NOW,END,h,{}),[])
 def test_weekly_market_not_every_day(self):
  row=regional(NOMOFFRE='Marché hebdomadaire (dimanche matin)',DATESCOMPLET='01/01/2026|31/12/2026|08:30|12:00|||Dimanche après midi Lundi Mardi Mercredi Jeudi Vendredi Samedi')
  sessions=t.sirtaqui_timings(row,NOW,END,h)
  self.assertTrue(sessions);self.assertTrue(all(h.iso(x['start']).weekday()==6 for x in sessions));self.assertTrue(all(h.iso(x['start']).hour==8 for x in sessions))
 def test_period_is_not_continuous_opening_and_afternoon_slot_is_preserved(self):
  p=t.sirtaqui_timings(regional(DATESCOMPLET='15/11/2026|18/11/2026|10:00|18:00|||'),NOW,END,h)
  self.assertEqual(len(p),1);self.assertTrue(p[0]['dateOnly'])
  s=t.sirtaqui_timings(regional(DATESCOMPLET='15/11/2026|15/11/2026|||14:15|16:30|'),NOW,END,h)
  self.assertEqual(h.iso(s[0]['start']).strftime('%H:%M'),'14:15')
 def test_negation_tickets_and_themes_do_not_create_accessibility(self):
  for text in ['Non accessible aux PMR.','Pas d’accès PMR.','Tarif réduit pour les personnes handicapées.','Un spectacle avec des danseurs en fauteuil.','Découverte de la langue des signes.', 'Atelier animé par une intervenante en langue des signes.']:
   self.assertFalse(any(x['value'] is True for x in t.explicit_features(text,'https://example.org',h,True).values()),text)
  self.assertTrue(t.explicit_features('Accès PMR.','https://example.org',h)['motor']['value'])
  self.assertTrue(t.explicit_features('Visite interprétée en LSF.','https://example.org',h,True)['hearing']['value'])
  self.assertIsNone(t.explicit_features('Visite interprétée en LSF.','https://example.org',h,False)['hearing']['value'])
 def test_conflicting_date_is_quarantined(self):
  self.assertEqual(t.parse_sirtaqui([regional(DESCRIPTIF='Vendredi 30 octobre 2026 à 20 h, le théâtre accueille un spectacle.')],{'79'},NOW,END,h,{}),[])
 def test_direct_national_flag_without_venue_inheritance(self):
  url='https://data.datatourisme.fr/1/example';row={'Nom_du_POI':'Exposition','URI_ID_du_POI':url,'Code_postal_et_commune':'97400#Saint-Denis','Periodes_regroupees':'2026-11-15<->2026-11-15','Description':'Tout public.'}
  self.assertEqual(t.parse_datatourisme([row],{'974'},NOW,END,h),[])
  index={'updatedAt':'2026-11-10','values':{url:True,'https://data.datatourisme.fr/venue':True}}
  r=t.parse_datatourisme([row],{'974'},NOW,END,h,index)[0]
  self.assertEqual(r['timezone'],'Indian/Reunion');self.assertTrue(r['features']['motor']['value'])
  index['values'].pop(url);self.assertEqual(t.parse_datatourisme([row],{'974'},NOW,END,h,index),[])
 def test_corsica_is_resolved_by_commune_and_com_are_not_drom(self):
  url='https://data.datatourisme.fr/1/event';r={'Nom_du_POI':'Fête','URI_ID_du_POI':url,'Code_postal_et_commune':'20000#Ajaccio','Periodes_regroupees':'2026-11-15<->2026-11-15','Description':'Accès PMR.'}
  records=t.parse_datatourisme([r],{'2A','2B'},NOW,END,h,corsica={('20000','ajaccio'):'2A'})
  self.assertEqual(records[0]['department'],'2A')
  self.assertEqual(t.parse_datatourisme([{**r,'Code_postal_et_commune':'97150#Saint-Martin'}],{'971'},NOW,END,h),[])
 def test_same_place_distinct_adaptations_remain_separate(self):
  a=t.parse_sirtaqui([regional(AD1='Salle des fêtes',LAT='46',LON='-0.1')],{'79'},NOW,END,h,{})[0]
  b={**a,'id':'second','features':{**a['features'],'hearing':h.declared(True,'LSF','https://example.org')}}
  self.assertEqual(len(t.consolidate([a,b],h)),2)
  b={**a,'id':'second','timings':[dict(a['timings'][0])]}
  merged=t.consolidate([a,b],h);self.assertEqual(len(merged),1);self.assertEqual(len(merged[0]['timings']),1);self.assertEqual(len(merged[0]['sourceEntries']),2)
if __name__=='__main__':unittest.main()
