import assert from 'node:assert/strict';
import {cardMarkup,contacts,declaredNeeds} from '../dist/signage.mjs';
const record={id:'test',type:'event',title:'Atelier <test>',city:'Niort',features:{motor:{value:true,label:'Accès déclaré'},hearing:{value:false},autism:{value:null}},website:'https://example.org/lieu',phone:'+33 (0)5 49 00 00 00',email:'sorties@example.org'};
assert.deepEqual(declaredNeeds(record),['motor']);
assert.deepEqual(contacts(record),{website:'https://example.org/lieu',phone:'+33549000000',email:'sorties@example.org'});
assert.deepEqual(contacts({...record,website:'javascript:alert(1)',phone:'<script>123456789</script>',email:'x@example.org\r\nBcc:evil@example.org'}),{website:null,phone:null,email:null});
const html=cardMarkup(record,{timing:'15 octobre · 10:00',selectedNeed:'autism'});
assert.ok(html.includes('tel:+33549000000'));assert.ok(html.includes('mailto:sorties%40example.org'));
assert.ok(html.includes('aria-haspopup="dialog"'));assert.ok(html.includes('data-open="test"'));
assert.ok(html.includes('Atelier &lt;test&gt;'));assert.ok(html.includes('>Auditif<'));assert.ok(html.includes('Autisme : à vérifier'));
const badges=[...html.matchAll(/<li class="need-sign need-sign--(\w+)" data-need="(\w+)"[^>]*>(.*?)<\/li>/gs)];
assert.deepEqual(badges.map(b=>[b[2],b[1]]),[['motor','declared'],['hearing','unavailable'],['visual','unknown'],['mental','unknown'],['autism','unknown'],['psychic','unknown']]);
for(const badge of badges){
 const [marker,label]=badge[1]==='declared'?['✓','Adaptation déclarée']:badge[1]==='unavailable'?['−','Indiqué non adapté']:['?','Non renseigné'];
 assert.ok(badge[3].includes(`aria-hidden="true">${marker}</span>`));
 assert.ok(badge[3].includes(`class="sr-only"> : ${label} par la source`));
}
assert.equal((cardMarkup({...record,features:undefined}).match(/need-sign--unknown/g)||[]).length,6);
assert.ok(!cardMarkup({...record,features:{motor:{value:'true'}}}).includes('need-sign--declared'));
const missing=cardMarkup({...record,website:null,phone:null,email:null});
assert.ok(!missing.includes('href='));assert.ok(missing.includes('>Info<'));
assert.ok(!missing.includes('Âges accueillis : à vérifier'));
assert.equal(cardMarkup({...record,features:{motor:{value:true},autism:{value:null,label:'À vérifier'}}}),cardMarkup({...record,features:{motor:{value:true},autism:{value:null}}}),'Compacting unknown labels must not change the displayed card');
console.log('Signage: six fixed icons, declared/unknown/negative states, accessible labels, safe contacts and Info action passed.');
