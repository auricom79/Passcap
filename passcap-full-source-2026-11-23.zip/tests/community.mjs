import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {createCommunityHandler} from '../worker/community.mjs';
import {sqliteD1} from './helpers/sqlite-d1.mjs';
const origin='https://passcap.org',client='123456-test.apps.googleusercontent.com';
const digest=async s=>Buffer.from(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))).toString('hex');
const key=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
const jwk={...await crypto.subtle.exportKey('jwk',key.publicKey),kid:'test-key',alg:'RS256',use:'sig'};
const event={id:'event-1',type:'event',title:'Sortie de test',city:'Bordeaux',department:'33',timezone:'Europe/Paris',sourceUrl:'https://example.com/event',timings:[{start:'2027-01-01T12:00:00Z',end:'2027-01-01T15:00:00Z'}]};
async function jwt(nonce,extra={}){const b=v=>Buffer.from(JSON.stringify(v)).toString('base64url'),body=b({alg:'RS256',kid:'test-key'})+'.'+b({iss:'https://accounts.google.com',aud:client,sub:'google-user',email:'test@example.com',email_verified:true,iat:Math.floor(Date.now()/1000),exp:Math.floor(Date.now()/1000)+3600,nonce,...extra});return body+'.'+Buffer.from(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key.privateKey,new TextEncoder().encode(body))).toString('base64url');}
function fixture(){const DB=sqliteD1();for(const name of readdirSync(new URL('../drizzle',import.meta.url)).filter(x=>x.endsWith('.sql')).sort())DB.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));const env={DB,GOOGLE_CLIENT_ID:client},route=createCommunityHandler();let catalog=true;
 const request=(path,method='GET',body,cookie='',requestOrigin=origin)=>route(new Request(origin+'/api/community/'+path,{method,headers:{...(requestOrigin?{Origin:requestOrigin}:{}),...(body===undefined?{}:{'Content-Type':'application/json'}),Cookie:cookie,'CF-Connecting-IP':'192.0.2.1'},...(body===undefined?{}:{body:JSON.stringify(body)})}),env,async id=>catalog&&id===event.id?event:null);
 async function login(subject='google-user'){
  const challenge=await request('google/challenge','POST',{}),c=await challenge.json(),cookie=challenge.headers.get('set-cookie').split(';')[0];
  const response=await request('google','POST',{nonce:c.nonce,credential:await jwt(c.nonce,{sub:subject,email:subject+'@example.com'})},cookie);assert.equal(response.status,200,JSON.stringify(await response.clone().json()));const user=(await response.json()).user;return {user,cookie:response.headers.getSetCookie().find(c=>c.startsWith('__Host-pc_session')).split(';')[0],response};
 }
 return {DB,env,request,login,removeEvent:()=>catalog=false};}
const originalFetch=globalThis.fetch;
globalThis.fetch=async (url,options)=>{assert.equal(String(url),'https://www.googleapis.com/oauth2/v3/certs');assert.equal(options.redirect,'manual','Workers rejects redirect:error; redirects must be returned and rejected by the status check');return Response.json({keys:[jwk]});};
process.on('exit',()=>{globalThis.fetch=originalFetch;});
test('Google signed identity, cookie binding, nonce replay, issuer and audience',async()=>{
 const f=fixture();try{
  let c=await f.request('google/challenge','POST',{}),d=await c.json(),browser=c.headers.get('set-cookie').split(';')[0];
  assert.equal((await f.request('google','POST',{nonce:d.nonce,credential:await jwt(d.nonce)})).status,401);
  assert.equal((await f.request('google','POST',{nonce:d.nonce,credential:await jwt(d.nonce,{aud:'other-client'})},browser)).status,401);
  assert.equal((await f.request('google','POST',{nonce:d.nonce,credential:await jwt(d.nonce,{iss:'https://evil.example'})},browser)).status,401);
  assert.equal((await f.request('google','POST',{nonce:d.nonce,credential:await jwt(d.nonce,{email_verified:false})},browser)).status,401);
  const invalid=(await jwt(d.nonce)).split('.');invalid[2]='aaaa';assert.equal((await f.request('google','POST',{nonce:d.nonce,credential:invalid.join('.')},browser)).status,401);
  const credential=await jwt(d.nonce),result=await f.request('google','POST',{nonce:d.nonce,credential},browser);assert.equal(result.status,200);assert.match(result.headers.get('set-cookie'),/HttpOnly; Secure; SameSite=Lax/);
  assert.equal((await f.request('google','POST',{nonce:d.nonce,credential},browser)).status,401);
  const cookies=result.headers.getSetCookie(),session=cookies.find(c=>c.startsWith('__Host-pc_session')).split(';')[0],token=session.split('=')[1];
  const row=await f.DB.prepare('SELECT token_hash FROM community_sessions').first();assert.notEqual(row.token_hash,token);assert.equal(row.token_hash,await digest(token));
  assert.equal((await f.request('me','GET',undefined,session)).status,200);
  await f.request('logout','POST',{},session);assert.equal((await (await f.request('me','GET',undefined,session)).json()).user,null);
 }finally{f.DB.close();}
});
test('profiles, private favorites, visibility opt-in, duplicate prevention, expired catalog removal',async()=>{
 const f=fixture();try{
  const a=await f.login('a'),b=await f.login('b');
  assert.equal((await f.request('profile','PATCH',{pseudo:'Hacker'},a.cookie,'https://evil.example')).status,403);
  assert.equal((await f.request('profile','PATCH',{pseudo:'Hacker'},a.cookie,null)).status,403);
  assert.equal((await f.request('marks')).status,401);
  assert.equal((await f.request('profile','PATCH',{pseudo:'A',avatar:'sun'},a.cookie)).status,400);
  assert.equal((await f.request('profile','PATCH',{pseudo:'Alice',avatar:'data:image/svg+xml;base64,YQ=='},a.cookie)).status,400);
  assert.equal((await f.request('profile','PATCH',{pseudo:'Alice',avatar:'data:image/png;base64,YQ=='},a.cookie)).status,400);
  assert.equal((await f.request('profile','PATCH',{pseudo:'Alice',avatar:'leaf'},a.cookie)).status,200);
  const body={favorite:true,interested:true,visible:false};
  assert.equal((await f.request('event?id=event-1','PATCH',body,a.cookie)).status,200);await f.request('event?id=event-1','PATCH',body,a.cookie);
  assert.equal((await (await f.request('marks','GET',undefined,a.cookie)).json()).items.length,1);
  assert.equal((await (await f.request('marks','GET',undefined,b.cookie)).json()).items.length,0);
  let publicState=await (await f.request('event?id=event-1')).json();assert.equal(publicState.interestedCount,1);assert.equal(publicState.participants.length,0);assert.equal(publicState.favorite,false);
  await f.request('event?id=event-1','PATCH',{...body,visible:true},a.cookie);publicState=await (await f.request('event?id=event-1')).json();assert.equal(publicState.participants[0].pseudo,'Alice');assert.ok(!JSON.stringify(publicState).includes('a@example.com'));assert.ok(!JSON.stringify(publicState).includes('google_sub'));
  const signed=await (await f.request('event?id=event-1','GET',undefined,a.cookie)).json();assert.equal(signed.favorite,true);
  f.removeEvent();assert.equal((await f.request('event?id=event-1','PATCH',{favorite:false,interested:true,visible:true},a.cookie)).status,200);
  assert.equal((await f.request('event?id=event-1','PATCH',{favorite:true,interested:true,visible:true},a.cookie)).status,404);
  assert.equal((await f.request('event?id=event-1','PATCH',{favorite:false,interested:false,visible:false},a.cookie)).status,200);
 }finally{f.DB.close();}
});
test('discussion ownership, pagination, blocked users, reports and moderation authorization',async()=>{
 const f=fixture();try{
  const a=await f.login('a'),b=await f.login('b');
  assert.equal((await f.request('event?id=event-1','POST',{body:'Bonjour'},a.cookie)).status,403);
  for(const [u,pseudo]of [[a,'Alice'],[b,'Benoît']])await f.request('profile','PATCH',{pseudo,avatar:'sun'},u.cookie);
  assert.equal((await f.request('event?id=missing','POST',{body:'Bonjour'},a.cookie)).status,404);
  assert.equal((await f.request('event?id=event-1','POST',{body:'x'.repeat(2001)},a.cookie)).status,400);
  const posted=await f.request('event?id=event-1','POST',{body:'Bonjour <script>alert(1)</script>'},a.cookie);assert.equal(posted.status,201);const id=(await posted.json()).id;
  assert.equal((await f.request('comments/'+id,'DELETE',{},b.cookie)).status,404);
  assert.equal((await f.request('comments/'+id+'/report','POST',{reason:'Contenu à examiner'},b.cookie)).status,200);
  assert.equal((await f.request('moderation','GET',undefined,b.cookie)).status,403);
  f.env.COMMUNITY_ADMIN_GOOGLE_SUB='a';assert.equal((await (await f.request('moderation','GET',undefined,a.cookie)).json()).items.length,1);
  await f.request('moderation','POST',{commentId:id,hidden:true},a.cookie);assert.equal((await (await f.request('event?id=event-1')).json()).comments.length,0);
  await f.request('moderation','POST',{commentId:id,hidden:false},a.cookie);
  await f.request('blocks','POST',{userId:a.user.id,blocked:true},b.cookie);assert.equal((await (await f.request('event?id=event-1','GET',undefined,b.cookie)).json()).comments.length,0);
  assert.equal((await (await f.request('event?id=event-1')).json()).comments.length,1);
  await f.request('blocks','POST',{userId:a.user.id,blocked:false},b.cookie);
  for(let i=0;i<35;i++)await f.DB.prepare('INSERT INTO community_comments(event_id,user_id,body,created_at) VALUES(?,?,?,?)').bind(event.id,a.user.id,'Message '+i,Date.now()).run();
  const page=await (await f.request('event?id=event-1','GET',undefined,b.cookie)).json();assert.equal(page.comments.length,30);assert.ok(page.before);const older=await (await f.request('event?id=event-1&before='+page.before,'GET',undefined,b.cookie)).json();assert.equal(older.comments.length,6);assert.ok(!older.comments.some(c=>page.comments.some(p=>p.id===c.id)));
  assert.equal((await f.request('comments/'+id,'DELETE',{},a.cookie)).status,200);
 }finally{f.DB.close();}
});
test('account deletion cascades, session expiry, throttling and disabled Google',async()=>{
 const f=fixture();try{
  const a=await f.login();await f.request('profile','PATCH',{pseudo:'Alice',avatar:'sun'},a.cookie);await f.request('event?id=event-1','PATCH',{favorite:true,interested:true,visible:true},a.cookie);await f.request('event?id=event-1','POST',{body:'Message'},a.cookie);
  assert.equal((await f.request('profile','DELETE',{confirm:'no'},a.cookie)).status,400);
  await f.DB.prepare('UPDATE community_sessions SET created_at=?').bind(Date.now()-3600000).run();assert.equal((await f.request('profile','DELETE',{confirm:'SUPPRIMER'},a.cookie)).status,401);
  await f.DB.prepare('UPDATE community_sessions SET created_at=?').bind(Date.now()).run();assert.equal((await f.request('profile','DELETE',{confirm:'SUPPRIMER'},a.cookie)).status,200);
  for(const table of ['community_users','community_sessions','community_marks','community_comments'])assert.equal(await f.DB.prepare('SELECT COUNT(*) n FROM '+table).first('n'),0);
  const b=await f.login('b');await f.DB.prepare('UPDATE community_sessions SET expires_at=1').run();assert.equal((await (await f.request('me','GET',undefined,b.cookie)).json()).user,null);
  for(let i=0;i<25;i++)await f.request('google/challenge','POST',{});assert.equal((await f.request('google/challenge','POST',{})).status,429);
  f.env.GOOGLE_CLIENT_ID='';assert.equal((await (await f.request('config')).json()).google,false);assert.equal((await f.request('google/challenge','POST',{})).status,503);
 }finally{f.DB.close();}
});
test('optional disability categories require consent and never enter public responses',async()=>{
 const f=fixture();try{
  const a=await f.login('a'),b=await f.login('b');const profile={pseudo:'Alice',avatar:'sun',needs:['motor','autism']};
  assert.equal((await f.request('profile','PATCH',profile,a.cookie)).status,400);
  assert.equal((await f.request('profile','PATCH',{...profile,needs:['other'],needsConsent:true},a.cookie)).status,400);
  assert.equal((await f.request('profile','PATCH',{...profile,needs:['motor','motor'],needsConsent:true},a.cookie)).status,400);
  const saved=await f.request('profile','PATCH',{...profile,needsConsent:true},a.cookie);assert.equal(saved.status,200);const own=(await saved.json()).user;assert.deepEqual(own.needs,['motor','autism']);assert.ok(own.needsConsentAt);
  assert.deepEqual((await (await f.request('me','GET',undefined,a.cookie)).json()).user.needs,['motor','autism']);
  await f.request('event?id=event-1','PATCH',{favorite:true,interested:true,visible:true},a.cookie);await f.request('event?id=event-1','POST',{body:'Bonjour !'},a.cookie);
  for(const cookie of ['',b.cookie]){const payload=await (await f.request('event?id=event-1','GET',undefined,cookie)).json();const serialized=JSON.stringify(payload);assert.ok(!serialized.includes('needs'));assert.ok(!serialized.includes('autism'));assert.ok(!serialized.includes('motor'));assert.ok(!serialized.includes('consent'));}
  const cleared=await f.request('profile','PATCH',{...profile,needs:[],needsConsent:false},a.cookie);assert.equal(cleared.status,200);assert.deepEqual((await cleared.json()).user.needs,[]);assert.equal((await (await f.request('me','GET',undefined,a.cookie)).json()).user.needsConsentAt,null);
 }finally{f.DB.close();}
});
test('automatic profile filter preference is private, enabled by default and persisted per account',async()=>{
 const f=fixture();try{
  const a=await f.login('a'),b=await f.login('b');assert.equal((await (await f.request('me','GET',undefined,a.cookie)).json()).user.autoFilter,true);
  assert.equal((await f.request('preferences','PATCH',{autoFilter:false})).status,401);
  assert.equal((await f.request('preferences','PATCH',{autoFilter:'false'},a.cookie)).status,400);
  assert.equal((await f.request('preferences','PATCH',{autoFilter:false},a.cookie,'https://evil.example')).status,403);
  assert.equal((await (await f.request('preferences','PATCH',{autoFilter:false},a.cookie)).json()).user.autoFilter,false);
  assert.equal((await (await f.request('me','GET',undefined,a.cookie)).json()).user.autoFilter,false);
  assert.equal((await (await f.request('me','GET',undefined,b.cookie)).json()).user.autoFilter,true);
  await f.request('preferences','PATCH',{autoFilter:true},a.cookie);assert.equal((await (await f.request('me','GET',undefined,a.cookie)).json()).user.autoFilter,true);
 }finally{f.DB.close();}
});

test('Google key redirects are rejected without following another host',async()=>{
 const f=fixture(),saved=globalThis.fetch;try{
  globalThis.fetch=async(url,options)=>{assert.equal(options.redirect,'manual');return new Response(null,{status:302,headers:{Location:'https://example.com/untrusted-keys'}});};
  const c=await f.request('google/challenge','POST',{}),d=await c.json(),browser=c.headers.get('set-cookie').split(';')[0];
  const response=await f.request('google','POST',{nonce:d.nonce,credential:await jwt(d.nonce)},browser);
  assert.equal(response.status,503);assert.equal((await response.json()).error,'google_unavailable');
 }finally{globalThis.fetch=saved;f.DB.close();}
});

test('listing activity exposes anonymous totals only and excludes hidden comments',async()=>{
 const f=fixture();try{
  const a=await f.login('stats-a'),b=await f.login('stats-b');
  await f.request('event?id=event-1','PATCH',{favorite:true,interested:true,visible:false},a.cookie);
  await f.request('event?id=event-1','PATCH',{favorite:false,interested:true,visible:false},b.cookie);
  await f.DB.prepare("INSERT INTO community_comments(event_id,user_id,body,created_at,hidden) VALUES('event-1',?,'Visible',?,0),('event-1',?,'Hidden',?,1)").bind(a.user.id,Date.now(),b.user.id,Date.now()).run();
  const response=await f.request('stats','POST',{ids:['event-1','missing','event-1']});assert.equal(response.status,200);
  const body=await response.json();assert.deepEqual(body.items,[{id:'event-1',interested:2,favorites:1,comments:1},{id:'missing',interested:0,favorites:0,comments:0}]);
  assert.ok(!JSON.stringify(body).includes(a.user.id));assert.ok(!JSON.stringify(body).includes('stats-a@example.com'));
  await f.request('event?id=event-1','PATCH',{favorite:false,interested:false,visible:false},a.cookie);
  assert.equal((await (await f.request('stats','POST',{ids:['event-1']})).json()).items[0].favorites,0);
  assert.equal((await f.request('stats','POST',{ids:Array(101).fill('event-1')})).status,400);
 }finally{f.DB.close();}
});
