import {test} from 'node:test';
import assert from 'node:assert/strict';
import {seoResponse} from '../worker/runtime.mjs';
const now=Date.parse('2026-11-18T12:00:00Z');
const row={id:'event-test',type:'event',title:'Une sortie </script><script>bad()</script>',city:'Niort',venue:'Le musée',department:'79',description:'Une rencontre & une visite',status:1,sourceUrl:'https://example.org/',features:{motor:{value:true}},timings:[{start:'2026-11-21T12:00:00Z',end:'2026-11-21T18:00:00Z'}]};
const snapshot={catalog:{departments:[{code:'79',nom:'Deux-Sèvres'}]},departments:{79:{records:[row,{...row,id:'event-2',title:'Deuxième sortie',features:{motor:{value:true},hearing:{value:true}}},{...row,id:'event-3',title:'Troisième sortie',features:{motor:{value:true}}},{...row,id:'expired',timings:[{start:'2026-01-01',end:'2026-01-02'}]}]}}};
test('public SEO pages escape catalogue content, expose canonical URLs and structured dates',async()=>{
 const r=seoResponse(snapshot,new URL('https://passcap.org/evenements/fiche/event-test'),now),html=await r.text();assert.equal(r.status,200);assert.ok(html.includes('Une sortie &lt;/script&gt;'));assert.ok(!html.includes('<script>bad()'));assert.ok(html.includes('https://passcap.org/evenements/fiche/event-test'));
 const data=JSON.parse(html.match(/<script type="application\/ld\+json">(.*?)<\/script>/s)[1]);assert.equal(data.name,row.title);assert.equal(data.startDate,row.timings[0].start);assert.equal(data.location.address.addressLocality,'Niort');
 const sitemap=await seoResponse(snapshot,new URL('https://passcap.org/sitemap.xml'),now).text();assert.ok(sitemap.includes('/evenements/fiche/event-test'));assert.ok(!sitemap.includes('expired'));
 assert.equal(seoResponse(snapshot,new URL('https://passcap.org/evenements/fiche/expired'),now).status,404);
 assert.equal(seoResponse(snapshot,new URL('https://passcap.org/evenements/departement/79?page=999'),now).status,404);
 const list=await seoResponse(snapshot,new URL('https://passcap.org/evenements/departement/79'),now).text();assert.ok(list.includes('href="/evenements/fiche/event-test"'));
 const city=await seoResponse(snapshot,new URL('https://passcap.org/evenements/ville/niort'),now).text();assert.ok(city.includes('Sorties et événements à Niort'));assert.ok(!city.includes('noindex,follow'));
 const motor=await seoResponse(snapshot,new URL('https://passcap.org/evenements/handicap/mobilite'),now).text();assert.ok(motor.includes('Mobilité et déplacement'));assert.ok(!motor.includes('noindex,follow'));
 const hearing=await seoResponse(snapshot,new URL('https://passcap.org/evenements/ville/niort/handicap/audition'),now).text();assert.ok(hearing.includes('noindex,follow'));
 const departmentNeed=await seoResponse(snapshot,new URL('https://passcap.org/evenements/departement/79/handicap/mobilite'),now).text();assert.ok(departmentNeed.includes('Deux-Sèvres'));
 assert.ok(sitemap.includes('/evenements/ville/niort'));assert.ok(sitemap.includes('/evenements/handicap/mobilite'));assert.ok(!sitemap.includes('/evenements/handicap/audition'));
});
