ALTER TABLE community_users ADD COLUMN needs_json TEXT NOT NULL DEFAULT '[]';
ALTER TABLE community_users ADD COLUMN needs_consent_at INTEGER;
