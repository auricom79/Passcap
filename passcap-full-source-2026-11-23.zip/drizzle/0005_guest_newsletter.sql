CREATE TABLE newsletter_guests (id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, department TEXT NOT NULL, consent_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE newsletter_guest_tokens (token_hash TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, department TEXT NOT NULL, expires_at INTEGER NOT NULL);
CREATE TABLE newsletter_guest_deliveries (guest_id TEXT NOT NULL REFERENCES newsletter_guests(id) ON DELETE CASCADE, week_key TEXT NOT NULL, status TEXT NOT NULL, lease_until INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(guest_id,week_key));
CREATE INDEX newsletter_guest_token_expiry ON newsletter_guest_tokens(expires_at);
