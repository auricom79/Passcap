CREATE TABLE community_passwords (user_id TEXT PRIMARY KEY REFERENCES community_users(id) ON DELETE CASCADE, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, salt TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, verified_at INTEGER NOT NULL);
CREATE TABLE community_email_tokens (token_hash TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('signup','password','reset')), user_id TEXT NOT NULL, email TEXT NOT NULL, password_hash TEXT, salt TEXT, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL);
CREATE INDEX community_email_tokens_expiry ON community_email_tokens(expires_at);
CREATE UNIQUE INDEX community_email_tokens_target ON community_email_tokens(email,kind);
