# Pass Cap — Métropole et DROM

MVP web pour les familles et les proches de personnes en situation de handicap. Carte interactive des 96 départements métropolitains et des 5 DROM, agrandissement de Paris et de la petite couronne, sélection par liste utilisable au clavier. Un département charge uniquement son jeu de données. Les filtres commune, tranche d’âge, besoin et texte restent combinables ; l’agenda et les fiches conservent leurs sources.

## Ouvrir et développer

```sh
python3 -m http.server 8765 --bind 127.0.0.1 --directory dist
```

Ouvrir http://127.0.0.1:8765/. HTML/CSS/JavaScript natifs, sans clé d’API ni compte applicatif. La publication Sites conserve son accès privé. Les liens `?departement=971` ouvrent directement un territoire.

`dist/carte.html` est une carte autonome : géométrie et nombres de fiches sont intégrés, elle fonctionne hors connexion. Les liens vers les résultats nécessitent Internet et l’accès au site privé. Générer cette carte après un import avec `node scripts/export-map.mjs`.

## Import national

```sh
python3 -m venv .sites-runtime/data-venv
.sites-runtime/data-venv/bin/pip install -r scripts/requirements-data.txt
.sites-runtime/data-venv/bin/python3 scripts/import-data.py
node scripts/export-map.mjs
node tests/national.mjs
node tests/content-policy.mjs
```

`--cached` réserve la réutilisation des fichiers dans `.sites-runtime/national` au développement. Pour un nouvel import daté, lancer sans ce drapeau afin de retélécharger les sources. Le processus quotidien importe et vérifie les données, puis utilise `scripts/push-data.py` pour les enregistrer dans le stockage du Site sans republication. Voir `DAILY_UPDATE.md`.

- **Acceslibre** : export officiel Parquet via data.gouv.fr. Catégories culture, loisirs et information touristique ; les autres établissements ne sont pas importés. Attribution et URL d’origine sur chaque fiche. La date fournie est celle de l’export, pas une date de contrôle terrain.
- **OpenAgenda** : catalogue national public diffusé par Huwise (anciennement Opendatasoft), téléchargé via son API d’export sans clé. Seules les séances en cours ou futures des 90 jours suivant l’import sont gardées. Les événements annulés, reportés, complets ou exclusivement en ligne sont exclus. Les identifiants sont dédupliqués. Les descriptions de plus de 2 400 caractères sont abrégées et signalées, avec lien vers l’original.
- **Que Faire à Paris / Nantes Métropole** : API publiques d’agendas avec champs d’accessibilité par manifestation. Occurrences, contacts et catégories sont conservés. Les fiches sans adaptation restent exclues. Les doublons Nantes/OpenAgenda sont rapprochés par l’identifiant officiel quand il est fourni.
- **PSG / Opéra national de Paris** : dates et lieux issus des calendriers officiels. Matchs au Parc des Princes avec horaire annoncé ; représentations à Bastille et Garnier. Les conditions de réservation adaptée ont leur propre source. Audiodescription et Relax ne sont appliqués qu’aux séances signalées, sans généralisation aux autres séances ou visites des bâtiments.
- **Culture Relax** : flux public utilisé par le site officiel, pour les séances de cinéma et de spectacle vivant. Les séances sans œuvre annoncée sont exclues ; aucune affiche ni description d’œuvre n’est copiée. Les liens pointent vers la séance chez l’organisateur. Les adaptations Relax ne deviennent pas des affirmations sur l’accès moteur ou sensoriel.
- **Découpage** : noms et codes issus de geo.api.gouv.fr. Géométrie de France GeoJSON, IGN Admin Express 2018 sous Licence Ouverte ; simplifiée pour l’affichage. Le rattachement utilise le code INSEE, puis le nom du département, puis le code postal quand le pays est identifié. Les cas non rattachables sont exclus. La Corse conserve les codes 2A et 2B.
- **Fuseaux** : Europe/Paris ; America/Guadeloupe ; America/Martinique ; America/Cayenne ; Indian/Reunion ; Indian/Mayotte.

La couverture est non exhaustive et inégale, particulièrement dans les DROM. Les nombres sur la carte sont ceux de l’import, avant filtres ; les séances expirées sont masquées à la consultation.

- **DATAtourisme national** : export CSV Fêtes et manifestations des offices de tourisme, toutes régions et DROM examinés. Le graphe complet RDF fournit les indicateurs PMR manquants dans le CSV simplifié. L’indicateur doit appartenir à la manifestation elle-même. Les labels précis et quelques formulations explicites complètent l’information ; une mention du handicap dans un tarif, une intrigue ou une cause défendue ne suffit pas. L’archive complète est lue en flux, puis supprimée au profit d’un index compact vérifié contre les métadonnées à chaque import. La date de cet export d’accessibilité est conservée et affichée dans le détail de l’adaptation.
- **SIRTAQUI** : flux ouvert des fêtes et manifestations du réseau Nouvelle-Aquitaine. Le champ PMR et les labels par déficience concernent chaque événement ; heures, créneaux du soir, fermetures et récurrences explicites sont conservés. Les séries à titre/adresse/coordonnées/profil d’accessibilité identiques sont réunies, avec leurs sources par séance. Les déclarations différentes restent séparées. Le doublonnage avec DATAtourisme est résolu par l’identifiant d’origine ou la correspondance unique titre/code postal. Une date explicite en début de description qui contredit les dates structurées met la fiche à l’écart.

La présence d’un agenda touristique ne suffit pas à produire une fiche : l’accessibilité doit être renseignée. Le flux Pays de la Loire a également été examiné le 14 novembre 2026 ; son champ Tourisme & Handicap était vide sur toutes les fiches et n’a pas été utilisé pour inventer des adaptations. Le pipeline national conserve les cinq DROM ; il peut n’y trouver aucune manifestation avec adaptation déclarée dans l’export courant.

Les filtres Cinéma, Théâtre, Expositions, Opéra, Concerts, Sport, Danse, Ateliers et Visites concernent les événements. Les théâtres et cinémas restent également référencés comme lieux via Acceslibre. Le bouton Programme relie les événements connus d’un même lieu sur le nom normalisé, la commune et le département : aucun rapprochement approximatif ni transfert d’accessibilité. Quand aucune séance ne correspond à la période mais que des séances futures existent, « Voir les prochaines dates » sélectionne la période couverte par l’import. Aujourd’hui reste le choix initial. `tests/events.mjs` et `tests/event-sources.py` vérifient ces relations et la portée des adaptations.

## Fidélité et confidentialité

Seules les fiches avec au moins une adaptation `features.*.value === true` sont conservées. Les valeurs inconnues ou négatives ne suffisent pas, même si la case « fiches incomplètes » est cochée. Les annonces de recrutement et offres d’emploi sont écartées par `dist/content-policy.mjs`, utilisé à l’import et à la consultation. Le filtrage recalcule les compteurs par département et par source. Les mots emploi, CV ou alternance isolés ne justifient pas une exclusion : des contre-exemples culturels sont testés.

Une valeur absente reste inconnue. Aucune adaptation à l’autisme n’est déduite d’une adaptation au handicap intellectuel. Les âges 0–11, 12–17 et 18+ sont des conventions de recherche ; le détail conserve les bornes déclarées. Les caractéristiques d’entrée seules ne garantissent pas l’accessibilité de tout le bâtiment. L’utilisateur est invité à confirmer les conditions d’accueil directement auprès du lieu.

Pas de compte applicatif, de profil médical, de réservation, de paiement ni de contribution publique. Les filtres restent en mémoire ; seul le département est reflété dans l’URL. Les fichiers publics sont livrés dans `dist/data/departments`, séparés pour éviter le téléchargement de tout le catalogue. Cache mémoire limité aux cinq territoires récemment consultés ; les réponses arrivées après un changement de département sont ignorées.

## Vérification

`node tests/national.mjs
node tests/content-policy.mjs` vérifie les 101 départements, l’alignement carte/catalogue, les totaux, l’unicité des identifiants, les sources, les filtres âge/adaptation, les codes corses et DROM, les événements expirés et les fuseaux locaux. Vérifier aussi la navigation carte/liste, les résultats vides, le changement rapide de territoire et le rendu mobile avant publication.

## Identité et accessibilité

Identité : logo typographique bleu « pass cap. » avec point brique, signature « Les sorties qui font la différence ! », composition inspirée d’un carnet de sorties. Police Atkinson Hyperlegible servie localement, licence OFL incluse dans `dist/fonts`. La carte autonome intègre les polices sans requête extérieure.

Les contrôles natifs et les cibles de 48 px accompagnent les liens d’évitement, les dialogues natifs, le focus visible et la navigation clavier. La liste de départements fournit une alternative complète aux petites zones de la carte. La pagination focalise la première fiche ajoutée, les réinitialisations d’états vides et les nouvelles tentatives restaurent un point de lecture stable. La carte précède le formulaire dans le document, sur ordinateur et sur mobile ; un lien d’évitement permet d’accéder directement à la recherche. Les préférences de réduction des mouvements et de couleurs forcées sont prises en compte.

Contrôles du 7 octobre 2026 : axe-core 4.14.0 sur accueil/résultats, fiche et sources ; parcours clavier ; largeur 320/390 px ; texte à 200 % à 1280 px ; contrastes de carte calculés séparément (le contraste SVG n’est pas conclu automatiquement par axe). Ces vérifications ne constituent pas une certification de conformité RGAA/WCAG complète ni un test utilisateur avec lecteur d’écran.

## Fiches à pictogrammes

Les cartes affichent le titre, la commune, la date éventuelle, les âges connus, puis les six pictogrammes dans un ordre fixe. Les adaptations explicitement déclarées sont bleues avec une coche ; les informations inconnues sont grises avec « ? », et les indications négatives de la source sont rouges avec « − ». Chaque état possède un libellé pour les lecteurs d’écran, sans dépendre de la couleur. Les pictogrammes sont accompagnés de courts libellés ; une légende dépliable précise leur sens. Les coordonnées disponibles donnent des liens vers le site, `tel:` ou `mailto:`. Info ouvre le dialogue natif avec les détails, les besoins non renseignés et les sources. Les contacts absents ne produisent pas de faux boutons.

Le 12 octobre 2026, les champs publics d’inscription OpenAgenda des événements déjà présents ont permis d’ajouter 645 e-mails et 583 téléphones. Les coordonnées des contributeurs ne sont pas utilisées. L’import lit désormais le champ `registration` pour conserver cette extraction. La date de consultation de ces coordonnées est conservée par fiche.

`node tests/signage.mjs` contrôle les adaptations réellement déclarées, les coordonnées absentes, les protocoles autorisés, l’échappement et les attributs de l’action Info. Les tests nationaux et de sélection restent applicables. La vérification visuelle de cette évolution n’a pas pu être menée le 12 octobre : navigateur intégré indisponible et Mac verrouillé.

## Recherche par date

Aujourd’hui est sélectionné à l’ouverture et à la réinitialisation. Les autres choix sont Demain, Cette semaine (jusqu’au dimanche inclus), une date et une période dont les deux bornes sont incluses. Les calculs suivent le fuseau de chaque territoire, y compris dans les DROM, et les jours calendaires lors des changements d’heure. Le filtrage recherche toutes les séances d’un événement, puis utilise la première séance correspondante pour le tri et l’affichage. Les événements sur plusieurs jours sont retenus si leur durée recoupe la période ; une fin à minuit n’occupe pas le lendemain. Les séances terminées restent masquées.

La date s’applique aux événements dans Agenda et Tout explorer. Les lieux ne sont pas filtrés par date, car les sources ne fournissent pas leurs horaires d’ouverture ; la recherche le précise. La période est désactivée dans l’onglet Les lieux. Les champs date utilisent des contrôles natifs avec libellés, et une période inversée affiche une erreur.

Vérifications du 13 novembre 2026 : `node tests/dates.mjs`, tests nationaux, politique de sélection et signalétique, syntaxe JavaScript et structure HTML. La vérification visuelle n’a pas été possible : l’usage du navigateur local est désactivé dans les réglages Work.

## Actualisation en ligne

Le serveur Worker conserve l’interface existante et sert les catalogues depuis le binding R2 `BUCKET`. Le catalogue embarqué sert de secours avant la première écriture. La route de mise à jour s’appuie sur l’accès de service Sites du Site strictement privé ; avant tout élargissement de l’audience, ajouter une autorisation propre à cette route. Les jetons ne sont jamais enregistrés dans le dépôt ou le navigateur.

`scripts/build-worker.mjs` produit `dist/server/index.js` ; `npm run build` ne demande aucune dépendance JavaScript. Les imports quotidiens sont validés puis remplacés atomiquement ; une erreur n’écrase pas l’import précédent. `tests/updater.mjs` contrôle l’enregistrement, la lecture, le rejet d’un import incomplet ou ancien et l’idempotence. `DAILY_UPDATE.md`, également accessible par `/api/update-guide`, décrit la procédure autonome.
