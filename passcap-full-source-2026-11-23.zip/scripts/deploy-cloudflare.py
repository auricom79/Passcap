#!/usr/bin/env python3
"""Deploy the prepared direct Cloudflare release without exposing credentials.
Uses an existing API token or Wrangler login. No login, permission or DNS changes.
"""
import argparse,base64,hashlib,json,mimetypes,os,pathlib,re,secrets,sys,urllib.request,urllib.error,uuid
parser=argparse.ArgumentParser();parser.add_argument('--config',required=True);parser.add_argument('--account-id',required=True);args=parser.parse_args()
root=pathlib.Path(__file__).resolve().parents[1];config=json.loads(pathlib.Path(args.config).read_text());account=args.account_id
if not re.fullmatch(r'[a-f0-9]{32}',account):raise SystemExit('Invalid account ID')
token=os.environ.get('CLOUDFLARE_API_TOKEN')
if not token:
 text=(pathlib.Path.home()/'Library/Preferences/.wrangler/config/default.toml').read_text();m=re.search(r'^oauth_token\s*=\s*"([^\"]+)"',text,re.M)
 if not m:raise SystemExit('Existing Cloudflare authentication required')
 token=m.group(1)
base='https://api.cloudflare.com/client/v4/accounts/'+account
class CFError(Exception):pass
def call(endpoint,data=None,method='GET',ctype='application/json',auth=None,allow404=False):
 req=urllib.request.Request(base+endpoint,method=method,data=data,headers={'Authorization':'Bearer '+(auth or token),'Content-Type':ctype})
 try:
  with urllib.request.urlopen(req,timeout=45) as r:result=json.load(r)
 except urllib.error.HTTPError as e:
  if e.code==404 and allow404:return None
  try:messages=json.loads(e.read()).get('errors',[]);codes=[{'code':m.get('code'),'message':m.get('message')} for m in messages]
  except Exception:codes=[]
  raise CFError('Cloudflare HTTP '+str(e.code)+' '+json.dumps(codes))
 if not result.get('success'):raise CFError('Cloudflare rejected operation')
 return result.get('result')
def jcall(endpoint,obj,method='POST'):return call(endpoint,json.dumps(obj).encode(),method)
def multipart(parts):
 boundary='passcap-'+uuid.uuid4().hex;chunks=[]
 for name,filename,mime,blob in parts:
  chunks.extend([('--'+boundary+'\r\n').encode(),('Content-Disposition: form-data; name="'+name+'"'+('; filename="'+filename+'"' if filename else '')+'\r\nContent-Type: '+mime+'\r\n\r\n').encode(),blob,b'\r\n'])
 chunks.append(('--'+boundary+'--\r\n').encode());return b''.join(chunks),'multipart/form-data; boundary='+boundary
name=config['name'];manifest={};files={}
for p in pathlib.Path(config['assets']['directory']).rglob('*'):
 if not p.is_file():continue
 rel='/'+p.relative_to(config['assets']['directory']).as_posix();blob=p.read_bytes();digest=hashlib.sha256(blob+p.suffix.encode()).hexdigest()[:32];manifest[rel]={'hash':digest,'size':len(blob)};files[digest]=(p,blob)
session=jcall('/workers/scripts/'+name+'/assets-upload-session',{'manifest':manifest});jwt=session['jwt'];completion=jwt
for group in session.get('buckets',[]):
 parts=[]
 for digest in group:
  p,blob=files[digest];mime='text/javascript' if p.suffix in ('.js','.mjs') else (mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
  parts.append((digest,digest,mime,base64.b64encode(blob)))
 data,ctype=multipart(parts);uploaded=call('/workers/assets/upload?base64=true',data,'POST',ctype,auth=jwt)
 if uploaded and uploaded.get('jwt'):completion=uploaded['jwt']
 print('Uploaded asset group:',len(group),flush=True)
bindings=[{'type':'assets','name':'ASSETS'}]
for d in config['d1_databases']:bindings.append({'type':'d1','name':d['binding'],'id':d['database_id']})
for b in config['r2_buckets']:bindings.append({'type':'r2_bucket','name':b['binding'],'bucket_name':b['bucket_name']})
for key,value in config.get('vars',{}).items():bindings.append({'type':'plain_text','name':key,'text':str(value)})
existing=call('/workers/scripts/'+name+'/secrets',allow404=True) or []
if not any(s['name']=='CATALOG_UPDATE_TOKEN' for s in existing):bindings.append({'type':'secret_text','name':'CATALOG_UPDATE_TOKEN','text':secrets.token_urlsafe(48)})
if not any(s['name']=='PASSWORD_PEPPER' for s in existing):bindings.append({'type':'secret_text','name':'PASSWORD_PEPPER','text':secrets.token_urlsafe(48)})
metadata={'main_module':'cloudflare/worker.mjs','compatibility_date':config['compatibility_date'],'bindings':bindings,'keep_bindings':['secret_text'],'assets':{'jwt':completion,'config':{'run_worker_first':config['assets']['run_worker_first']}},'logpush':False,'observability':{'enabled':False}}
parts=[('metadata',None,'application/json',json.dumps(metadata).encode())]
for module in ['cloudflare/worker.mjs','worker/runtime.mjs','worker/community.mjs','worker/email-auth.mjs','worker/mail.mjs','worker/newsletter.mjs','dist/content-policy.mjs']:parts.append((module,module,'application/javascript+module',(root/module).read_bytes()))
data,ctype=multipart(parts);result=call('/workers/scripts/'+name,data,'PUT',ctype)
jcall('/workers/scripts/'+name+'/subdomain',{'enabled':False,'previews_enabled':False})
if config.get('triggers',{}).get('crons'):
 jcall('/workers/scripts/'+name+'/schedules',[{'cron':cron} for cron in config['triggers']['crons']],method='PUT')
print(json.dumps({'worker':name,'assets':len(manifest),'deployment_id':result.get('deployment_id'),'modified_on':result.get('modified_on'),'workers_dev':False,'domain_attached':False}))
