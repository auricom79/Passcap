"""SCARE cinema sessions from the current public DataCinesIndes endpoint.

Only a session's declared audio/caption format establishes sensory adaptations.
DCP codes: https://www.isdcf.com/registry/audioconfigs/ and
https://www.isdcf.com/registry/openandclosedcaptions/ . Ordinary ST/VOST never
means captions for deaf viewers. Equipment/activation is not guaranteed.
"""
import datetime,hashlib,json,re,urllib.parse,urllib.request
from zoneinfo import ZoneInfo
BASE='https://datacinesindes.fr/data-fair/api/v1/datasets/programmation-cinemas'
PAGE='https://datacinesindes.fr/datasets/programmation-cinemas'
CATALOG='https://www.data.gouv.fr/api/1/datasets/programmation-des-cinemas-independants/'
SOURCE='SCARE · cinémas indépendants'
ZONES={'971':'America/Guadeloupe','972':'America/Martinique','973':'America/Cayenne','974':'Indian/Reunion','976':'Indian/Mayotte'}
FORMATS={'7.1','5.1','ST','ATMOS','3D','HI','VI','OCAP','CCAP','OPNCAP'}

def safe_url(value):
 try:
  u=urllib.parse.urlparse(value or '')
  return value if u.scheme=='https' and u.hostname and not u.username and not u.password else None
 except (TypeError,ValueError):return None

def iso(value):
 try:
  value=re.sub(r'([+-]\d{2})(\d{2})$',r'\1:\2',str(value))
  d=datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
  return d if d.tzinfo else None
 except ValueError:return None

def adaptations(value):
 tokens=set(re.split(r'[\s,]+',str(value or '').strip().upper()))
 if not tokens or not tokens<=FORMATS:return ()
 return tuple(sorted(tokens & {'HI','VI','OCAP','CCAP','OPNCAP'}))

def department(row,deps,communes):
 postal=str(row.get('cinecp') or '').strip()
 if not re.fullmatch(r'\d{5}',postal) or postal in {'97133','97150'}:return None
 if postal.startswith('20'):
  candidates=[c for c in communes if postal in c.get('codesPostaux',[])]
  exact=[c for c in candidates if c['nom'].casefold()==str(row.get('cineville') or '').casefold()]
  choices={c['codeDepartement'] for c in exact or candidates}
  dep=next(iter(choices)) if len(choices)==1 else None
 else:dep=postal[:3] if postal.startswith('97') else postal[:2]
 return dep if dep in deps else None

def parse_rows(rows,deps,now,until,extra,updated_at,communes=()):
 result={};seen=set()
 for e in rows:
  profile=adaptations(e.get('filmaudio'))
  if not profile:continue
  a,b=iso(e.get('showstart')),iso(e.get('showend'))
  if not a or not b or b<=a or b<=now or a>until:continue
  dep=department(e,deps,communes)
  if not dep or not e.get('filmtitle') or not e.get('cinenom'):continue
  if any(e.get(k) is None for k in ['cineid','filmid','showid','_id']):continue
  event=extra.plain(e.get('evenement'))
  if re.search(r'\b(?:annul[eé]e?s?|report[eé]e?s?)\b',event,re.I):continue
  identity=(str(e['cineid']),str(e['showid']))
  if identity in seen:continue
  seen.add(identity)
  version=extra.plain(e.get('filmversion'))
  key=(str(e['cineid']),str(e['filmid']),version,profile,event)
  proof=BASE+'/lines?'+urllib.parse.urlencode({'size':1,'qs':'_id:'+json.dumps(str(e['_id']))})
  website=safe_url(e.get('showurl'))
  timing={'start':a.isoformat(),'end':b.isoformat(),'sourceUrl':website or proof}
  if key in result:
   result[key]['timings'].append(timing);continue
  title=extra.plain(e['filmtitle'])
  id='scare-'+hashlib.sha256(json.dumps(key,ensure_ascii=False).encode()).hexdigest()[:20]
  r=extra.base(id,title,e['cinenom'],e.get('cineville'),dep,website or PAGE,SOURCE,now)
  features=extra.blank()
  if 'VI' in profile:features['visual']=extra.declared(True,'Piste d’audiodescription (VI) indiquée pour ces séances ; équipement et activation à confirmer au cinéma',proof)
  hearing=[]
  if set(profile)&{'OCAP','OPNCAP'}:hearing.append('Sous-titres adaptés à l’écran (OCAP) indiqués pour ces séances')
  if 'CCAP' in profile:hearing.append('Sous-titres adaptés individuels (CCAP), dispositif à confirmer')
  if 'HI' in profile:hearing.append('Piste de renfort sonore (HI), équipement et activation à confirmer')
  if hearing:features['hearing']=extra.declared(True,' ; '.join(hearing),proof)
  version_label={'VERSION_LOCAL':'VF','VERSION_ORIGINAL_LOCAL':'VF','VERSION_ORIGINAL':'VO','VERSION_MUET':'Film muet'}.get(version,version)
  description='Programmation du cinéma '+extra.plain(e['cinenom'])+'.'
  if e.get('filmdirector'):description+=' Réalisation : '+extra.plain(e['filmdirector'])+'.'
  if version_label:description+=' Version : '+version_label+'.'
  if event:description+=' '+event
  r.update({'features':features,'timings':[timing],'eventKind':'cinema','category':'Cinéma',
            'timezone':ZONES.get(dep,'Europe/Paris'),'producer':extra.plain(e['cinenom']),
            'updatedAt':updated_at,'sourceUpdatedLabel':'Programmation source mise à jour',
            'description':description,'conditions':'Tarifs, réservation et disponibilité des dispositifs à confirmer auprès du cinéma pour la séance choisie.',
            'website':website,'address':' '.join(str(e.get(k) or '') for k in ['cineadresse','cinecp','cineville']).strip(),
            'lat':e.get('_coords.lat'),'lon':e.get('_coords.lon')})
  result[key]=r
 for r in result.values():r['timings'].sort(key=lambda t:iso(t['start']))
 return list(result.values())

def fetch_pages(fetch):
 url=BASE+'/lines?size=1000&sort=showstart';rows=[];visited=set();ids=set();expected=None
 for page in range(100):
  u=urllib.parse.urlparse(url)
  if u.scheme!='https' or u.netloc!='datacinesindes.fr' or not u.path.startswith('/data-fair/api/v1/datasets/') or not u.path.endswith('/lines') or url in visited:
   raise ValueError('Unexpected SCARE pagination URL')
  visited.add(url);payload=fetch('page-'+str(page)+'.json',url)
  if page==0:
   expected=payload.get('total')
   if not isinstance(expected,int) or expected<1:raise ValueError('SCARE catalogue unexpectedly empty')
  batch=payload.get('results')
  if not isinstance(batch,list):raise ValueError('Invalid SCARE page')
  for row in batch:
   if not row.get('_id') or row['_id'] in ids:raise ValueError('Duplicate or missing SCARE row identifier')
   ids.add(row['_id'])
  rows.extend(batch);url=payload.get('next')
  if not url:
   if len(rows)!=expected:raise ValueError('Truncated SCARE catalogue')
   return rows
  if not batch:raise ValueError('Empty intermediate SCARE page')
 raise ValueError('SCARE pagination limit reached')

def collect(deps,now,until,cache,cached=False,extra=None):
 folder=cache/'scare';folder.mkdir(exist_ok=True)
 def fetch(name,url):
  p=folder/name
  if not cached or not p.exists():
   req=urllib.request.Request(url,headers={'User-Agent':'PassCap/1.4 public cinema programme importer'})
   with urllib.request.urlopen(req,timeout=90) as f:content=f.read()
   d=json.loads(content);temp=p.with_suffix('.tmp');temp.write_bytes(content);temp.replace(p)
  else:d=json.loads(p.read_text())
  return d
 catalog=fetch('catalog.json',CATALOG)
 if catalog.get('license')!='lov2':raise ValueError('SCARE open licence changed')
 metadata=fetch('metadata.json',BASE)
 expected={'filmtitle','filmaudio','showstart','showend','showid','filmid','cineid','cinecp'}
 if not expected<={f['key'] for f in metadata.get('schema',[])}:raise ValueError('SCARE schema changed')
 updated=metadata.get('dataUpdatedAt')
 if not iso(updated):raise ValueError('SCARE freshness is unknown')
 if now-iso(updated)>datetime.timedelta(days=3):raise ValueError('SCARE daily source is stale')
 rows=fetch_pages(fetch)
 latest=fetch('metadata-after.json',BASE)
 if latest.get('dataUpdatedAt')!=updated:raise ValueError('SCARE changed during pagination; retry the complete import')
 communes=[]
 if any(str(e.get('cinecp') or '').startswith('20') for e in rows):
  for dep in ['2A','2B']:
   communes+=fetch('communes-'+dep+'.json','https://geo.api.gouv.fr/departements/'+dep+'/communes?fields=nom,codeDepartement,codesPostaux')
 records=parse_rows(rows,deps,now,until,extra,updated,communes)
 sources=[{'name':SOURCE,'recordSource':SOURCE,'url':PAGE,'description':'Séances des cinémas indépendants : seules les versions annonçant VI (audiodescription), HI (renfort sonore) ou des sous-titres adaptés sont retenues. Équipement et activation à confirmer auprès du cinéma.','license':'Licence Ouverte 2.0','licenseUrl':'https://www.data.gouv.fr/datasets/programmation-des-cinemas-independants','updatedAt':updated,'count':len(records)}]
 print('SCARE:',len(records),'programmes,',sum(len(r['timings']) for r in records),'sessions,',len({r['department'] for r in records}),'departments.',flush=True)
 return records,sources
