"""Public tourism-office agendas. Keep only explicitly documented adaptations."""
import concurrent.futures
import csv
import datetime as dt
import hashlib
import json
import pathlib
import re
import shutil
import urllib.parse
import urllib.request
import zipfile
from zoneinfo import ZoneInfo

DATASET = 'https://www.data.gouv.fr/api/1/datasets/datatourisme-la-plateforme-nationale-des-donnees-touristiques/'
DATASET_PAGE = 'https://www.data.gouv.fr/datasets/datatourisme-la-plateforme-nationale-des-donnees-touristiques'
SIRTAQUI = 'https://wcf.tourinsoft.com/Syndication/aquitaine/99727cfe-b4f0-4e35-9bbc-dbedf67b0348/'
SIRTAQUI_PAGE = 'https://www.data.gouv.fr/datasets/fetes-et-manifestation-en-aquitaine'
ZONES = {'971':'America/Guadeloupe','972':'America/Martinique','973':'America/Cayenne','974':'Indian/Reunion','976':'Indian/Mayotte'}
DAYS = ['lundi','mardi','mercredi','jeudi','vendredi','samedi','dimanche']
LABELS = {'motor':'moteur','hearing':'auditif','visual':'visuel','mental':'mental'}


def extract_access_index(archive):
    """Scan the national graph without extracting its 13+ GiB onto disk.

    Only a flag on the event's own URI can be used. A flag on its building,
    organiser or another related resource is never inherited.
    """
    pattern=re.compile(rb'^<(https://data\.datatourisme(?:\.gouv)?\.fr/[^>]+)>\s+<https?://www\.datatourisme(?:\.gouv)?\.fr/ontology/core#reducedMobilityAccess>\s+"(true|false|1|0)"')
    origin_pattern=re.compile(rb'^<(https://data\.datatourisme(?:\.gouv)?\.fr/[^>]+)>\s+<http://purl.org/dc/elements/1.1/identifier>\s+"(FMA[A-Za-z0-9_-]+)"')
    values={};identifiers={}
    def accept(line):
        if b'#reducedMobilityAccess>' in line:
            match=pattern.match(line)
            if match:values[match[1].decode().replace('data.datatourisme.gouv.fr','data.datatourisme.fr')]=match[2] in [b'true',b'1']
        elif b'/identifier>' in line:
            match=origin_pattern.match(line)
            if match:identifiers[match[1].decode().replace('data.datatourisme.gouv.fr','data.datatourisme.fr')]=match[2].decode()
    with zipfile.ZipFile(archive) as zipped:
        members=[m for m in zipped.infolist() if m.filename.endswith('.nt')]
        if len(members)!=1:raise ValueError('Unexpected DATAtourisme archive structure')
        with zipped.open(members[0]) as stream:
            rest=b''
            while True:
                block=stream.read(16*1024*1024)
                if not block:break
                lines=(rest+block).split(b'\n');rest=lines.pop()
                for line in lines:accept(line)
            if rest:accept(rest)
    return {'values':values,'identifiers':identifiers}


def department(code, deps):
    code = str(code or '')
    dep = code[:3] if code.startswith('97') else code[:2]
    return dep if dep in deps else None


def safe_url(value):
    for part in re.split(r'[|#\s]+', str(value or '')):
        if urllib.parse.urlparse(part).scheme in ['https','http']:
            return part
    return None


def number(value):
    try: return float(value)
    except (TypeError, ValueError): return None


def day(value):
    for fmt in ['%d/%m/%Y', '%Y-%m-%d']:
        try: return dt.datetime.strptime(value, fmt).date()
        except (ValueError, TypeError): pass
    return None


def hour(value):
    try: return dt.datetime.strptime(value, '%H:%M').time()
    except (ValueError, TypeError): return None


def tourism_period(start, end, zone):
    # Inclusive source dates. No assertion that the event runs every day.
    return {'start':dt.datetime.combine(start, dt.time.min, zone).isoformat(),
            'end':dt.datetime.combine(end + dt.timedelta(days=1), dt.time.min, zone).isoformat(),
            'dateOnly':True, 'endTimeKnown':False}


def closures(value, normalize):
    text = normalize(value)
    found = list(re.finditer(r'\b('+'|'.join(DAYS)+r')\b', text))
    result = {}
    for i, match in enumerate(found):
        suffix = text[match.end():found[i+1].start() if i+1<len(found) else len(text)].strip()
        result.setdefault(DAYS.index(match[1]), []).append(suffix)
    return result


def sirtaqui_timings(row, now, until, helpers):
    zone = ZoneInfo('Europe/Paris')
    output = []
    weekly = re.search(r'hebdomadaire.*?\b('+'|'.join(DAYS)+r')\b', helpers.norm(row.get('NOMOFFRE')))
    weekly_day = DAYS.index(weekly[1]) if weekly else None
    for raw in str(row.get('DATESCOMPLET') or row.get('DATES') or '').split('#'):
        fields = (raw.split('|')+['']*7)[:7]
        start, end = day(fields[0]), day(fields[1])
        if not start or not end or end<start: continue
        if end<now.astimezone(zone).date() or start>until.astimezone(zone).date(): continue
        close = closures(fields[6], helpers.norm)
        slots = [(hour(fields[2]),hour(fields[3])), (hour(fields[4]),hour(fields[5]))]
        slots = [(a,b) for a,b in slots if a is not None]
        # A multi-day period without weekdays is presented as a period, not
        # repeated invented daily sessions. Explicit weekly titles are usable.
        if start!=end and not close and weekly_day is None:
            output.append(tourism_period(start,end,zone))
            continue
        current, last = max(start,now.astimezone(zone).date()), min(end,until.astimezone(zone).date())
        while current<=last:
            blocked = close.get(current.weekday(), [])
            if '' not in blocked and (weekly_day is None or weekly_day==current.weekday()):
                if not slots:
                    output.append(tourism_period(current,current,zone))
                for a,b in slots:
                    # Only completely closed slots are excluded. Ambiguous
                    # partial closures retain a date with hours to confirm.
                    boundaries={'matin':(0,12),'midi':(12,14),'apres midi':(12,18),'soir':(18,24)}
                    overlaps=[boundaries[x] for x in blocked if x in boundaries]
                    endhour=(b.hour+b.minute/60) if b else 24
                    starthour=a.hour+a.minute/60
                    if any(lo<=starthour and endhour<=hi for lo,hi in overlaps): continue
                    if any(starthour<hi and endhour>lo for lo,hi in overlaps):
                        output.append(tourism_period(current,current,zone));continue
                    begin=dt.datetime.combine(current,a,zone)
                    finish=dt.datetime.combine(current,b or dt.time(23,59,59),zone)
                    if finish<begin: finish+=dt.timedelta(days=1)
                    output.append({'start':begin.isoformat(),'end':finish.isoformat(),'endTimeKnown':b is not None})
            current+=dt.timedelta(days=1)
    unique={json.dumps(t,sort_keys=True):t for t in output if helpers.within(t,now,until)}
    return sorted(unique.values(),key=lambda t:helpers.iso(t['start']))


def label_features(text, url, helpers):
    features=helpers.blank()
    for key,label in LABELS.items():
        if re.search(r'handicap\s+'+label+r'\b', helpers.norm(text)):
            features[key]=helpers.declared(True,'Tourisme & Handicap : '+label+' déclaré dans la fiche touristique',url)
    return features


def schedule_conflict(description, timings, helpers):
    """Quarantine a conflicting opening date explicitly stated in the first sentence."""
    text=helpers.norm(description).replace('\\n','\n').strip()
    match=re.match(r'(?:le\s+)?(?:'+'|'.join(DAYS)+r')\s+(\d{1,2})\s+([a-z]+)\s+(20\d{2})\b',text)
    months={helpers.norm(k):v for k,v in helpers.MONTHS.items()}
    if not match or match[2] not in months:return False
    try:announced=dt.date(int(match[3]),months[match[2]],int(match[1]))
    except ValueError:return False
    return not any(helpers.iso(t['start']).date()<=announced<=(helpers.iso(t['end'])-dt.timedelta(microseconds=1)).date() for t in timings)


def consolidate(records, helpers):
    """Group named series at the exact same address, keeping session provenance.

    Different accessibility profiles remain separate: a Relax or LSF session
    must never lend its adaptation to the remainder of a programme.
    """
    groups={}
    for r in records:
        profile=tuple((k,r['features'][k]['value']) for k in sorted(r['features']))
        key=(r['department'],helpers.norm(r['city']).strip(),helpers.norm(r['title']).strip(),helpers.norm(r['address']).strip(),profile)
        if not r['address'] or r['lat'] is None or r['lon'] is None:key=(r['id'],)
        else:key+=(round(r['lat'],5),round(r['lon'],5))
        groups.setdefault(key,[]).append(r)
    result=[]
    for grouped in groups.values():
        if len(grouped)==1:result.extend(grouped);continue
        # Most recently maintained entry supplies practical details.
        chosen=max(grouped,key=lambda r:(r['updatedAt'] or '',r['id'])).copy()
        chosen['id']='sirtaqui-series-'+hashlib.sha256('|'.join(sorted(r['id'] for r in grouped)).encode()).hexdigest()[:20]
        sessions={}
        for r in grouped:
            for t in r['timings']:
                t={**t,'sourceUrl':r['sourceUrl']}
                key=(t['start'],t['end'])
                sessions[key]=t
        exact_days={t['start'][:10] for t in sessions.values() if not t.get('dateOnly')}
        chosen['timings']=sorted((t for t in sessions.values() if not (t.get('dateOnly') and t['start'][:10] in exact_days and helpers.iso(t['end'])-helpers.iso(t['start'])<=dt.timedelta(hours=25))),key=lambda t:t['start'])
        chosen['sourceEntries']=[{'id':r['id'],'url':r['sourceUrl']} for r in grouped]
        chosen['_selectionDescription']='\n'.join(r.get('_selectionDescription','') for r in grouped)
        result.append(chosen)
    return result


def explicit_features(description, url, helpers, single_day=False):
    features=helpers.blank()
    text=helpers.norm(description).replace('\\n','\n')
    # Match access statements, never a benefit, ticket concession, cause,
    # character in a film, or a workshop that merely teaches sign language.
    patterns={
        'motor':r'\b(?:accessible\s+(?:aux?\s+)?(?:personnes\s+(?:a\s+)?)?(?:mobilite reduite|pmr)|accessible\s+(?:en\s+)?fauteuil(?:\s+roulant)?|acces\s+(?:pour\s+les\s+)?pmr)\b',
        'visual':r'\b(?:proposee?s?|adaptee?s?|disponible)\s+(?:en|avec)\s+audiodescription\b',
        'hearing':r'\b(?:visite\s+(?:commentee\s+)?en|visite\s+proposee\s+en|interpretee?\s+en|traduite?s?\s+en)\s+(?:langue des signes(?: francaise)?|lsf)\b'
    }
    for key,pattern in patterns.items():
        # Sensory accommodation announced in prose could apply to only one
        # session of a longer programme. Only an unambiguous single day fits.
        if key!='motor' and not single_day: continue
        for match in re.finditer(pattern,text):
            before=text[max(0,match.start()-100):match.start()]
            clause=re.split(r'[.!?;\n]',before)[-1]
            after=text[match.end():match.end()+100]
            if re.search(r'\b(?:non|pas|sans|inaccessible|impossible|uniquement|seulement|partiellement)\b',clause): continue
            if re.match(r'\s*(?:non|impossible|a confirmer|sauf|hors|uniquement|seulement)\b',after): continue
            features[key]=helpers.declared(True,{'motor':'Accès PMR annoncé dans le descriptif de cet événement','visual':'Audiodescription annoncée pour cette date','hearing':'Langue des signes annoncée pour cette date'}[key],url)
            break
    return features


def parse_datatourisme(rows,deps,now,until,helpers,access_index=None,corsica=None):
    result=[]
    for e in rows:
        postal,_,city=str(e.get('Code_postal_et_commune') or '').partition('#')
        dep=department(postal,deps)
        if postal.startswith('20'):dep=(corsica or {}).get((postal,helpers.norm(city).strip()))
        if postal in ['97133','97150']:continue  # Collectivities outside the five DROM.
        if not dep: continue
        url=e.get('URI_ID_du_POI') or ''
        if not url.startswith('https://data.datatourisme.fr/'): continue
        zone=ZoneInfo(ZONES.get(dep,'Europe/Paris'))
        periods=[];all_periods=[]
        for pair in str(e.get('Periodes_regroupees') or '').split('|'):
            a,sep,b=pair.partition('<->');a,b=day(a),day(b)
            if not sep or not a or not b or b<a: continue
            period=tourism_period(a,b,zone)
            all_periods.append(period)
            if helpers.within(period,now,until): periods.append(period)
        if not periods: continue
        periods=list({t['start']+'|'+t['end']:t for t in periods}.values())
        single=len(periods)==1 and (helpers.iso(periods[0]['end'])-helpers.iso(periods[0]['start']))<=dt.timedelta(hours=25)
        features=label_features(e.get('Classements_du_POI'),url,helpers)
        mobility=(access_index or {}).get('values',{}).get(url)
        if isinstance(mobility,bool):
            updated=access_index['updatedAt'][:10]
            features['motor']=helpers.declared(mobility,'Accès PMR '+('déclaré' if mobility else 'indiqué non adapté')+' dans l’export complet DATAtourisme du '+updated,url)
        descriptive=explicit_features(e.get('Description'),url,helpers,single)
        for k,f in descriptive.items():
            if features[k]['value'] is None: features[k]=f
        if not any(f['value'] is True for f in features.values()): continue
        title=e.get('Nom_du_POI') or ''
        if re.search(r'\bannul[ée]',title,re.I) or schedule_conflict(e.get('Description'),all_periods,helpers): continue
        r=helpers.base('dt-'+url.rsplit('/',1)[-1],title,'',city,dep,url,'DATAtourisme · offices de tourisme',now)
        event_kind=helpers.kind(title)
        r.update({'eventKind':event_kind,'category':helpers.KIND_LABELS[event_kind], 'timezone':str(zone),'features':features,'timings':sorted(periods,key=lambda t:t['start']),'description':helpers.plain(e.get('Description')).replace('\\n','\n')[:900], 'address':e.get('Adresse_postale') or '', 'postalCode':postal,'producer':e.get('Createur_de_la_donnee') or 'Réseau DATAtourisme','updatedAt':e.get('Date_de_mise_a_jour') or now.isoformat(),'sourceUpdatedLabel':'Fiche touristique mise à jour','website':safe_url(e.get('Contacts_du_POI')),'lat':number(e.get('Latitude')),'lon':number(e.get('Longitude')),'scheduleNote':'Dates ou périodes fournies par l’office de tourisme ; jours précis et horaires à vérifier dans la source.'})
        r['_selectionDescription']=helpers.plain(e.get('Description'))
        r['sourceRecordId']=(access_index or {}).get('identifiers',{}).get(url)
        result.append(r)
    return result


def parse_sirtaqui(rows,deps,now,until,helpers,dt_index,origin_index=None):
    result=[]
    for e in rows:
        id=str(e.get('SyndicObjectID') or '')
        if not re.fullmatch(r'[A-Za-z0-9_-]+',id): continue
        dep=department(e.get('COMMUNEINSEE'),deps)
        if not dep: continue
        url=SIRTAQUI+"Objects('"+id+"')?$format=json"
        features=label_features(e.get('HANDICAPLABEL'),url,helpers)
        if e.get('ACCESHANDI') in ['oui','non']:
            value=e['ACCESHANDI']=='oui'
            features['motor']=helpers.declared(value,'Accès aux personnes à mobilité réduite '+('déclaré' if value else 'indiqué non adapté')+' sur la fiche événement SIRTAQUI',url)
        if not any(f['value'] is True for f in features.values()): continue
        timings=sirtaqui_timings(e,now,until,helpers)
        title=e.get('NOMOFFRE') or e.get('SyndicObjectName') or ''
        all_periods=[]
        for raw in str(e.get('DATESCOMPLET') or e.get('DATES') or '').split('#'):
            pair=raw.split('|');a,b=day(pair[0]),day(pair[1]) if len(pair)>1 else None
            if a and b and a<=b:all_periods.append(tourism_period(a,b,ZoneInfo('Europe/Paris')))
        if not timings or re.search(r'\bannul[ée]',title,re.I) or schedule_conflict(e.get('DESCRIPTIF'),all_periods,helpers): continue
        postal=str(e.get('CP') or '')
        matches=(origin_index or {}).get(id) or dt_index.get((helpers.norm(title).strip(),postal),[])
        # The canonical national page is a friendlier source link when unique.
        original=matches[0] if len(matches)==1 else None
        source_url=original['URI_ID_du_POI'] if original else url
        address=' '.join(str(e[k]) for k in ['AD1','AD2','CP','COMMUNE'] if e.get(k))
        venue=helpers.plain(e.get('AD1')) if re.match(r'^(?:th[ée][aâ]tre|cin[ée]ma|salle|mus[ée]e|m[ée]diath[èe]que|biblioth[èe]que|conservatoire|op[ée]ra)\b',str(e.get('AD1') or ''),re.I) else ''
        r=helpers.base('sirtaqui-'+id,title,venue,e.get('COMMUNE'),dep,source_url,'SIRTAQUI · offices de tourisme',now)
        kind=helpers.kind(title,str(e.get('CATFMA') or '')+' '+str(e.get('THEMEFMA') or ''))
        updated=re.search(r'Date\((\d+)\)',str(e.get('Updated')))
        r.update({'eventKind':kind,'category':helpers.KIND_LABELS[kind],'features':features,'timings':timings,'description':helpers.plain(e.get('DESCRIPTIF')).replace('\\n','\n')[:900],'address':address,'postalCode':postal,'producer':(original or {}).get('Createur_de_la_donnee') or e.get('ORGNOM') or 'Réseau SIRTAQUI','phone':str(e.get('TEL') or e.get('TELMOB') or '').split('#')[0] or None,'email':str(e.get('MAIL') or '').split('#')[0] or None,'website':safe_url(e.get('URL')),'lat':number(e.get('LAT')),'lon':number(e.get('LON')),'conditions':helpers.plain(e.get('TARIFS')).replace('#',' · ') or 'Tarif, réservation et conditions d’accueil à confirmer auprès de l’organisateur.','updatedAt':dt.datetime.fromtimestamp(int(updated[1])/1000,dt.timezone.utc).isoformat() if updated else now.isoformat(),'sourceUpdatedLabel':'Fiche touristique mise à jour'})
        if any(t.get('dateOnly') for t in timings):r['scheduleNote']='Dates ou périodes annoncées ; horaires non renseignés à confirmer dans la source.'
        r['_selectionDescription']=helpers.plain(e.get('DESCRIPTIF'))
        r['sourceRecordId']=id
        if original:r['tourismUri']=original['URI_ID_du_POI']
        result.append(r)
    return result


def collect(deps,now,until,cache,cached,helpers):
    folder=cache/'tourism';folder.mkdir(exist_ok=True)
    def fetch(name,url):
        file=folder/name
        if not cached or not file.exists():
            request=urllib.request.Request(url,headers={'User-Agent':'PassCap/1.2 public tourism agenda importer'})
            with urllib.request.urlopen(request,timeout=180) as response,open(str(file)+'.download','wb') as out:shutil.copyfileobj(response,out)
            pathlib.Path(str(file)+'.download').replace(file)
        return file
    metadata=json.loads(fetch('metadata.json',DATASET).read_text())
    resource=next(r for r in metadata['resources'] if r['title']=='datatourisme-fma.csv')
    graph=next(r for r in metadata['resources'] if r['title']=='datatourisme.nt.zip')
    index_path=folder/'access-index.json';access_index=None
    if index_path.exists():
        previous=json.loads(index_path.read_text())
        if previous.get('version')==2 and previous.get('resourceUrl')==graph['url'] and previous.get('updatedAt')==graph['last_modified']:
            access_index=previous
    if access_index is None:
        name='national-'+hashlib.sha256(graph['url'].encode()).hexdigest()[:16]+'.zip'
        archive=folder/name
        if not archive.exists() or archive.stat().st_size!=graph.get('filesize'):
            print('Downloading complete national DATAtourisme accessibility export (streamed ZIP).',flush=True)
            archive=fetch(name,graph['url'])
        access_index={**extract_access_index(archive),'resourceUrl':graph['url'],'updatedAt':graph['last_modified'],'version':2}
        if len(access_index['values'])<1000:raise ValueError('DATAtourisme accessibility graph incomplete')
        temp=index_path.with_suffix('.tmp');temp.write_text(json.dumps(access_index));temp.replace(index_path)
        archive.unlink()
        print('National accessibility index:',len(access_index['values']),'declared flags.',flush=True)
    jobs=[('datatourisme.csv',resource['url']),('sirtaqui.json',SIRTAQUI+'Objects?$format=json'),('corse-sud.json','https://geo.api.gouv.fr/communes?codeDepartement=2A&fields=nom,code,codesPostaux'),('haute-corse.json','https://geo.api.gouv.fr/communes?codeDepartement=2B&fields=nom,code,codesPostaux')]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:files=list(pool.map(lambda pair:fetch(*pair),jobs))
    with open(files[0],encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream))
    payload=json.loads(files[1].read_text());regional=payload.get('d')
    if not isinstance(regional,list) or '__next' in payload:raise ValueError('SIRTAQUI: unexpected format or incomplete pagination')
    if len(rows)<1000 or len(regional)<1000:raise ValueError('Unexpected incomplete tourism export')
    index={};origin_index={}
    for row in rows:
        index.setdefault((helpers.norm(row.get('Nom_du_POI')).strip(),str(row.get('Code_postal_et_commune') or '').split('#')[0]),[]).append(row)
        origin=access_index['identifiers'].get(row.get('URI_ID_du_POI'))
        if origin:origin_index.setdefault(origin,[]).append(row)
    sirtaqui=parse_sirtaqui(regional,deps,now,until,helpers,index,origin_index)
    corsica={}
    for file,dep in zip(files[2:],['2A','2B']):
        for commune in json.loads(file.read_text()):
            for postal in commune.get('codesPostaux',[]):corsica[(postal,helpers.norm(commune['nom']).strip())]=dep
    national=parse_datatourisme(rows,deps,now,until,helpers,access_index,corsica)
    # Prefer the regional record with structured accessibility and exact hours.
    covered={r.get('tourismUri') for r in sirtaqui if r.get('tourismUri')}
    origin_ids={r['sourceRecordId'] for r in sirtaqui}
    national=[r for r in national if r['sourceUrl'] not in covered and r.get('sourceRecordId') not in origin_ids]
    sirtaqui=consolidate(sirtaqui,helpers)
    records=sirtaqui+national
    sources=[{'name':'SIRTAQUI · offices de tourisme','recordSource':'SIRTAQUI · offices de tourisme','url':SIRTAQUI_PAGE,'description':'Agendas des offices de tourisme du réseau Nouvelle-Aquitaine. Adaptations issues des champs PMR et Tourisme & Handicap de chaque manifestation.','count':len(sirtaqui)}, {'name':'DATAtourisme · offices de tourisme','recordSource':'DATAtourisme · offices de tourisme','url':DATASET_PAGE,'description':'Agendas nationaux des offices de tourisme, toutes régions et DROM examinés. Dates et contacts issus de l’export événements, complétés par les déclarations PMR de l’export national complet du '+graph['last_modified'][:10]+'. Les territoires sans adaptation déclarée ne produisent pas de fiche.','count':len(national),'accessibilitySourceUpdatedAt':graph['last_modified']}]
    for source in sources:source.update({'license':'Licence Ouverte 2.0','licenseUrl':'https://www.etalab.gouv.fr/licence-ouverte-open-licence/','updatedAt':now.isoformat()})
    print('Tourism agendas:',{s['name']:s['count'] for s in sources},flush=True)
    return records,sources
