import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {hasDeclaredNeed,isEmploymentContent} from '../dist/content-policy.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const catalogPath=path.join(root,'dist/data.json');
const catalog=JSON.parse(fs.readFileSync(catalogPath,'utf8'));
let noDeclaredNeed=0,employment=0,places=0,events=0;const sourceCounts=new Map();
const exclusions=[];
for(const department of catalog.departments){
 const file=path.join(root,'dist',department.file);
 const shard=JSON.parse(fs.readFileSync(file,'utf8'));
 shard.records=shard.records.filter(record=>{
  if(!hasDeclaredNeed(record)){noDeclaredNeed++;return false;}
  if(isEmploymentContent(record)){employment++;exclusions.push({id:record.id,title:record.title,department:record.department});return false;}
  delete record._selectionDescription;
  // Unknown labels have a UI default. Avoid repeating them across the national
  // snapshot as new agendas are added; retain every explicit statement.
  for(const f of Object.values(record.features||{}))if(f.value===null&&f.label==='À vérifier')delete f.label;
  return true;
 });
 for(const record of shard.records)sourceCounts.set(record.source,(sourceCounts.get(record.source)||0)+1);
 department.places=shard.records.filter(record=>record.type==='place').length;
 department.events=shard.records.filter(record=>record.type==='event').length;
 places+=department.places;events+=department.events;
 fs.writeFileSync(file,JSON.stringify(shard));
}
catalog.totalPlaces=places;catalog.totalEvents=events;
for(const source of catalog.sources)source.count=sourceCounts.get(source.recordSource||source.name)||0;
catalog.selectionPolicy={version:1,atLeastOneDeclaredNeed:true,excludeEmployment:true};
fs.writeFileSync(catalogPath,JSON.stringify(catalog));
const report={places,events,total:places+events,removed:{noDeclaredNeed,employment},employmentExclusions:exclusions,departmentsWithData:catalog.departments.filter(d=>d.places+d.events>0).length,drom:catalog.departments.filter(d=>d.drom).map(({code,nom,places,events})=>({code,nom,places,events}))};
fs.mkdirSync(path.join(root,'.sites-runtime'),{recursive:true});
fs.writeFileSync(path.join(root,'.sites-runtime/selection-report.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report));
