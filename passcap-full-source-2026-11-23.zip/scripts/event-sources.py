"""Additional public agendas. Accessibility stays tied to its cited source/session."""
import concurrent.futures,datetime,hashlib,html,json,pathlib,re,urllib.parse,urllib.request,unicodedata
from zoneinfo import ZoneInfo
from bs4 import BeautifulSoup
PARIS='https://opendata.paris.fr/api/explore/v2.1/catalog/datasets/que-faire-a-paris-/'
NANTES='https://data.nantesmetropole.fr/api/explore/v2.1/catalog/datasets/244400404_agenda-evenements-nantes-metropole_v2/'
PSG='https://www.psg.fr/football-masculin/calendrier'
PSG_ACCESS='https://www.handicap-psg.fr/a-propos'
RELAX='https://culture-relax.org/'
RELAX_API='https://strapi.culture-relax.org/api/search'
OPERA='https://www.operadeparis.fr/billetterie/recherche'
OPERA_ACCESS='https://www.operadeparis.fr/infos-pratiques/accessibilite-pmr'
ZONE=ZoneInfo('Europe/Paris')
MONTHS={n:i+1 for i,n in enumerate(['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'])}
KIND_LABELS={'exhibition':'Exposition','theatre':'Théâtre','opera':'Opéra','concert':'Concert','sport':'Sport · match','dance':'Danse','cinema':'Cinéma','workshop':'Atelier','visit':'Visite','other':'Événement'}
def norm(v):return ''.join(c for c in unicodedata.normalize('NFD',str(v or '')) if not unicodedata.combining(c)).lower()
def plain(v):return BeautifulSoup(str(v or ''),'html.parser').get_text(' ',strip=True)
def kind(title,tags=''):
 t=norm(str(tags)+' '+title)
 for key,pattern in [('opera',r'\bopera\b|lyrique'),('sport',r'\bfootball\b|\brugby\b|\bmatch\b|\bbasket|\bhandball|sports? collectifs'),('exhibition',r'\bexpo(?:sition)?s?\b'),('theatre',r'theatre|comedie|marionnett'),('dance',r'\bdanse\b|\bballet\b'),('concert',r'concert|musique|recital|jazz|chorale'),('cinema',r'cinema|projection|\bfilm\b'),('workshop',r'atelier'),('visit',r'visite|balade')]:
  if re.search(pattern,t):return key
 return 'other'
def remote_image(url,credit='',alt='',policy='oa'):
 """Use only source-supplied HTTPS artwork. Restricted credits override feed defaults."""
 if not isinstance(url,str):return None
 try:
  u=urllib.parse.urlparse(url);port=u.port
 except ValueError:return None
 if u.scheme!='https' or u.hostname not in {'img.openagenda.com','cdn.openagenda.com','cibul.s3.amazonaws.com','cdn.paris.fr'} or u.username or u.password or (port and port!=443):return None
 if not re.search(r'\.(jpe?g|png|webp|avif)$',u.path,re.I):return None
 credit=plain(credit);alt=plain(alt)
 if re.search(r'tous droits reserves|all rights reserved|non commercial|non-commercial|cc.?by.?nc|usage interne|reproduction interdite',norm(credit)):return None
 if policy in {'oa','oa2'} and u.hostname=='cdn.paris.fr':return None
 if policy=='paris':
  # The database licence alone does not establish the rights to third-party photos.
  if re.search(r'\bcc[ -]?0\b',credit,re.I):policy='cc0'
  else:
   match=re.search(r'\bcc[ -]by([ -]sa)?[ -]+(2\.0|2\.5|3\.0|4\.0)\b',credit,re.I)
   if not match:return None
   policy='cc-by'+('-sa' if match[1] else '')+'-'+match[2]
 result={'url':url,'policy':policy}
 if credit:result['credit']=credit
 if alt:result['alt']=alt
 return result

def iso(v):
 try:return datetime.datetime.fromisoformat(str(v).replace('Z','+00:00'))
 except (ValueError,TypeError):return None

def blank():return {k:{'value':None,'label':'À vérifier'} for k in ['motor','hearing','visual','mental','autism','psychic']}
def declared(value,label,url):return {'value':value,'label':label,'sourceUrl':url}
def base(id,title,venue,city,dep,url,source,now):
 return {'id':id,'type':'event','title':plain(title),'venue':plain(venue),'city':plain(city),'department':dep,'timezone':'Europe/Paris','source':source,'producer':source,'sourceUrl':url,'updatedAt':now.isoformat(),'sourceUpdatedLabel':'Programmation consultée','features':blank(),'timings':[],'status':1,'age':None,'description':'','conditions':'Réservation et accueil à confirmer auprès de l’organisateur.','address':plain(venue)+' · '+plain(city),'website':url,'phone':None,'email':None,'lat':None,'lon':None}
def within(t,now,until):
 a,b=iso(t.get('start')),iso(t.get('end'))
 return a is not None and b is not None and a.tzinfo is not None and b.tzinfo is not None and a<=b and b>=now and a<=until

def parse_paris(rows,deps,now,until):
 result=[]
 for e in rows:
  code=str(e.get('address_zipcode') or '');dep=code[:2]
  if dep not in deps or dep not in ['75','77','78','91','92','93','94','95']:continue
  url=e.get('url') or ''
  if not url.startswith('https://www.paris.fr/'):continue
  r=base('paris-'+str(e['id']),e['title'],e.get('address_name'),e.get('address_city') or 'Paris',dep,url,'Que Faire à Paris',now)
  for key,field,label in [('motor','pmr','Mobilité réduite'),('visual','blind','Accueil des personnes aveugles ou malvoyantes'),('hearing','deaf','Accueil des personnes sourdes ou malentendantes'),('mental','mental','Accueil du handicap intellectuel')]:
   value=e.get(field)
   if str(value) in ['0','1']:r['features'][key]=declared(str(value)=='1',(label+' déclaré' if str(value)=='1' else 'Indiqué non adapté : '+label.lower())+' par la fiche événement',url)
  if str(e.get('sign_language'))=='1':r['features']['hearing']=declared(True,'Langue des signes déclarée pour cet événement',url)
  for occurrence in str(e.get('occurrences') or '').split(';'):
   parts=occurrence.split('_')
   if len(parts)==2:
    t={'start':parts[0],'end':parts[1]}
    if within(t,now,until):r['timings'].append(t)
  if not e.get('occurrences'):
   t={'start':e.get('date_start'),'end':e.get('date_end'),'dateOnly':True}
   if within(t,now,until):r['timings']=[t];r['scheduleNote']='Période annoncée ; jours et horaires d’ouverture à vérifier dans la source.'
  if not r['timings']:continue
  r.update({'eventKind':kind(r['title'],e.get('qfap_tags')),'description':plain(e.get('lead_text') or e.get('description'))[:900],'address':plain(e.get('address_street'))+' '+code+' '+r['city'],'phone':e.get('contact_phone'),'email':e.get('contact_mail'),'website':e.get('contact_url') or url,'conditions':plain(e.get('price_detail')) or 'Tarif et réservation à consulter dans la source.'})
  image=remote_image(e.get('cover_url'),e.get('cover_credit'),e.get('cover_alt'),policy='paris')
  if image:r['image']=image
  r['category']=KIND_LABELS[r['eventKind']];r['timings'].sort(key=lambda t:iso(t['start']))
  coords=e.get('lat_lon') or {};r['lat']=coords.get('lat');r['lon']=coords.get('lon');r['updatedAt']=e.get('updated_at') or now.isoformat();result.append(r)
 return result

def parse_nantes(rows,deps,now,until):
 result={}
 for e in rows:
  if any(e.get(k)=='oui' for k in ['annule','complet','reporte']):continue
  day=e.get('date');a=iso(str(day)+'T'+str(e.get('heure_debut') or '00:00'));b=iso(str(day)+'T'+str(e.get('heure_fin') or '23:59'))
  if not a or not b:continue
  a=a.replace(tzinfo=ZONE);b=b.replace(tzinfo=ZONE)
  if b<a:b+=datetime.timedelta(days=1)
  t={'start':a.isoformat(),'end':b.isoformat(),'endTimeKnown':bool(e.get('heure_fin')),'dateOnly':not bool(e.get('heure_debut'))}
  if not within(t,now,until):continue
  dep=str(e.get('code_postal') or '')[:2]
  if dep not in deps:continue
  url=e.get('lien_agenda') or '';id='nantes-'+str(e['id_manif'])
  if not url.startswith('https://'):continue
  if id in result:result[id]['timings'].append(t);continue
  r=base(id,e['nom'],e.get('lieu'),e.get('ville'),dep,url,'Nantes Métropole',now)
  for key,field in [('motor','h_moteur'),('visual','h_visuel'),('hearing','h_auditif'),('mental','h_intellectuel'),('psychic','h_psychique')]:
   if e.get(field) in ['oui','non']:r['features'][key]=declared(e[field]=='oui',('Adaptation déclarée' if e[field]=='oui' else 'Indiqué non adapté')+' par la fiche événement de Nantes Métropole',url)
  if e.get('h_lsf')=='oui':r['features']['hearing']=declared(True,'Langue des signes française déclarée',url)
  r.update({'timings':[t],'eventKind':kind(r['title'],e.get('types_libelles')),'description':plain(e.get('description_evt'))[:1200],'address':plain(e.get('adresse')),'phone':e.get('telephone') or e.get('lieu_tel'),'email':e.get('courriel') or e.get('lieu_email'),'website':e.get('url_site') or url,'conditions':plain(e.get('precisions_tarifs_evt')) or 'Tarifs et réservation à confirmer.','openAgendaUid':str(e.get('id_agenda_in') or '')})
  r['category']=KIND_LABELS[r['eventKind']];coords=e.get('location_latlong') or {};r['lat']=coords.get('lat');r['lon']=coords.get('lon');result[id]=r
 for r in result.values():r['timings'].sort(key=lambda t:iso(t['start']))
 return list(result.values())

def parse_psg(page,now,until):
 soup=BeautifulSoup(page,'html.parser');cards=soup.select('article[id^="fixture-card-"]');result=[]
 for card in cards:
  heading=card.find('h2');clock=card.find('time');link=card.find('a',href=re.compile(r'^/matchs/football-masculin/'))
  if not heading or not clock or not link or 'Parc des Princes' not in card.get_text(' ',strip=True):continue
  h=heading.get_text(' ',strip=True)
  if not h.startswith('Paris Saint-Germain vs ') or not re.search(r' - \d{2}:\d{2}$',h):continue
  a=iso(clock.get('datetime'));title=h.split(' - ')[0]
  if not a or a<now or a>until:continue
  end=a.astimezone(ZONE).replace(hour=23,minute=59,second=59)
  url=urllib.parse.urljoin(PSG,link['href']);r=base('psg-'+card['id'],title,'Parc des Princes','Paris','75',url,'Paris Saint-Germain',now)
  r.update({'category':'Football · PSG','eventKind':'sport','timings':[{'start':a.isoformat(),'end':end.isoformat(),'endTimeKnown':False}],'description':'Match de football du PSG à domicile. Date et horaire susceptibles d’être modifiés par l’organisateur.','conditions':'Places pour personnes en fauteuil sur demande via l’offre PFR de la billetterie officielle, selon disponibilité. L’accès n’est pas garanti par la présence de cette fiche.','website':'https://billetterie.psg.fr/fr/'})
  r['features']['motor']=declared(True,'Offre PFR pour les matchs à domicile : demande et confirmation obligatoires',PSG_ACCESS);result.append(r)
 return result

def parse_opera(page,now,until):
 soup=BeautifulSoup(page,'html.parser');result=[];maxdate=None
 for group in soup.select('ul.TicketingList'):
  date=group.select_one('.PerformanceDate[title]')
  if not date:continue
  m=re.search(r'(\d{1,2}) (\w+) (\d{4})',date['title'])
  if not m or m[2] not in MONTHS:continue
  day=datetime.date(int(m[3]),MONTHS[m[2]],int(m[1]));maxdate=max(maxdate or day,day)
  for item in group.select('.TicketingList__item'):
   title=item.select_one('h2.title-oeuvre');link=item.select_one('.TicketingList__title a[href]');description=item.select_one('.TicketingList__description');text=item.get_text(' ',strip=True)
   if not title or not link or not description or re.search(r'\bcomplet\b',text,re.I):continue
   info=description.get_text(' ',strip=True);m=re.search(r'^(Opéra Bastille|Palais Garnier)\s*—\s*(\d{1,2})h(\d{2})',info)
   if not m:continue
   a=datetime.datetime(day.year,day.month,day.day,int(m[2]),int(m[3]),tzinfo=ZONE)
   if a<now or a>until:continue
   url=link['href'];venue=m[1];id=hashlib.sha256((url+a.isoformat()+venue).encode()).hexdigest()[:20]
   r=base('opera-'+id,title.get_text(' ',strip=True),venue,'Paris','75',url,'Opéra national de Paris',now)
   author=item.select_one('.TicketingList__author');tags=author.get_text(' ',strip=True) if author else ''
   r.update({'eventKind':kind(r['title'],tags),'timings':[{'start':a.isoformat(),'end':a.replace(hour=23,minute=59,second=59).isoformat(),'endTimeKnown':False}],'description':'Représentation au '+venue+'. Consulter la fiche officielle pour la distribution et la durée.','conditions':'Réservation adaptée auprès du service Accessibilité, au moins huit jours avant la représentation, selon disponibilité.','phone':'01 40 01 18 50','email':'accessibilite@operadeparis.fr'})
   r['category']=KIND_LABELS[r['eventKind']];r['features']['motor']=declared(True,'Emplacements fauteuil et accueil PMR pour les représentations, sur réservation auprès du service Accessibilité',OPERA_ACCESS)
   if 'Audiodescription' in text:r['features']['visual']=declared(True,'Audiodescription annoncée pour cette séance',url)
   if re.search(r'\bRelax\b',text):
    for k in ['autism','mental','psychic']:r['features'][k]=declared(True,'Séance Relax annoncée pour cette représentation',url)
   result.append(r)
 return result,maxdate

def parse_relax(payload,deps,now,until):
 result=[]
 zones={'971':'America/Guadeloupe','972':'America/Martinique','973':'America/Cayenne','974':'Indian/Reunion','976':'Indian/Mayotte'}
 for e in (payload.get('movies') or [])+(payload.get('spectacles') or []):
  work=e.get('movie') if e.get('eventSessionType')=='Movie' else e.get('spectacle')
  theater=e.get('theater') or {};address=theater.get('address') or e.get('externalAddress') or {};org=e.get('organizer') or {}
  if not work or not work.get('title') or not org.get('slug'):continue
  if norm(address.get('country')) not in ['france','fr','guadeloupe','martinique','guyane','reunion','mayotte']:continue
  postcode=str(address.get('zipCode') or '');context=str(address.get('context') or '').split(',')[0].strip();dep=context if context in deps else postcode[:3] if postcode.startswith('97') else postcode[:2]
  if dep not in deps:continue
  zone=ZoneInfo(zones.get(dep,'Europe/Paris'));a=iso(str(e.get('date'))+'T'+str(e.get('time') or ''))
  if not a:continue
  a=a.replace(tzinfo=zone)
  if a<now or a>until:continue
  url=RELAX+'organizer/'+urllib.parse.quote(org['slug'])+'?event='+str(e['id'])
  r=base('relax-'+str(e['id']),work['title'],theater.get('name') or org.get('name'),address.get('city'),dep,url,'Culture Relax',now)
  event_kind='cinema' if e.get('eventSessionType')=='Movie' else kind(work['title'])
  r.update({'timezone':str(zone),'eventKind':event_kind,'category':'Cinéma · Relax' if event_kind=='cinema' else (KIND_LABELS[event_kind] if event_kind!='other' else 'Spectacle vivant')+' · Relax','timings':[{'start':a.isoformat(),'end':a.replace(hour=23,minute=59,second=59).isoformat(),'endTimeKnown':False}],'description':'Séance Relax annoncée par Culture Relax. Consulter la source pour les informations sur l’œuvre et l’accueil.','conditions':'Tarif et réservation à confirmer auprès de l’organisateur de cette séance Relax.','producer':org.get('name') or 'Culture Relax','address':' '.join(str(address[k]) for k in ['address1','zipCode','city'] if address.get(k)),'lat':address.get('latitude'),'lon':address.get('longitude'),'email':org.get('contactMail'),'phone':org.get('contactPhoneNumber')})
  for key in ['autism','mental','psychic']:r['features'][key]=declared(True,'Séance Relax : accueil adapté annoncé pour cette séance',url)
  result.append(r)
 return result

def collect(deps,now,until,cache,cached=False):
 cache=cache/'supplemental';cache.mkdir(exist_ok=True)
 def fetch(name,url):
  p=cache/name
  if not cached or not p.exists():
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PassCap/1.1 public agenda importer'}),timeout=90) as f:content=f.read()
   temp=p.with_suffix(p.suffix+'.tmp');temp.write_bytes(content);temp.replace(p)
  return p.read_text()
 jobs=[('paris.json',PARIS+'exports/json?'+urllib.parse.urlencode({'where':f"date_end >= '{now.isoformat()}' AND date_start <= '{until.isoformat()}'",'limit':-1})),('nantes.json',NANTES+'exports/json?'+urllib.parse.urlencode({'where':f"date >= '{now.date()}' AND date <= '{until.date()}'",'limit':-1})),('psg-access.html',PSG_ACCESS),('opera-access.html',OPERA_ACCESS),('relax.json',RELAX_API),('relax-access.html',RELAX)]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:raw=dict(zip([j[0] for j in jobs],pool.map(lambda j:fetch(*j),jobs)))
 assert 'PFR' in raw['psg-access.html'] and 'fauteuil' in raw['psg-access.html'].lower(),'PSG accessibility source changed'
 assert '8' in raw['opera-access.html'] and 'accessibilite@operadeparis.fr' in raw['opera-access.html'],'Opera accessibility source changed'
 assert 'autistes' in raw['relax-access.html'] and 'psychiques' in raw['relax-access.html'],'Relax accessibility source changed'
 paris=parse_paris(json.loads(raw['paris.json']),deps,now,until);nantes=parse_nantes(json.loads(raw['nantes.json']),deps,now,until)
 months=sorted({(now+datetime.timedelta(days=d)).strftime('%b') for d in range((until-now).days+1)})
 psg=[]
 for month in months:psg.extend(parse_psg(fetch('psg-'+month+'.html',PSG+'?period='+month),now,until))
 opera=[]
 for page in range(1,31):
  body=fetch('opera-'+str(page)+'.html',OPERA+'?page='+str(page));rows,last=parse_opera(body,now,until);opera.extend(rows)
  if last and last>until.astimezone(ZONE).date():break
  if not BeautifulSoup(body,'html.parser').select('a[rel="next"]'):break
 assert paris and nantes and opera,'Unexpected empty supplemental cultural agenda'
 relax=parse_relax(json.loads(raw['relax.json']),deps,now,until)
 assert relax,'Unexpected empty Relax agenda'
 records=list({r['id']:r for r in paris+nantes+psg+opera+relax}.values())
 sources=[
 {'name':'Que Faire à Paris','recordSource':'Que Faire à Paris','url':'https://opendata.paris.fr/explore/dataset/que-faire-a-paris-/','description':'Événements culturels et sportifs de Paris et sa région, avec adaptations déclarées sur les fiches.','license':'Open Database License (ODbL)','licenseUrl':'https://opendatacommons.org/licenses/odbl/1-0/'},
 {'name':'Nantes Métropole','recordSource':'Nantes Métropole','url':'https://data.nantesmetropole.fr/explore/dataset/244400404_agenda-evenements-nantes-metropole_v2/','description':'Expositions, théâtre, concerts, opéra et manifestations sportives de la métropole.','license':'Licence Ouverte 2.0','licenseUrl':'https://www.etalab.gouv.fr/licence-ouverte-open-licence/'},
 {'name':'Paris Saint-Germain','recordSource':'Paris Saint-Germain','url':PSG,'description':'Matchs de l’équipe masculine au Parc des Princes avec horaire annoncé. Offre fauteuil PFR soumise à confirmation.','license':'Dates et lieux · calendrier officiel','licenseUrl':PSG},
 {'name':'Opéra national de Paris','recordSource':'Opéra national de Paris','url':OPERA,'description':'Représentations à Bastille et Garnier. Audiodescription et Relax uniquement sur les séances explicitement signalées.','license':'Dates et lieux · programmation officielle','licenseUrl':OPERA},
 {'name':'Culture Relax','recordSource':'Culture Relax','url':RELAX,'description':'Séances de cinéma et de spectacle vivant Relax en France. Seules les œuvres et dates annoncées sont reprises.','license':'Dates et lieux · programmation officielle','licenseUrl':RELAX}]
 for s in sources:s.update({'updatedAt':now.isoformat(),'count':sum(r['source']==s['recordSource'] for r in records)})
 print('Supplemental agendas:',{s['name']:s['count'] for s in sources},flush=True)
 return records,sources
