#!/usr/bin/env python3
"""Build an attributed national snapshot, split by department. Requires duckdb.
Run in .sites-runtime/data-venv; --cached reuses previously downloaded source files.
Regular runs download a fresh snapshot, preserving dates and provenance.
"""
import argparse,collections,concurrent.futures,datetime,gzip,html,json,math,pathlib,re,shutil,subprocess,urllib.parse,urllib.request,unicodedata
import duckdb
import importlib.util
_extra_spec=importlib.util.spec_from_file_location("event_sources",pathlib.Path(__file__).with_name("event-sources.py"));extra=importlib.util.module_from_spec(_extra_spec);_extra_spec.loader.exec_module(extra)
_tourism_spec=importlib.util.spec_from_file_location("tourism_sources",pathlib.Path(__file__).with_name("tourism-sources.py"));tourism=importlib.util.module_from_spec(_tourism_spec);_tourism_spec.loader.exec_module(tourism)
_institution_spec=importlib.util.spec_from_file_location("association_sources",pathlib.Path(__file__).with_name("association-sources.py"));institutions=importlib.util.module_from_spec(_institution_spec);_institution_spec.loader.exec_module(institutions)
_cinema_spec=importlib.util.spec_from_file_location("cinema_sources",pathlib.Path(__file__).with_name("cinema-sources.py"));cinema=importlib.util.module_from_spec(_cinema_spec);_cinema_spec.loader.exec_module(cinema)
ROOT=pathlib.Path(__file__).resolve().parents[1];CACHE=ROOT/'.sites-runtime/national';CACHE.mkdir(parents=True,exist_ok=True)
NOW=datetime.datetime.now(datetime.timezone.utc);UNTIL=NOW+datetime.timedelta(days=90)
DATASET='https://www.data.gouv.fr/api/1/datasets/accessibilite-des-etablissements-recevant-du-public-erp-pour-les-personnes-en-situation-de-handicap/'
ODS='https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/evenements-publics-openagenda/'
GEOMETRY='https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements-avec-outre-mer.geojson'
TIMEZONES={'971':'America/Guadeloupe','972':'America/Martinique','973':'America/Cayenne','974':'Indian/Reunion','976':'Indian/Mayotte'}
CATEGORIES='^(biblioth|musée|cinéma|théâtre|centre culturel|piscine|espace vert|jardin botanique|salle de spectacle|office d[eu] tourisme|information touristique|centre de loisirs|conservatoire|galerie d.art)'
def decode(b):return json.loads(gzip.decompress(b) if b[:2]==b'\x1f\x8b' else b)
def read(name):return decode((CACHE/name).read_bytes())
def get(url):
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PassCap/1.0 open-data import'}),timeout=180) as f:return decode(f.read())
def download(url,name):
 temp=CACHE/(name+'.download')
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PassCap/1.0 open-data import'}),timeout=180) as f,open(temp,'wb') as out:shutil.copyfileobj(f,out)
 temp.replace(CACHE/name);print('Downloaded',name,flush=True)
def norm(v):return ''.join(c for c in unicodedata.normalize('NFD',str(v or '')) if not unicodedata.combining(c)).lower().replace('’',"'").replace('-',' ').strip()
def plain(v):
 s=html.unescape(v or '');s=re.sub(r'</(?:p|div|li)>|<br\s*/?>','\n',s);s=re.sub(r'<[^>]+>','',s);s=re.sub(r'\[([^\]]+)\]\([^)]+\)',r'\1',s);return s.replace('**','').strip()
def safe_url(v):return v if isinstance(v,str) and urllib.parse.urlparse(v).scheme in ['http','https'] else None
def iso(v):
 try:
  d=datetime.datetime.fromisoformat(v.replace('Z','+00:00'));return d if d.tzinfo else d.replace(tzinfo=datetime.timezone.utc)
 except (ValueError,TypeError,AttributeError):return None
def object_value(v,default):
 if isinstance(v,str):
  try:return json.loads(v)
  except (ValueError,TypeError):return default
 return v if v is not None else default
def feature(value,label):return {'value':value,'label':label}
def blank_features():return {k:feature(None,'À vérifier') for k in ['motor','hearing','visual','mental','autism','psychic']}
def numeric(v):
 try:return float(v) if v is not None else None
 except (ValueError,TypeError):return None
def department(code,deps):
 code=str(code or '').strip()
 d=code[:3] if code.startswith('97') else code[:2]
 return d if d in deps else None
def place(p,updated,deps):
 dep=department(p.get('code_insee'),deps)
 if not dep or not safe_url(p.get('web_url')):return None
 features=blank_features()
 if p.get('entree_pmr') is False:features['motor']=feature(False,'Entrée déclarée non accessible en fauteuil')
 elif p.get('entree_pmr') is True and p.get('accueil_cheminement_plain_pied') is True and p.get('accueil_retrecissement') is False:features['motor']=feature(True,'Entrée accessible et cheminement de plain-pied déclarés')
 if p.get('accueil_equipements_malentendants_presence') is True:features['hearing']=feature(True,'Équipement pour personnes malentendantes déclaré')
 if p.get('accueil_audiodescription_presence') is True:features['visual']=feature(True,'Audiodescription déclarée')
 details=[{'label':label,'value':p[key]} for key,label in [('entree_pmr','Entrée accessible en fauteuil'),('entree_plain_pied','Entrée de plain-pied'),('accueil_cheminement_plain_pied','Cheminement intérieur de plain-pied'),('sanitaires_adaptes','Sanitaires adaptés'),('stationnement_pmr','Stationnement adapté sur place')] if isinstance(p.get(key),bool)]
 return {'id':'al-'+str(p['id']),'type':'place','department':dep,'timezone':TIMEZONES.get(dep,'Europe/Paris'),'title':p['name'],'description':'Consultez les caractéristiques déclarées pour préparer votre visite. Les horaires, les tarifs et les conditions d’accueil sont à confirmer auprès du lieu.','category':p.get('activite') or 'Lieu','city':p.get('commune') or 'Commune non précisée','address':' '.join(str(p[k]) for k in ['numero','voie','postal_code','commune'] if p.get(k)),'venue':p['name'],'lat':numeric(p.get('latitude')),'lon':numeric(p.get('longitude')),'age':None,'features':features,'details':details,'timings':[],'conditions':'Tarifs et horaires à vérifier auprès du lieu.','source':'Acceslibre','producer':'Acceslibre — contributeurs','sourceUrl':safe_url(p['web_url']),'updatedAt':updated,'sourceUpdatedLabel':'Export source mis à jour','website':safe_url(p.get('site_internet')),'phone':None}
def event(e,deps,names):
 country=str(e.get('location_countrycode') or '').upper()
 if country and country not in ['FR','GP','MQ','GF','RE','YT']:return None
 dep=department(e.get('location_insee'),deps) or names.get(norm(e.get('location_department')))
 if not dep and country in ['FR','GP','MQ','GF','RE','YT']:dep=department(e.get('location_postalcode'),deps)
 if not dep:return None
 status=object_value(e.get('status'),{});status=status.get('id',1) if isinstance(status,dict) else status
 attendance=object_value(e.get('attendancemode'),{});attendance=attendance.get('id',1) if isinstance(attendance,dict) else attendance
 if status not in [1,2] or attendance==2:return None
 raw=object_value(e.get('timings'),[]);timings=[]
 for t in raw:
  start=t.get('begin') or t.get('start');end=t.get('end');a,b=iso(start),iso(end)
  if a and b and b>=NOW and a<=UNTIL:timings.append({'start':start,'end':end})
 timings.sort(key=lambda t:iso(t['start']))
 if not timings or not safe_url(e.get('canonicalurl')):return None
 a=object_value(e.get('accessibility'),e.get('accessibility') or [])
 if isinstance(a,dict):a=[k for k,v in a.items() if v]
 if isinstance(a,str):a=re.split('[,; ]+',a)
 features=blank_features()
 for key,code,label in [('motor','mi','moteur'),('hearing','hi','auditif'),('visual','vi','visuel'),('mental','ii','intellectuel'),('psychic','pi','psychique')]:
  if code in a:features[key]=feature(True,'Aménagement déclaré pour le handicap '+label)
 coords=e.get('location_coordinates') or {};minimum=e.get('age_min');maximum=e.get('age_max');age={'min':minimum,'max':maximum} if minimum is not None or maximum is not None else None
 registration=object_value(e.get('registration'),[])
 if not isinstance(registration,list):registration=[]
 email=next((str(c.get('value','')).strip() for c in registration if c.get('type')=='email' and re.fullmatch(r'[^\s<>@,;]+@[^\s<>@,;]+\.[A-Za-z]{2,63}',str(c.get('value','')).strip())),None)
 phone=e.get('location_phone') or next((c.get('value') for c in registration if c.get('type')=='phone'),None)
 event_kind=extra.kind(plain(e.get('title_fr')),e.get('keywords_fr') or '')
 description=plain(e.get('longdescription_fr') or e.get('description_fr'));truncated=len(description)>2400
 return {'id':'oa-'+str(e['uid']),'type':'event','department':dep,'timezone':TIMEZONES.get(dep,'Europe/Paris'),'title':plain(e.get('title_fr')),'_selectionDescription':description,'description':description[:2400]+('…' if truncated else ''),'descriptionTruncated':truncated,'category':extra.KIND_LABELS[event_kind],'eventKind':event_kind,'city':e.get('location_city') or 'Commune non précisée','address':e.get('location_address'),'venue':e.get('location_name'),'lat':numeric(coords.get('lat')),'lon':numeric(coords.get('lon')),'age':age,'features':features,'timings':timings,'conditions':plain(e.get('conditions_fr')) or 'Tarifs et réservation à vérifier auprès de l’organisateur.','source':'OpenAgenda','producer':e.get('originagenda_title') or 'OpenAgenda','sourceUrl':safe_url(e.get('canonicalurl')),'updatedAt':e.get('updatedat'),'sourceUpdatedLabel':'Fiche mise à jour','website':safe_url(e.get('location_website')),'phone':phone,'email':email,'status':status,**({'image':image} if (image:=extra.remote_image(e.get('image'),e.get('imagecredits'))) else {})}
def point_line_distance(p,a,b):
 dx=b[0]-a[0];dy=b[1]-a[1]
 if dx==dy==0:return math.hypot(p[0]-a[0],p[1]-a[1])
 t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy)))
 return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)
def simplify(points,epsilon=.008):
 if len(points)<=4:return points
 maxd=0;index=0
 for i in range(1,len(points)-1):
  d=point_line_distance(points[i],points[0],points[-1])
  if d>maxd:maxd,index=d,i
 if maxd>epsilon:return simplify(points[:index+1],epsilon)[:-1]+simplify(points[index:],epsilon)
 return [points[0],points[-1]]
def paths_for_feature(f):
 geom=f['geometry'];polygons=[geom['coordinates']] if geom['type']=='Polygon' else geom['coordinates'];rings=[]
 for polygon in polygons:
  for ring in polygon:
   if len(ring)<4:continue
   mid=len(ring)//2;points=simplify(ring[:mid+1])+simplify(ring[mid:])[1:]
   if len(points)>=4:rings.append(points)
 return rings

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--cached',action='store_true');args=parser.parse_args()
 if not args.cached:
  meta=get(DATASET);r=next(r for r in meta['resources'] if r['title']=='acceslibre-with-web-url.csv');m={'updatedAt':r['last_modified'],'url':r['url'],'parquet':r['extras']['analysis:parsing:parquet_url']};(CACHE/'acceslibre-meta.json').write_text(json.dumps(m))
  for name,url in [('departments.json','https://geo.api.gouv.fr/departements'),('geometry.json',GEOMETRY),('events-metadata.json',ODS)]:download(url,name)
  fields='uid,canonicalurl,title_fr,description_fr,longdescription_fr,conditions_fr,updatedat,timings,accessibility,accessibility_label_fr,location_name,location_address,location_insee,location_postalcode,location_city,location_department,location_region,location_countrycode,location_coordinates,location_phone,location_website,status,attendancemode,age_min,age_max,originagenda_title,registration,keywords_fr,image,imagecredits'
  where=f"lastdate_end >= '{NOW.isoformat()}' AND firstdate_begin <= '{UNTIL.isoformat()}' AND accessibility IS NOT NULL"
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lambda pair:download(*pair),[(m['parquet'],'places.parquet'),(ODS+'exports/json?'+urllib.parse.urlencode({'select':fields,'where':where,'limit':-1}),'events.json')]))
 departments=read('departments.json');deps={d['code']:d for d in departments};names={norm(d['nom']):d['code'] for d in departments};names.update({'reunion':'974','la reunion':'974'})
 c=duckdb.connect();q=c.execute('SELECT * FROM read_parquet(?) WHERE regexp_matches(lower(activite), ?)',[str(CACHE/'places.parquet'),CATEGORIES]);columns=[d[0] for d in q.description];m=read('acceslibre-meta.json');records={}
 for row in q.fetchall():
  r=place(dict(zip(columns,row)),m['updatedAt'],deps)
  if r:records[r['id']]=r
 raw=read('events.json')
 for row in raw:
  r=event(row,deps,names)
  if r:
   old=records.get(r['id'])
   if not old or (r['updatedAt'] or '')>(old['updatedAt'] or ''):records[r['id']]=r
 supplements,additional_sources=extra.collect(deps,NOW,UNTIL,CACHE,args.cached)
 tourism_records,tourism_sources=tourism.collect(deps,NOW,UNTIL,CACHE,args.cached,extra)
 supplements.extend(tourism_records);additional_sources.extend(tourism_sources)
 institutional_records,institutional_sources=institutions.collect(deps,NOW,UNTIL,CACHE,args.cached,extra)
 supplements=institutional_records+supplements;additional_sources.extend(institutional_sources)
 cinema_records,cinema_sources=cinema.collect(deps,NOW,UNTIL,CACHE,args.cached,extra)
 supplements.extend(cinema_records);additional_sources.extend(cinema_sources)
 images_by_uid={str(e['uid']):image for e in raw if (image:=extra.remote_image(e.get('image'),e.get('imagecredits')))}
 for r in supplements:
  uid=r.get('openAgendaUid')
  if uid and images_by_uid.get(uid):r['image']=images_by_uid[uid]
  if uid and 'oa-'+uid in records and any(f['value'] is True for f in r['features'].values()):records.pop('oa-'+uid)
  records[r['id']]=r
 buckets={code:[] for code in deps}
 for r in records.values():buckets[r['department']].append(r)
 total_events=sum(r['type']=='event' for r in records.values());total_places=len(records)-total_events
 assert len(deps)==101 and total_places>10000 and total_events>1000,'Unexpected empty or truncated national input'
 stage=ROOT/'.sites-runtime/staged-data';stage.mkdir(exist_ok=True)
 for d in departments:
  rows=buckets[d['code']];d.update({'places':sum(r['type']=='place' for r in rows),'events':sum(r['type']=='event' for r in rows),'timezone':TIMEZONES.get(d['code'],'Europe/Paris'),'drom':d['code'] in TIMEZONES,'file':'data/departments/'+d['code']+'.json'})
  (stage/(d['code']+'.json')).write_text(json.dumps({'importedAt':NOW.isoformat(),'records':rows},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
 geometry=read('geometry.json');mapdata=[]
 for f in geometry['features']:
  code=f['properties']['code']
  if code in deps:mapdata.append({'code':code,'rings':[[[round(p[0],4),round(p[1],4)] for p in ring] for ring in paths_for_feature(f)]})
 assert len(mapdata)==101
 sources=[{'name':'Acceslibre','url':'https://acceslibre.beta.gouv.fr/','description':'Lieux culturels, de loisirs et d’information touristique en métropole et dans les DROM. Les autres catégories d’établissements ne sont pas importées.','updatedAt':m['updatedAt'],'license':'Licence Ouverte 2.0','licenseUrl':'https://www.etalab.gouv.fr/licence-ouverte-open-licence/','count':total_places},{'name':'OpenAgenda · catalogue national','url':'https://public.opendatasoft.com/explore/dataset/evenements-publics-openagenda/','description':'Événements publics du catalogue OpenAgenda diffusé par Huwise, avec au moins une séance pendant les 90 jours suivant l’import. Couverture variable selon les agendas contributeurs.','updatedAt':NOW.isoformat(),'license':'Licence Ouverte 1.0','licenseUrl':'https://www.etalab.gouv.fr/wp-content/uploads/2014/05/Licence_Ouverte.pdf','count':total_events}]
 sources[0]['recordSource']='Acceslibre';sources[1]['recordSource']='OpenAgenda';sources.extend(additional_sources)
 catalog={'importedAt':NOW.isoformat(),'horizonEnd':UNTIL.isoformat(),'territory':'France métropolitaine et DROM','totalEvents':total_events,'totalPlaces':total_places,'departments':departments,'sources':sources,'geometrySource':{'url':'https://github.com/gregoiredavid/france-geojson','label':'France GeoJSON · IGN Admin Express 2018 · Licence Ouverte','updatedAt':'2018-01-01'}}
 destination=ROOT/'dist/data/departments';destination.mkdir(parents=True,exist_ok=True)
 for path in stage.glob('*.json'):shutil.copy2(path,destination/path.name)
 for name,obj in [('data.json',catalog),('map-data.json',mapdata)]:
  p=ROOT/'dist'/name;temp=p.with_suffix('.tmp');temp.write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':')),encoding='utf-8');temp.replace(p)
 subprocess.run(['node',str(ROOT/'scripts/filter-catalog.mjs')],check=True)
if __name__=='__main__':main()
