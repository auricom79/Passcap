// Local verification only. This file is never bundled or deployed.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {createHash,randomBytes} from 'node:crypto';
import {sqliteD1} from '../tests/helpers/sqlite-d1.mjs';
import {createHandler} from '../worker/runtime.mjs';
import {gzipSync} from 'node:zlib';
const root=path.resolve(import.meta.dirname,'..'),DB=sqliteD1();
DB.exec(fs.readFileSync(path.join(root,'drizzle/0000_community.sql'),'utf8'));DB.exec(fs.readFileSync(path.join(root,'drizzle/0001_private_needs.sql'),'utf8'));DB.exec(fs.readFileSync(path.join(root,'drizzle/0002_auto_filter.sql'),'utf8'));
DB.exec(fs.readFileSync(path.join(root,'drizzle/0003_email_auth.sql'),'utf8'));
DB.exec(fs.readFileSync(path.join(root,'drizzle/0004_newsletter.sql'),'utf8'));
DB.exec(fs.readFileSync(path.join(root,'drizzle/0005_guest_newsletter.sql'),'utf8'));
const catalog=JSON.parse(fs.readFileSync(path.join(root,'dist/data.json'),'utf8'));
const departments=Object.fromEntries(catalog.departments.map(d=>[d.code,JSON.parse(fs.readFileSync(path.join(root,'dist',d.file),'utf8'))]));
const snapshot={catalog,departments,mapData:JSON.parse(fs.readFileSync(path.join(root,'dist/map-data.json'),'utf8')),mapHtml:fs.readFileSync(path.join(root,'dist/carte.html'),'utf8')};
const bootstrap=gzipSync(JSON.stringify(snapshot)).toString('base64'),assets={};
const mime={html:'text/html',js:'text/javascript',mjs:'text/javascript',css:'text/css',svg:'image/svg+xml',woff2:'font/woff2',txt:'text/plain'};
function walk(dir){for(const f of fs.readdirSync(dir,{withFileTypes:true})){const local=path.join(dir,f.name);if(f.isDirectory()){if(!['server','.openai','data'].includes(f.name))walk(local);}else{const type=mime[f.name.split('.').at(-1)];if(type)assets['/'+path.relative(path.join(root,'dist'),local)]={type,body:fs.readFileSync(local).toString('base64')};}}}
walk(path.join(root,'dist'));
const handler=createHandler(assets,bootstrap),env={DB,BUCKET:{get:async()=>null},RESEND_API_KEY:'local-preview-only',ACCOUNT_EMAIL_FROM:'Pass Cap <bonjour@passcap.org>',PASSWORD_PEPPER:'local-preview-pepper-with-at-least-32-characters'};
let previewNewsletterLink='';
const realFetch=globalThis.fetch;globalThis.fetch=(url,options)=>{if(String(url)!=='https://api.resend.com/emails')return realFetch(url,options);const mail=JSON.parse(options.body);previewNewsletterLink=mail.text.match(/http[^\s]+#newsletter=confirm&token=[a-f0-9]{64}/)?.[0]||previewNewsletterLink;return Promise.resolve(Response.json({id:'local-preview-no-mail-sent'}));};
const port=Number(process.env.PREVIEW_PORT||8766),origin='http://localhost:'+port;env.APP_ORIGIN=origin;
// Explicit, isolated local QA fixtures; no test login route is present in production.
const token=randomBytes(32).toString('hex'),tokenHash=createHash('sha256').update(token).digest('hex'),now=Date.now();
await DB.prepare("INSERT INTO community_users(id,google_sub,email,pseudo,avatar,profile_complete,created_at) VALUES('qa-local','qa-local','qa@example.invalid','Compte de test local','leaf',1,?)").bind(now).run();
await DB.prepare('INSERT INTO community_sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)').bind(tokenHash,'qa-local',now,now+3600000).run();
http.createServer(async(req,res)=>{try{
 if(req.url==='/__qa/newsletter-link'){res.writeHead(previewNewsletterLink?303:404,previewNewsletterLink?{'Location':previewNewsletterLink}:{});res.end();return;}
 if(req.url==='/__qa/signin'){res.writeHead(303,{'Set-Cookie':`__Host-pc_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax`,'Location':'/'});res.end();return;}
 const chunks=[];for await(const part of req)chunks.push(part);const body=Buffer.concat(chunks),request=new Request(origin+req.url,{method:req.method,headers:req.headers,...(!['GET','HEAD'].includes(req.method)?{body}: {})});const response=await handler.fetch(request,env);res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
 }catch{res.writeHead(500);res.end('Local preview error');}
}).listen(port,'127.0.0.1',()=>console.log('Local community preview: '+origin));
