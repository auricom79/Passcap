import fs from 'node:fs';
import path from 'node:path';
import {gzipSync} from 'node:zlib';
const root=path.resolve(import.meta.dirname,'..'),dist=path.join(root,'dist');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const catalog=JSON.parse(read('dist/data.json'));
const snapshot={catalog,departments:Object.fromEntries(catalog.departments.map(d=>[d.code,JSON.parse(read('dist/'+d.file))])),mapData:JSON.parse(read('dist/map-data.json')),mapHtml:read('dist/carte.html')};
const types={html:'text/html; charset=utf-8',css:'text/css; charset=utf-8',js:'text/javascript; charset=utf-8',mjs:'text/javascript; charset=utf-8',svg:'image/svg+xml',woff2:'font/woff2',txt:'text/plain; charset=utf-8',md:'text/plain; charset=utf-8'};
const assets={};
function add(file,url){const ext=file.split('.').at(-1);if(!types[ext])return;assets[url]={type:types[ext],body:fs.readFileSync(file).toString('base64')};}
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,e.name),rel=path.relative(dist,f);if(e.isDirectory()){if(!['server','data','.openai'].includes(rel))walk(f);}else if(rel!=='carte.html')add(f,'/'+rel);}}
walk(dist);add(path.join(root,'DAILY_UPDATE.md'),'/api/update-guide');
const policy=read('dist/content-policy.mjs').replace(/export /g,'');
const runtime=read('worker/runtime.mjs').replace(/^import .*;\n/gm,'').replace(/export /g,'');
const mail=read('worker/mail.mjs').replace(/export /g,'');
const newsletter=read('worker/newsletter.mjs').replace(/^import .*;\n/gm,'').replace(/export /g,'');
const emailAuth=read('worker/email-auth.mjs').replace(/^import .*;\n/gm,'').replace(/export /g,'');
const community=read('worker/community.mjs').replace(/^import .*;\n/gm,'').replace(/export /g,'');
const code=policy+'\n'+mail+'\n'+newsletter+'\n'+emailAuth+'\n'+community+'\n'+runtime+'\nexport default createHandler('+JSON.stringify(assets)+','+JSON.stringify(gzipSync(JSON.stringify(snapshot)).toString('base64'))+');\n';
fs.mkdirSync(path.join(dist,'server'),{recursive:true});fs.mkdirSync(path.join(dist,'.openai'),{recursive:true});
fs.writeFileSync(path.join(dist,'server/index.js'),code);fs.copyFileSync(path.join(root,'.openai/hosting.json'),path.join(dist,'.openai/hosting.json'));
fs.cpSync(path.join(root,'drizzle'),path.join(dist,'.openai/drizzle'),{recursive:true});
fs.writeFileSync(path.join(dist,'server/wrangler.json'),JSON.stringify({name:'pass-cap',main:'index.js',compatibility_date:'2026-05-15',no_bundle:true,d1_databases:[{binding:'DB',database_name:'site-creator-d1',database_id:'00000000-0000-4000-8000-000000000000',migrations_dir:'../.openai/drizzle'}]}));
console.log(JSON.stringify({workerBytes:Buffer.byteLength(code),compressedBytes:gzipSync(code).byteLength}));
