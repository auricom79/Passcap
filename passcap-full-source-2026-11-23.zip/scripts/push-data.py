#!/usr/bin/env python3
"""Upload validated open data. Read Site service access from hidden stdin only."""
import gzip,hashlib,json,pathlib,sys,urllib.request,urllib.error
ROOT=pathlib.Path(__file__).resolve().parents[1]
ALLOWED_ORIGINS={'https://pass-cap.sachant-sweat0b.chatgpt.site','https://passcap.org'}
def read(rel):return json.loads((ROOT/rel).read_text())
catalog=read('dist/data.json')
snapshot={'catalog':catalog,'departments':{d['code']:read('dist/'+d['file']) for d in catalog['departments']},'mapData':read('dist/map-data.json'),'mapHtml':(ROOT/'dist/carte.html').read_text()}
body=gzip.compress(json.dumps(snapshot,ensure_ascii=False,separators=(',',':')).encode(),mtime=0)
digest=hashlib.sha256(body).hexdigest()
if sys.stdin.isatty():
 import termios
 previous=termios.tcgetattr(sys.stdin);hidden=previous[:];hidden[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,hidden)
else:previous=None
print('Ready for Site access JSON on stdin (input is hidden).',flush=True)
try:access=json.loads(sys.stdin.readline())
finally:
 if previous:termios.tcsetattr(sys.stdin,termios.TCSANOW,previous)
ORIGIN=access['url'].rstrip('/')
assert ORIGIN in ALLOWED_ORIGINS,'Unexpected Site origin'
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect())
headers={('Authorization' if ORIGIN=='https://passcap.org' else 'OAI-Sites-Authorization'):'Bearer '+access['token']}
def call(path,data=None):
 h=dict(headers)
 if data is not None:h.update({'Content-Type':'application/gzip','X-Pass-Cap-Update':'1'})
 req=urllib.request.Request(ORIGIN+path,data=data,headers=h,method='POST' if data is not None else 'GET')
 with opener.open(req,timeout=180) as r:
  assert r.geturl().startswith(ORIGIN+'/'),'Unexpected redirect'
  return json.load(r)
try:
 result=call('/api/catalog/update',body)
 assert result.get('ok') and result.get('sha256')==digest,'Update acknowledgement mismatch'
 status=call('/api/catalog/status')
 assert status.get('persisted') and status.get('sha256')==digest,'Persisted readback mismatch'
 live=call('/data.json')
 assert live['importedAt']==catalog['importedAt'] and live['totalEvents']==catalog['totalEvents'] and live['totalPlaces']==catalog['totalPlaces'],'Live catalog mismatch'
 for code in ['79','974']:
  shard=call('/data/departments/'+code+'.json')
  assert shard==snapshot['departments'][code],'Department readback mismatch: '+code
 print(json.dumps({'verified':True,'importedAt':catalog['importedAt'],'places':catalog['totalPlaces'],'events':catalog['totalEvents'],'sha256':digest,'unchanged':result.get('unchanged',False)}),flush=True)
except urllib.error.HTTPError as e:
 print('Update failed: HTTP '+str(e.code),file=sys.stderr)
 # Validation errors contain public catalog diagnostics, never the access header.
 if e.code in [409,413,415,422]:print(e.read(3000).decode(errors='replace'),file=sys.stderr)
 sys.exit(1)
