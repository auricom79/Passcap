import fs from 'node:fs';
import path from 'node:path';
import {gzipSync} from 'node:zlib';
const root=path.resolve(import.meta.dirname,'..'),args=process.argv.slice(2);
function arg(name,fallback){const i=args.indexOf(name);return i<0?fallback:args[i+1];}
const database=arg('--database-id',''),bucket=arg('--bucket','passcap-catalogue'),domain=arg('--domain','passcap.org');
if(!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(database))throw Error('Pass the exact D1 database_id returned by Cloudflare with --database-id. No resource is created by this helper.');
if(!/^[a-z0-9][a-z0-9.-]+\.[a-z]{2,}$/i.test(domain)||! /^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(bucket))throw Error('Invalid domain or bucket name');
const out=path.join(root,'.sites-runtime/cloudflare'),publicDir=path.join(out,'public');
fs.mkdirSync(publicDir,{recursive:true});
for(const entry of fs.readdirSync(path.join(root,'dist'),{withFileTypes:true})){
 if(['server','.openai','data','data.json','map-data.json','carte.html'].includes(entry.name))continue;
 fs.cpSync(path.join(root,'dist',entry.name),path.join(publicDir,entry.name),{recursive:true});
}
const read=f=>JSON.parse(fs.readFileSync(path.join(root,'dist',f),'utf8')),catalog=read('data.json');
const snapshot={catalog,departments:Object.fromEntries(catalog.departments.map(d=>[d.code,read(d.file)])),mapData:read('map-data.json'),mapHtml:fs.readFileSync(path.join(root,'dist/carte.html'),'utf8')};
fs.writeFileSync(path.join(out,'catalogue.json.gz'),gzipSync(JSON.stringify(snapshot)));
const config={name:'passcap',main:path.join(root,'cloudflare/worker.mjs'),compatibility_date:'2026-05-15',workers_dev:false,preview_urls:false,routes:[{pattern:domain+'/*',zone_name:domain}],assets:{directory:publicDir,binding:'ASSETS',run_worker_first:['/evenements','/evenements/*','/sitemap.xml','/api/*','/data.json','/map-data.json','/carte.html','/data/departments/*']},d1_databases:[{binding:'DB',database_name:'passcap-community',database_id:database,migrations_dir:path.join(root,'drizzle')}],r2_buckets:[{binding:'BUCKET',bucket_name:bucket}],vars:{APP_ORIGIN:'https://'+domain},triggers:{crons:['*/5 * * * *']},observability:{enabled:false}};
fs.writeFileSync(path.join(out,'wrangler.json'),JSON.stringify(config,null,2)+'\n');
console.log('Prepared local Cloudflare files in '+out+'. Nothing was deployed. Set Google and updater configuration before release.');
