"""Direct, openly licensed institutional agendas, beyond the national mirror.

The public JSON endpoint is the one used by OpenAgenda's public agenda pages.
No account, API key, deprecated export or authenticated endpoint is involved.
Each event must itself carry the Etalab licence and a declared adaptation.
"""
import concurrent.futures
import json
import re
import urllib.parse
import urllib.request

AGENDAS = [
    ('bibliotheques-de-rennes', 'Bibliothèques de Rennes'),
    ('bibliotheques-de-toulouse', 'Bibliothèques de Toulouse'),
    ('musee-des-augustins-toulouse', 'Musée des Augustins'),
    ('echosciences', 'Échosciences · culture scientifique'),
]
SOURCE = 'Musées, bibliothèques et sciences · agendas directs'
LICENSE_URL = 'https://www.data.gouv.fr/pages/legal/licences/etalab-2.0/'
FIELDS = ['uid', 'title', 'canonicalUrl', 'timings', 'accessibility', 'location',
          'rights', 'updatedAt', 'description', 'longDescription', 'registration',
          'age', 'conditions', 'status', 'slug', 'originAgenda', 'keywords',
          'attendanceMode', 'timezone', 'image', 'imageCredits']
ZONES = {'971':'America/Guadeloupe', '972':'America/Martinique',
         '973':'America/Cayenne', '974':'Indian/Reunion', '976':'Indian/Mayotte'}


def french(value):
    if isinstance(value, dict):
        return value.get('fr') or value.get('en') or next(iter(value.values()), '')
    return value or ''


def safe_url(value):
    if not isinstance(value, str): return None
    try:
        parsed = urllib.parse.urlparse(value)
        port = parsed.port
    except ValueError:
        return None
    if parsed.scheme not in ['http', 'https'] or not parsed.hostname or parsed.username or parsed.password:
        return None
    return value


def department(location, deps):
    country = str(location.get('countryCode') or '').upper()
    if country and country not in ['FR', 'GP', 'MQ', 'GF', 'RE', 'YT']:
        return None
    insee = str(location.get('insee') or '')
    postal = str(location.get('postalCode') or '')
    if not postal:
        match = re.search(r'(?<!\d)(\d{5})(?!\d)', location.get('address') or '')
        postal = match[1] if match else ''
    code = insee or postal
    # Saint-Martin and Saint-Barthélemy are not Guadeloupe departments.
    if code in ['97123', '97127', '97133', '97150', '97701', '97801']:
        return None
    dep = code[:3] if code.startswith('97') else code[:2]
    if dep in deps: return dep
    return None


def parse_events(rows, deps, now, until, helpers):
    records = {}
    for event in rows:
        rights = event.get('rights') or {}
        if (rights.get('license') or {}).get('id') != 'etalab-2.0': continue
        if event.get('status') not in [1, 2] or event.get('attendanceMode') == 2: continue
        location = event.get('location') or {}
        dep = department(location, deps)
        url = safe_url(event.get('canonicalUrl'))
        if not dep or not url or not event.get('uid') or not french(event.get('title')): continue
        features = helpers.blank()
        adaptations = event.get('accessibility') or {}
        # OpenAgenda checkboxes express declared facilities. False is an unchecked
        # box, not an explicit statement that the event is unsuitable.
        for code, key, label in [('mi','motor','moteur'), ('hi','hearing','auditif'),
                                 ('vi','visual','visuel'), ('ii','mental','intellectuel'),
                                 ('pi','psychic','psychique')]:
            if isinstance(adaptations, dict) and adaptations.get(code) is True:
                features[key] = helpers.declared(True, 'Aménagement déclaré pour le handicap '+label, url)
        if not any(f['value'] is True for f in features.values()): continue
        timings = []
        for timing in event.get('timings') or []:
            item = {'start':timing.get('begin') or timing.get('start'), 'end':timing.get('end')}
            if helpers.within(item, now, until): timings.append(item)
        timings = sorted({(t['start'], t['end']):t for t in timings}.values(), key=lambda t:helpers.iso(t['start']))
        if not timings: continue
        record = helpers.base('oa-'+str(event['uid']), french(event['title']),
                              location.get('name'), location.get('city'), dep, url, SOURCE, now)
        description = helpers.plain(french(event.get('longDescription')) or french(event.get('description')))
        event_kind = helpers.kind(record['title'], french(event.get('keywords')))
        record.update({'features':features, 'timings':timings,
                       'timezone':ZONES.get(dep, 'Europe/Paris'),
                       'producer':helpers.plain((rights.get('licensor') or {}).get('name') or (event.get('originAgenda') or {}).get('title')) or SOURCE,
                       'updatedAt':event.get('updatedAt') or now.isoformat(),
                       'sourceUpdatedLabel':'Fiche mise à jour', 'status':event['status'],
                       'eventKind':event_kind, 'category':helpers.KIND_LABELS[event_kind],
                       '_selectionDescription':description, 'description':description[:1200],
                       'descriptionTruncated':len(description)>1200,
                       'conditions':helpers.plain(french(event.get('conditions'))) or 'Tarifs et réservation à vérifier auprès de l’organisateur.',
                       'address':helpers.plain(location.get('address')),
                       'lat':location.get('latitude'), 'lon':location.get('longitude'),
                       'age':event.get('age')})
        contacts = event.get('registration') or []
        for field, type_ in [('email','email'), ('phone','phone'), ('website','link')]:
            value = next((c.get('value') for c in contacts if c.get('type') == type_ and c.get('value')), None)
            if field == 'website': value = safe_url(value)
            if value: record[field] = value
        if not record['phone']: record['phone'] = location.get('phone')
        artwork = event.get('image') or {}
        if isinstance(artwork, dict) and artwork.get('base') and artwork.get('filename'):
            image = helpers.remote_image(artwork['base']+artwork['filename'], event.get('imageCredits'), policy='oa2')
            if image: record['image'] = image
        records[record['id']] = record
    return list(records.values())


def fetch_agenda(slug, now, until, fetch):
    """Fetch every page; reject partial/looping responses rather than truncating."""
    rows = []; seen = set(); after = None
    for page in range(30):
        params = [('size',100), ('relative[]','current'), ('relative[]','upcoming'),
                  ('timings[gte]',now.isoformat()), ('timings[lte]',until.isoformat())]
        params += [('includeFields[]',field) for field in FIELDS]
        if after: params += [('after[]',part) for part in after]
        url = 'https://openagenda.com/api/agendas/slug/'+slug+'/events?'+urllib.parse.urlencode(params)
        payload = json.loads(fetch(slug+'-'+str(page)+'.json', url))
        if payload.get('success') is not True or not isinstance(payload.get('events'), list) or not isinstance(payload.get('total'), int):
            raise ValueError('Unexpected public agenda response: '+slug)
        batch = payload['events']
        new_ids = {str(e.get('uid')) for e in batch} - seen
        if not batch and len(seen) >= payload['total']: return rows
        if not new_ids: raise ValueError('Incomplete or repeating agenda page: '+slug)
        rows.extend(batch); seen.update(new_ids)
        if len(seen) >= payload['total']: return rows
        after = payload.get('after')
        if not isinstance(after, list) or not after: raise ValueError('Missing agenda pagination: '+slug)
    raise ValueError('Agenda exceeds the bounded importer: '+slug)


def collect(deps, now, until, cache, cached=False, extra=None):
    if extra is None: raise ValueError('Event helper module required')
    folder = cache/'associations'; folder.mkdir(exist_ok=True)
    def fetch(name, url):
        target = folder/name
        if not cached or not target.exists():
            request = urllib.request.Request(url, headers={'User-Agent':'PassCap/1.3 public institutional agenda importer'})
            with urllib.request.urlopen(request, timeout=90) as response: content = response.read()
            temp = target.with_suffix('.tmp'); temp.write_bytes(content); temp.replace(target)
        return target.read_text()
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        collections = list(pool.map(lambda agenda:fetch_agenda(agenda[0], now, until, fetch), AGENDAS))
    records = parse_events([event for collection in collections for event in collection], deps, now, until, extra)
    sources = [{'name':SOURCE, 'recordSource':SOURCE,
                'url':'https://openagenda.com/fr/echosciences',
                'description':'Agendas directs des Bibliothèques de Rennes et de Toulouse, du Musée des Augustins et du réseau Échosciences. Seuls les événements sous Licence Ouverte avec une adaptation déclarée sont retenus ; doublons OpenAgenda supprimés par identifiant.',
                'license':'Licence Ouverte 2.0', 'licenseUrl':LICENSE_URL,
                'updatedAt':now.isoformat(), 'count':len(records)}]
    print('Institutional agendas:',len(records),'eligible events from',len(AGENDAS),'agendas.',flush=True)
    return records, sources
