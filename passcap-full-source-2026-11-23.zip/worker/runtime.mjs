import {sendWeeklyNewsletter,unsubscribeNewsletter} from './newsletter.mjs';
import {createCommunityHandler} from './community.mjs';
import {isEligibleRecord} from '../dist/content-policy.mjs';
const KEY='pass-cap/catalog/current.json.gz';
const MAX_COMPRESSED=8*1024*1024,MAX_JSON=20*1024*1024;
const json=(value,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const unbase64=value=>Uint8Array.from(atob(value),c=>c.charCodeAt(0));
async function unpack(bytes){
 const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
 const reader=stream.getReader(),chunks=[];let size=0;
 for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX_JSON){await reader.cancel();throw new Error('Catalogue trop volumineux');}chunks.push(value);}
 const data=new Uint8Array(size);let at=0;for(const c of chunks){data.set(c,at);at+=c.length;}
 return JSON.parse(new TextDecoder().decode(data));
}
function assert(condition,message){if(!condition)throw new Error(message);}
export function validateSnapshot(snapshot){
 const c=snapshot.catalog,rows=snapshot.departments;
 assert(c&&rows&&Array.isArray(c.departments)&&c.departments.length===101,'101 départements requis');
 const expected=[...Array.from({length:95},(_,i)=>String(i+1).padStart(2,'0')).filter(c=>c!=='20'),'2A','2B','971','972','973','974','976'].sort();
 assert(JSON.stringify(c.departments.map(d=>d.code).sort())===JSON.stringify(expected),'Codes des départements invalides');
 assert(Number.isFinite(Date.parse(c.importedAt))&&Date.parse(c.importedAt)<=Date.now()+3600000,'Date d’import invalide');
 assert(Date.parse(c.horizonEnd)>Date.parse(c.importedAt),'Horizon invalide');
 assert(c.selectionPolicy?.atLeastOneDeclaredNeed&&c.selectionPolicy?.excludeEmployment,'Politique de sélection absente');
 let places=0,events=0;const ids=new Set();
 for(const d of c.departments){
  const shard=rows[d.code];assert(shard?.importedAt===c.importedAt&&Array.isArray(shard.records),'Département incomplet');
  let p=0,e=0;
  for(const r of shard.records){
   assert(r.department===d.code&&!ids.has(r.id)&&isEligibleRecord(r),'Fiche non admissible ou dupliquée');ids.add(r.id);
   assert(typeof r.sourceUrl==='string'&&r.sourceUrl.startsWith('https://'),'Source absente');
   if(r.type==='place'){p++;}else{assert(r.type==='event'&&[1,2].includes(r.status)&&r.timings?.length,'Événement invalide');e++;}
  }
  assert(p===d.places&&e===d.events,'Compteurs départementaux incohérents');places+=p;events+=e;
 }
 assert(places===c.totalPlaces&&events===c.totalEvents&&places>=500&&events>=500,'Catalogue vide, tronqué ou compteurs incohérents');
 assert(Array.isArray(snapshot.mapData)&&snapshot.mapData.length===101,'Carte incomplète');
 assert(typeof snapshot.mapHtml==='string'&&snapshot.mapHtml.startsWith('<!doctype html>'),'Carte autonome absente');
 return {importedAt:c.importedAt,horizonEnd:c.horizonEnd,places:String(places),events:String(events)};
}
// Public, server-rendered catalogue pages: no member data is read here.
const seoEscape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const seoSlug=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const seoNeeds={motor:'mobilite',hearing:'audition',visual:'vision',mental:'handicap-intellectuel',autism:'autisme',psychic:'handicap-psychique'};
const seoNeedLabels={motor:'Mobilité et déplacement',hearing:'Handicap auditif',visual:'Handicap visuel',mental:'Handicap intellectuel',autism:'Autisme et besoins sensoriels',psychic:'Handicap psychique'};
export function seoResponse(snapshot,url,now=Date.now()){
 const e=seoEscape,base='https://passcap.org',path=url.pathname;
 const active=r=>r.type==='event'&&isEligibleRecord(r)&&r.timings?.some(t=>Date.parse(t.end)>=now);
 const departments=snapshot.catalog.departments,records=Object.values(snapshot.departments).flatMap(s=>s.records).filter(active);
 const eventPath=r=>'/evenements/fiche/'+encodeURIComponent(r.id);
 const cityGroups=new Map();for(const r of records){const key=seoSlug(r.city);if(!key)continue;if(!cityGroups.has(key))cityGroups.set(key,{name:r.city,rows:[]});cityGroups.get(key).rows.push(r);}
 const needFromSlug=value=>Object.keys(seoNeeds).find(k=>seoNeeds[k]===value);
 const indexable=rows=>rows.length>=3;
 const listPaths=[];
 for(const d of departments){const rows=records.filter(r=>r.department===d.code);if(indexable(rows))listPaths.push('/evenements/departement/'+d.code);for(const [need,slug] of Object.entries(seoNeeds)){const filtered=rows.filter(r=>r.features?.[need]?.value===true);if(indexable(filtered))listPaths.push('/evenements/departement/'+d.code+'/handicap/'+slug);}}
 for(const [slug,group] of cityGroups){if(indexable(group.rows))listPaths.push('/evenements/ville/'+slug);for(const [need,needSlug] of Object.entries(seoNeeds)){const filtered=group.rows.filter(r=>r.features?.[need]?.value===true);if(indexable(filtered))listPaths.push('/evenements/ville/'+slug+'/handicap/'+needSlug);}}
 for(const [need,slug] of Object.entries(seoNeeds))if(indexable(records.filter(r=>r.features?.[need]?.value===true)))listPaths.push('/evenements/handicap/'+slug);
 if(path==='/sitemap.xml'){
  const paths=['/','/evenements',...listPaths,...records.map(eventPath)];
  return new Response('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+paths.map(p=>'<url><loc>'+e(base+p)+'</loc></url>').join('')+'</urlset>',{headers:{'Content-Type':'application/xml; charset=utf-8','Cache-Control':'public, max-age=900'}});
 }
 let title='Événements et sorties par département',description='Trouvez une sortie près de chez vous : concerts, cinéma, expositions, marchés et ateliers, avec les adaptations déclarées par les sources.',body='',structured=null,canonical=base+path,status=200,noindex=false;
 const renderList=(rows,explore='')=>{rows=[...rows].sort((a,b)=>Date.parse(a.timings?.[0]?.start)-Date.parse(b.timings?.[0]?.start)||a.title.localeCompare(b.title,'fr'));const page=Math.max(1,Math.floor(Number(url.searchParams.get('page'))||1)),pages=Math.max(1,Math.ceil(rows.length/50));if(page>pages)return null;canonical+=page>1?'?page='+page:'';if(page>1)title+=' — page '+page;noindex=!indexable(rows);structured={'@context':'https://schema.org','@type':'ItemList',name:title,numberOfItems:rows.length,itemListElement:rows.slice((page-1)*50,page*50).map((r,i)=>({'@type':'ListItem',position:(page-1)*50+i+1,url:base+eventPath(r),name:r.title}))};return '<p>'+e(description)+'</p>'+(explore?'<p><a href="'+e(explore)+'">Explorer les dates et filtrer selon mes besoins</a></p>':'')+'<p><strong>'+rows.length+'</strong> événement'+(rows.length>1?'s':'')+' à venir.</p><ul>'+rows.slice((page-1)*50,page*50).map(r=>'<li><h2><a href="'+eventPath(r)+'">'+e(r.title)+'</a></h2><p>'+e(r.city)+' · '+e(r.venue)+'</p></li>').join('')+'</ul>'+(rows.length?'':'<p>Aucun événement à venir renseigné actuellement.</p>')+'<nav aria-label="Pagination">'+(page>1?'<a rel="prev" href="?page='+(page-1)+'">Page précédente</a> ':'')+(page<pages?'<a rel="next" href="?page='+(page+1)+'">Page suivante</a>':'')+'</nav>';};
 if(path==='/evenements')body='<p>Choisissez un département, une ville ou un besoin d’accessibilité pour découvrir les événements à venir.</p><h2>Par département</h2><ul class="seo-departments">'+departments.map(d=>'<li><a href="/evenements/departement/'+e(d.code)+'">'+e(d.code)+' · '+e(d.nom)+'</a></li>').join('')+'</ul><h2>Par besoin d’accessibilité</h2><ul>'+Object.entries(seoNeeds).map(([k,s])=>'<li><a href="/evenements/handicap/'+s+'">'+e(seoNeedLabels[k])+'</a></li>').join('')+'</ul>';
 else if(path.startsWith('/evenements/fiche/')){
  let id;try{id=decodeURIComponent(path.slice('/evenements/fiche/'.length));}catch{return new Response('Page introuvable',{status:404});}
  const r=records.find(r=>r.id===id);if(!r)return new Response('Cet événement n’est plus disponible. Retrouvez les prochaines sorties sur https://passcap.org/evenements',{status:404});
  canonical=base+eventPath(r);title=r.title+' à '+r.city;description=(r.description||'Découvrez cet événement à '+r.city+' et ses adaptations déclarées.').replace(/<[^>]*>/g,'').slice(0,170);
  const times=r.timings.filter(t=>Date.parse(t.end)>=now).sort((a,b)=>Date.parse(a.start)-Date.parse(b.start)),fmt=new Intl.DateTimeFormat('fr-FR',{dateStyle:'long',timeZone:r.timezone||'Europe/Paris'}),needs={motor:'Mobilité et déplacement',hearing:'Audition',visual:'Vision',mental:'Handicap intellectuel',autism:'Autisme et besoins sensoriels',psychic:'Handicap psychique'},app='/?departement='+encodeURIComponent(r.department)+'&evenement='+encodeURIComponent(r.id);
  body='<p><a href="/evenements/departement/'+e(r.department)+'">← Les événements du département '+e(r.department)+'</a></p><p><strong>'+e(r.venue)+'</strong> · '+e(r.city)+'</p><p>'+e(r.address)+'</p><h2>Quand ?</h2><ul>'+times.slice(0,20).map(t=>'<li><time datetime="'+e(t.start)+'">'+e(fmt.format(new Date(t.start)))+'</time></li>').join('')+'</ul><p>'+e(r.description)+'</p><h2>Les adaptations déclarées</h2><ul>'+Object.entries(needs).map(([k,label])=>'<li>'+e(label)+' : '+(r.features?.[k]?.value===true?'adaptation déclarée':r.features?.[k]?.value===false?'indiqué non adapté':'non renseigné')+'</li>').join('')+'</ul><p>Ces indications proviennent des sources et restent à confirmer auprès de l’organisateur avant votre visite.</p><p>'+e(r.conditions)+'</p><p><a href="'+e(r.sourceUrl)+'" rel="noopener noreferrer">Consulter la source et les informations de réservation ↗</a></p><section class="join-community"><div><h2>Cette sortie vous tente ?</h2><p>Avec votre compte gratuit, exprimez votre envie, gardez cet événement en favori et discutez entre membres.</p><a class="community-primary" href="'+e(app)+'">Voir la fiche et rejoindre la discussion ↗</a></div></section>';
  structured={'@context':'https://schema.org','@type':'Event',name:r.title,description:r.description||description,url:canonical,startDate:times[0].start,eventAttendanceMode:'https://schema.org/OfflineEventAttendanceMode',eventStatus:r.status===2?'https://schema.org/EventCancelled':'https://schema.org/EventScheduled',location:{'@type':'Place',name:r.venue||r.city,address:{'@type':'PostalAddress',streetAddress:r.address||undefined,addressLocality:r.city,addressCountry:'FR'}}};
 }else{
  let rows,match;
  if((match=path.match(/^\/evenements\/departement\/([^/]+)(?:\/handicap\/([^/]+))?$/))){const d=departments.find(d=>d.code===match[1]);if(!d)return new Response('Département introuvable',{status:404});rows=records.filter(r=>r.department===d.code);title='Sorties et événements : '+d.nom+' ('+d.code+')';description='Découvrez les événements à venir dans le département '+d.nom+' et leurs adaptations déclarées.';if(match[2]){const need=needFromSlug(match[2]);if(!need)return new Response('Besoin inconnu',{status:404});rows=rows.filter(r=>r.features?.[need]?.value===true);title='Sorties adaptées — '+seoNeedLabels[need]+' dans '+d.nom;description='Événements dans '+d.nom+' avec une adaptation déclarée pour '+seoNeedLabels[need].toLowerCase()+'. Informations à confirmer auprès de l’organisateur.';}body=renderList(rows,'/?departement='+encodeURIComponent(d.code));}
  else if((match=path.match(/^\/evenements\/ville\/([^/]+)(?:\/handicap\/([^/]+))?$/))){const group=cityGroups.get(match[1]);if(!group)return new Response('Ville introuvable',{status:404});rows=group.rows;title='Sorties et événements à '+group.name;description='Découvrez les événements à venir à '+group.name+' et leurs adaptations d’accessibilité déclarées.';if(match[2]){const need=needFromSlug(match[2]);if(!need)return new Response('Besoin inconnu',{status:404});rows=rows.filter(r=>r.features?.[need]?.value===true);title='Sorties adaptées — '+seoNeedLabels[need]+' à '+group.name;description='Événements à '+group.name+' avec une adaptation déclarée pour '+seoNeedLabels[need].toLowerCase()+'. Informations à confirmer.';}body=renderList(rows,'/?ville='+encodeURIComponent(group.name));}
  else if((match=path.match(/^\/evenements\/handicap\/([^/]+)$/))){const need=needFromSlug(match[1]);if(!need)return new Response('Besoin inconnu',{status:404});rows=records.filter(r=>r.features?.[need]?.value===true);title='Sorties et événements — '+seoNeedLabels[need];description='Événements en France avec une adaptation déclarée pour '+seoNeedLabels[need].toLowerCase()+'. Informations à confirmer auprès de l’organisateur.';body=renderList(rows);}
  else return new Response('Page introuvable',{status:404});if(body===null)return new Response('Page introuvable',{status:404});
 }
 const html='<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+e(title)+' | Pass Cap</title><meta name="description" content="'+e(description)+'"><link rel="canonical" href="'+e(canonical)+'">'+(noindex?'<meta name="robots" content="noindex,follow">':'')+'<meta property="og:type" content="'+(path.startsWith('/evenements/fiche/')?'article':'website')+'"><meta property="og:title" content="'+e(title)+'"><meta property="og:description" content="'+e(description)+'"><meta property="og:url" content="'+e(canonical)+'"><link rel="stylesheet" href="/styles.css"><link rel="icon" href="/favicon.svg">'+(structured?'<script type="application/ld+json">'+JSON.stringify(structured).replace(/</g,'\\u003c')+'</script>':'')+'</head><body><header class="header"><a class="brand" href="/" aria-label="Pass Cap, accueil"><span class="brand-name">pass<span class="brand-cap">cap</span></span></a><nav><a href="/evenements">Les événements</a> · <a href="/#account=newsletter">Mon compte gratuit</a></nav></header><main class="seo-page"><h1>'+e(title)+'</h1>'+body+'</main><footer class="footer"><p>Pass Cap — Les sorties qui font la différence !</p><a href="/">Explorer les sorties</a><a href="/confidentialite.html">Confidentialité</a></footer></body></html>';
 return new Response(html,{status,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'public, max-age=900','X-Content-Type-Options':'nosniff'}});
}
// This writer is deployed only on the owner-private Site. Sites validates service
// access before dispatch. Do not make the Site public without securing this route.
export function createHandler(assets,bootstrap){
 const community=createCommunityHandler();
 let cached=null,cachedTag='';
 async function current(bucket){
  const obj=await bucket.get(KEY,cachedTag&&cachedTag!=='bootstrap'?{onlyIf:{etagDoesNotMatch:cachedTag}}:undefined);
  if(obj&&!obj.body&&cached)return cached;
  if(obj){cached=await unpack(await obj.arrayBuffer());cachedTag=obj.etag;return cached;}
  if(!cached){cached=await unpack(unbase64(bootstrap));cachedTag='bootstrap';}
  return cached;
 }
 return {async newsletter(env,now){await env.DB.batch([env.DB.prepare('DELETE FROM newsletter_guest_tokens WHERE expires_at<?').bind(now),env.DB.prepare('DELETE FROM newsletter_guest_deliveries WHERE week_key<?').bind(new Date(now-90*86400000).toISOString().slice(0,10)),env.DB.prepare('DELETE FROM community_email_tokens WHERE expires_at<?').bind(now),env.DB.prepare('DELETE FROM community_newsletter_deliveries WHERE week_key<?').bind(new Date(now-90*86400000).toISOString().slice(0,10))]);return sendWeeklyNewsletter(env,()=>current(env.BUCKET),new Date(now));},async fetch(request,env){
  const url=new URL(request.url),path=url.pathname;
  try{
   if(path==='/sitemap.xml'||path==='/evenements'||path.startsWith('/evenements/')){if(!['GET','HEAD'].includes(request.method))return new Response('Méthode non autorisée',{status:405});const r=seoResponse(await current(env.BUCKET),url);return request.method==='HEAD'?new Response(null,{status:r.status,headers:r.headers}):r;}
   const unsubscribe=await unsubscribeNewsletter(request,env);if(unsubscribe)return unsubscribe;
   const social=await community(request,env,async id=>{const snap=await current(env.BUCKET);for(const shard of Object.values(snap.departments)){const row=shard.records.find(r=>r.id===id);if(row)return row;}return null;});if(social)return social;
   if(path==='/api/catalog/update'){
    if(request.method!=='POST')return json({error:'POST requis'},405);
    if(env.CATALOG_REQUIRE_TOKEN==='true'){if(typeof env.CATALOG_UPDATE_TOKEN!=='string'||env.CATALOG_UPDATE_TOKEN.length<32)return json({error:'Mise à jour non configurée'},503);const supplied=request.headers.get('Authorization')||'';const a=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(supplied))),b=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode('Bearer '+env.CATALOG_UPDATE_TOKEN)));let diff=0;for(let i=0;i<a.length;i++)diff|=a[i]^b[i];if(diff)return json({error:'Accès refusé'},401);}
    if(request.headers.get('Origin'))return json({error:'Mise à jour réservée au service'},403);
    if(request.headers.get('X-Pass-Cap-Update')!=='1')return json({error:'Requête de mise à jour invalide'},403);
    if(request.headers.get('Content-Type')!=='application/gzip')return json({error:'Format gzip requis'},415);
    if(!env.BUCKET)return json({error:'Stockage indisponible'},503);
    if(Number(request.headers.get('Content-Length'))>MAX_COMPRESSED)return json({error:'Import trop volumineux'},413);
    const bytes=await request.arrayBuffer();if(bytes.byteLength>MAX_COMPRESSED)return json({error:'Import trop volumineux'},413);
    let candidate,meta;try{candidate=await unpack(bytes);meta=validateSnapshot(candidate);}catch(e){return json({error:e.message},422);}
    const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),n=>n.toString(16).padStart(2,'0')).join('');
    const previous=await env.BUCKET.head(KEY);
    if(previous?.customMetadata?.sha256===digest)return json({ok:true,unchanged:true,...previous.customMetadata});
    if(previous&&Date.parse(previous.customMetadata.importedAt)>=Date.parse(meta.importedAt))return json({error:'Un import identique ou plus récent est déjà en ligne'},409);
    meta.sha256=digest;meta.updatedAt=new Date().toISOString();
    const onlyIf=new Headers(previous?{'If-Match':previous.httpEtag}:{'If-None-Match':'*'});
    const written=await env.BUCKET.put(KEY,bytes,{onlyIf,httpMetadata:{contentType:'application/gzip'},customMetadata:meta});
    if(!written)return json({error:'Une autre mise à jour est passée avant celle-ci. Relire le statut.'},409);
    cached=candidate;cachedTag=written.etag;return json({ok:true,...meta});
   }
   if(!['GET','HEAD'].includes(request.method))return json({error:'Méthode non autorisée'},405);
   if(path==='/api/catalog/status'){
    if(!env.BUCKET)return json({error:'Stockage indisponible'},503);
    const head=await env.BUCKET.head(KEY);return json(head?{persisted:true,...head.customMetadata}:{persisted:false});
   }
   if(path==='/data.json'||path==='/map-data.json'||path==='/carte.html'||/^\/data\/departments\/(?:\d{2,3}|2A|2B)\.json$/.test(path)){
    if(!env.BUCKET)return json({error:'Stockage indisponible'},503);
    const snapshot=await current(env.BUCKET);
    if(path==='/carte.html')return new Response(request.method==='HEAD'?null:snapshot.mapHtml,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}});
    const value=path==='/data.json'?snapshot.catalog:path==='/map-data.json'?snapshot.mapData:snapshot.departments[path.split('/').at(-1).replace('.json','')];
    return value?json(value):json({error:'Département inconnu'},404);
   }
   const asset=assets[path==='/'?'/index.html':path];if(!asset)return new Response('Page introuvable',{status:404});
   return new Response(request.method==='HEAD'?null:unbase64(asset.body),{headers:{'Content-Type':asset.type,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'}});
  }catch{return json({error:'Service momentanément indisponible. Dernier import conservé.'},503);}
 }};
}
