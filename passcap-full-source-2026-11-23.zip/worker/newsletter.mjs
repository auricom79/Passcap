import {renderMail,escapeHTML,sendMail} from './mail.mjs';
import {isEligibleRecord} from '../dist/content-policy.mjs';
const codes=new Set([...Array.from({length:95},(_,i)=>String(i+1).padStart(2,'0')).filter(c=>c!=='20'),'2A','2B','971','972','973','974','976']);
const enc=new TextEncoder(),hex=bytes=>Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
async function signature(env,id,consent){const key=await crypto.subtle.importKey('raw',enc.encode(env.PASSWORD_PEPPER),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',key,enc.encode('newsletter-unsubscribe:'+id+':'+consent)));}
const equal=(a,b)=>{if(a.length!==b.length)return false;let n=0;for(let i=0;i<a.length;i++)n|=a.charCodeAt(i)^b.charCodeAt(i);return n===0;};
export function selectNewsletterEvents(records,needs=[],now=new Date()){
 const end=+now+7*86400000;
 return records.filter(r=>r.type==='event'&&isEligibleRecord(r)&&needs.every(k=>r.features?.[k]?.value===true)).map(r=>({...r,newsletterSession:r.timings?.filter(t=>+new Date(t.end)>=+now&&+new Date(t.start)<end).sort((a,b)=>new Date(a.start)-new Date(b.start))[0]})).filter(r=>r.newsletterSession).sort((a,b)=>(Number(+new Date(a.newsletterSession.start)<+now)-Number(+new Date(b.newsletterSession.start)<+now))||new Date(a.newsletterSession.start)-new Date(b.newsletterSession.start)||a.title.localeCompare(b.title,'fr')).slice(0,6);
}
export function newsletterMail(rows,department,base,unsubscribe,now=new Date(),guest=false){
 const manage=guest?base+'/#newsletter=subscribe':base+'/#account=newsletter';
 const e=escapeHTML,title='Vos prochaines envies de sorties.',intro=rows.length?`Cette semaine, des idées de bons moments dans le département ${department}.`:'Aucune sortie correspondant à vos choix n’est renseignée cette semaine. Votre prochaine belle découverte vous attend peut-être dans un autre département.';
 const content=rows.map((r,i)=>{const url=base+'/?departement='+encodeURIComponent(r.department)+'&evenement='+encodeURIComponent(r.id),t=r.newsletterSession,ongoing=+new Date(t.start)<+now,date=(ongoing?'En cours · jusqu’au ':'')+new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'long',...(t.dateOnly?{}:{hour:'2-digit',minute:'2-digit'}),timeZone:r.timezone||'Europe/Paris'}).format(new Date(ongoing?t.end:t.start));return `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-bottom:14px"><tr><td style="border-left:7px solid ${['#b6a1ed','#eea782','#c5dbca'][i%3]};padding:16px;background:#f6f2e8;border-radius:14px"><p style="font-size:12px;margin:0 0 8px">${e(date)} · ${e(r.city)}</p><h2 style="font-size:20px;line-height:1.3;margin:0 0 12px"><a href="${e(url)}" style="color:#29243d;text-decoration:none">${e(r.title)}</a></h2><a href="${e(url)}" style="font-size:14px;font-weight:bold;color:#6147aa">Voir cette sortie ↗</a></td></tr></table>`;}).join('')+'<p style="font-size:13px;line-height:1.6">Les adaptations sont celles déclarées par les sources. Vérifiez les conditions auprès de l’organisateur avant votre visite.</p>';
 return {subject:'Pass Cap — Les sorties de votre semaine · '+department,text:title+'\n\n'+intro+'\n\n'+rows.map(r=>r.title+' · '+r.city+'\n'+base+'/?departement='+r.department+'&evenement='+encodeURIComponent(r.id)).join('\n\n')+'\n\nModifier mes choix : '+manage+'\nSe désinscrire : '+unsubscribe,html:renderMail({title,intro,content,url:manage,button:guest?'Modifier mon département':'Choisir mes prochaines envies',eyebrow:'VOTRE RENDEZ-VOUS DU JEUDI',footer:`Vous recevez ce mail parce que vous avez choisi la newsletter Pass Cap. <a href="${e(manage)}">Modifier mes choix</a> · <a href="${e(unsubscribe)}">Me désinscrire</a>`})};
}
export function createNewsletterRoutes({read,rate,session,fail,json}){return async(req,env,path)=>{
 if(path==='/api/community/newsletter/subscribe'||path==='/api/community/newsletter/confirm'){
  if(req.method!=='POST')fail(405,'method_not_allowed');
  const d=await read(req);await rate(env,'guest-newsletter-ip:'+(req.headers.get('CF-Connecting-IP')||'unknown'),10,3600000);
  if(!env.RESEND_API_KEY||!env.PASSWORD_PEPPER||!env.ACCOUNT_EMAIL_FROM)fail(503,'email_not_configured');
  if(path.endsWith('/confirm')){
   if(typeof d.token!=='string'||!/^[a-f0-9]{64}$/.test(d.token))fail(400,'invalid_email_link');
   const hash=hex(await crypto.subtle.digest('SHA-256',enc.encode(d.token))),now=Date.now();
   const result=await env.DB.batch([
    env.DB.prepare('INSERT INTO newsletter_guests(id,email,department,consent_at,updated_at) SELECT ?,email,department,?,? FROM newsletter_guest_tokens WHERE token_hash=? AND expires_at>? ON CONFLICT(email) DO UPDATE SET department=excluded.department,consent_at=excluded.consent_at,updated_at=excluded.updated_at').bind(crypto.randomUUID(),now,now,hash,now),
    env.DB.prepare('DELETE FROM newsletter_guest_tokens WHERE token_hash=?').bind(hash)
   ]);
   if(!result[0]?.meta?.changes)fail(400,'invalid_email_link');return json({ok:true});
  }
  const email=typeof d.email==='string'?d.email.trim().toLowerCase():'';
  if(email.length>254||! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))fail(400,'invalid_email');
  if(!codes.has(d.department)||d.consent!==true)fail(400,'invalid_newsletter');
  await rate(env,'guest-newsletter-email:'+email,3,3600000);
  const token=hex(crypto.getRandomValues(new Uint8Array(32))),hash=hex(await crypto.subtle.digest('SHA-256',enc.encode(token)));
  await env.DB.prepare('INSERT INTO newsletter_guest_tokens(token_hash,email,department,expires_at) VALUES(?,?,?,?) ON CONFLICT(email) DO UPDATE SET token_hash=excluded.token_hash,department=excluded.department,expires_at=excluded.expires_at').bind(hash,email,d.department,Date.now()+86400000).run();
  const url=env.APP_ORIGIN+'/#newsletter=confirm&token='+token,title='Vos idées de sorties arrivent bientôt.',intro='Confirmez votre inscription à la newsletter du département '+d.department+'. Aucun compte ni mot de passe ne sera créé. Ce lien est valable 24 heures.';
  try{await sendMail(env,email,{subject:'Pass Cap — Confirmez votre newsletter',text:intro+'\n\n'+url,html:renderMail({title,intro,url,button:'Confirmer mon inscription',eyebrow:'VOTRE RENDEZ-VOUS DU JEUDI',footer:'Vous avez demandé la newsletter Pass Cap. Si vous n’êtes pas à l’origine de cette demande, ignorez ce message : aucun abonnement ne sera activé.'})},'guest-confirm-'+hash);}catch{await env.DB.prepare('DELETE FROM newsletter_guest_tokens WHERE token_hash=?').bind(hash).run();fail(503,'mail_unavailable');}
  return json({ok:true});
 }
 if(path!=='/api/community/newsletter')return null;const u=await session(req,env);
 if(req.method==='GET'){const row=await env.DB.prepare('SELECT department,profile_filter,enabled FROM community_newsletters WHERE user_id=?').bind(u.id).first();return json({newsletter:row?{department:row.department,profileFilter:!!row.profile_filter,enabled:!!row.enabled}:null});}
 if(req.method!=='PATCH')fail(405,'method_not_allowed');const d=await read(req);await rate(env,'newsletter:'+u.id,20);
 if(typeof d.enabled!=='boolean')fail(400,'invalid_newsletter');if(!d.enabled){await env.DB.prepare('UPDATE community_newsletters SET enabled=0,updated_at=? WHERE user_id=?').bind(Date.now(),u.id).run();return json({ok:true});}
 if(!env.RESEND_API_KEY||!env.PASSWORD_PEPPER)fail(503,'email_not_configured');
 if(!codes.has(d.department)||typeof d.profileFilter!=='boolean'||d.consent!==true)fail(400,'invalid_newsletter');
 if(d.profileFilter&&!JSON.parse(u.needs_json||'[]').length)fail(400,'newsletter_needs_required');
 const now=Date.now();await env.DB.prepare('INSERT INTO community_newsletters(user_id,department,profile_filter,enabled,consent_at,updated_at) VALUES(?,?,?,1,?,?) ON CONFLICT(user_id) DO UPDATE SET department=excluded.department,profile_filter=excluded.profile_filter,enabled=1,consent_at=excluded.consent_at,updated_at=excluded.updated_at').bind(u.id,d.department,+d.profileFilter,now,now).run();await env.DB.prepare('DELETE FROM newsletter_guests WHERE email=?').bind(u.email.toLowerCase()).run();return json({ok:true});
};}
export async function unsubscribeNewsletter(req,env){
 const url=new URL(req.url);if(url.pathname!=='/api/newsletter/unsubscribe')return null;
 if(req.method!=='POST')return new Response('POST required',{status:405,headers:{Allow:'POST'}});
 const id=url.searchParams.get('id')||'',sig=url.searchParams.get('signature')||'';
 if(!/^[a-f0-9-]{36}$/.test(id)||!/^[a-f0-9]{64}$/.test(sig))return Response.json({error:'invalid_link'},{status:400});
 if(url.searchParams.get('kind')==='guest'){
  const row=await env.DB.prepare('SELECT consent_at FROM newsletter_guests WHERE id=?').bind(id).first();
  if(!row||!equal(sig,await signature(env,'guest:'+id,row.consent_at)))return Response.json({error:'invalid_link'},{status:400});
  await env.DB.prepare('DELETE FROM newsletter_guests WHERE id=? AND consent_at=?').bind(id,row.consent_at).run();return Response.json({ok:true},{headers:{'Cache-Control':'no-store'}});
 }
 const row=await env.DB.prepare('SELECT consent_at FROM community_newsletters WHERE user_id=?').bind(id).first();if(!row||!equal(sig,await signature(env,id,row.consent_at)))return Response.json({error:'invalid_link'},{status:400});
 await env.DB.prepare('UPDATE community_newsletters SET enabled=0,updated_at=? WHERE user_id=?').bind(Date.now(),id).run();return Response.json({ok:true},{headers:{'Cache-Control':'no-store'}});
}
export async function sendWeeklyNewsletter(env,snapshot,now=new Date()){
 if(env.NEWSLETTER_ENABLED!=='true'||!env.RESEND_API_KEY||!env.PASSWORD_PEPPER)return {sent:0};
 const p=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Paris',weekday:'short',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',hourCycle:'h23'}).formatToParts(now).map(p=>[p.type,p.value]));
 if(p.weekday!=='Thu'||+p.hour<18||+p.hour>22)return {sent:0};const week=p.year+'-'+p.month+'-'+p.day;let sent=0;
 if(typeof snapshot==='function')snapshot=await snapshot();
 const rows=(await env.DB.prepare("SELECT n.*,u.email,u.needs_json FROM community_newsletters n JOIN community_users u ON u.id=n.user_id LEFT JOIN community_newsletter_deliveries d ON d.user_id=n.user_id AND d.week_key=? WHERE n.enabled=1 AND (d.user_id IS NULL OR (d.status='pending' AND d.lease_until<?)) LIMIT 50").bind(week,+now).all()).results;
 for(const r of rows){
  const lease=await env.DB.prepare("INSERT INTO community_newsletter_deliveries(user_id,week_key,status,lease_until) VALUES(?,?,'pending',?) ON CONFLICT(user_id,week_key) DO UPDATE SET lease_until=excluded.lease_until WHERE status='pending' AND lease_until<? RETURNING user_id").bind(r.user_id,week,+now+300000,+now).first();if(!lease)continue;
  const needs=r.profile_filter?JSON.parse(r.needs_json||'[]'):[],records=snapshot.departments[r.department]?.records||[],events=r.profile_filter&&!needs.length?[]:selectNewsletterEvents(records,needs,now),sig=await signature(env,r.user_id,r.consent_at),base=env.APP_ORIGIN;
  const query='id='+encodeURIComponent(r.user_id)+'&signature='+sig,unsubscribe=base+'/#account=unsubscribe&'+query,oneClick=base+'/api/newsletter/unsubscribe?'+query;
  // Re-check consent after taking the lease, before sending.
  const active=await env.DB.prepare('SELECT enabled,updated_at FROM community_newsletters WHERE user_id=?').bind(r.user_id).first();if(!active?.enabled||active.updated_at!==r.updated_at)continue;
  try{await sendMail(env,r.email,newsletterMail(events,r.department,base,unsubscribe,now),'newsletter-'+r.user_id+'-'+week,{'List-Unsubscribe':'<'+oneClick+'>','List-Unsubscribe-Post':'List-Unsubscribe=One-Click'});await env.DB.prepare("UPDATE community_newsletter_deliveries SET status='sent' WHERE user_id=? AND week_key=?").bind(r.user_id,week).run();sent++;}catch{console.warn('newsletter_delivery_failed');}
 }
 const guests=(await env.DB.prepare("SELECT g.* FROM newsletter_guests g LEFT JOIN newsletter_guest_deliveries d ON d.guest_id=g.id AND d.week_key=? WHERE (d.guest_id IS NULL OR (d.status='pending' AND d.lease_until<?)) AND NOT EXISTS(SELECT 1 FROM community_newsletters n JOIN community_users u ON u.id=n.user_id WHERE n.enabled=1 AND lower(u.email)=g.email) LIMIT 50").bind(week,+now).all()).results;
 for(const g of guests){
  const lease=await env.DB.prepare("INSERT INTO newsletter_guest_deliveries(guest_id,week_key,status,lease_until) VALUES(?,?,'pending',?) ON CONFLICT(guest_id,week_key) DO UPDATE SET lease_until=excluded.lease_until WHERE status='pending' AND lease_until<? RETURNING guest_id").bind(g.id,week,+now+300000,+now).first();if(!lease)continue;
  const active=await env.DB.prepare('SELECT updated_at FROM newsletter_guests WHERE id=?').bind(g.id).first();if(active?.updated_at!==g.updated_at)continue;
  const sig=await signature(env,'guest:'+g.id,g.consent_at),query='kind=guest&id='+encodeURIComponent(g.id)+'&signature='+sig,base=env.APP_ORIGIN,unsubscribe=base+'/#account=unsubscribe&'+query,oneClick=base+'/api/newsletter/unsubscribe?'+query;
  try{await sendMail(env,g.email,newsletterMail(selectNewsletterEvents(snapshot.departments[g.department]?.records||[],[],now),g.department,base,unsubscribe,now,true),'guest-newsletter-'+g.id+'-'+week,{'List-Unsubscribe':'<'+oneClick+'>','List-Unsubscribe-Post':'List-Unsubscribe=One-Click'});await env.DB.prepare("UPDATE newsletter_guest_deliveries SET status='sent' WHERE guest_id=? AND week_key=?").bind(g.id,week).run();sent++;}catch{console.warn('guest_newsletter_delivery_failed');}
 }
 return {sent};
}
