import {createNewsletterRoutes} from './newsletter.mjs';
import {createEmailAuth,emailReady} from './email-auth.mjs';
// Adapted from MyWorkshops accounts.ts: signed Google identity, one-use nonce,
// hashed opaque sessions, exact-origin writes, bound SQL and raster-only avatars.
// Separate identity store: no MyWorkshops account, cookie or private data is shared.
export function createCommunityHandler(){
 const enc=new TextEncoder(),DAY=86400000,COOKIE='__Host-pc_session',CHALLENGE='__Host-pc_challenge';
 const json=(v,status=200,headers={})=>Response.json(v,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
 const fail=(status,error)=>{throw Object.assign(new Error(error),{status});};
 const random=()=>Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');
 const hash=async v=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(v))),b=>b.toString(16).padStart(2,'0')).join('');
 const cookies=req=>Object.fromEntries((req.headers.get('Cookie')||'').split(';').map(s=>s.trim().split('=')));
 const cookie=(key,value,age)=>`${key}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${age}`;
 const publicUser=u=>({id:u.id,pseudo:u.pseudo,avatar:u.avatar,profileComplete:!!u.profile_complete});
 const ownUser=(u,env)=>({...publicUser(u),email:u.email,needs:JSON.parse(u.needs_json||'[]'),needsConsentAt:u.needs_consent_at||null,autoFilter:u.auto_filter!==0,admin:admin(u,env)});
 const admin=(u,env)=>!!env.COMMUNITY_ADMIN_GOOGLE_SUB&&u?.google_sub===env.COMMUNITY_ADMIN_GOOGLE_SUB;
 const ready=env=>!!env.DB&&/^\d+-[a-z0-9]+\.apps\.googleusercontent\.com$/.test(env.GOOGLE_CLIENT_ID||'');
 const validId=id=>typeof id==='string'&&id.length>0&&id.length<=255&&!/[\u0000-\u001f]/.test(id);
 async function read(req){
  if(!req.headers.get('Content-Type')?.toLowerCase().startsWith('application/json'))fail(415,'json_required');
  const reader=req.body?.getReader();if(!reader)fail(400,'invalid_json');let size=0,text='';const decoder=new TextDecoder();
  while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>60000){await reader.cancel();fail(413,'body_too_large');}text+=decoder.decode(value,{stream:true});}text+=decoder.decode();
  try{const data=JSON.parse(text);if(!data||typeof data!=='object'||Array.isArray(data))throw Error();return data;}catch{fail(400,'invalid_json');}
 }
 async function rate(env,key,max,window=60000){
  const now=Date.now(),bucket=await hash(key+':'+Math.floor(now/window));
  const row=await env.DB.prepare('INSERT INTO community_limits(bucket,count,expires_at) VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET count=count+1 RETURNING count').bind(bucket,now+window*2).first();
  if(!row||row.count>max)fail(429,'rate_limited');
 }
 async function session(req,env,required=true){
  const token=cookies(req)[COOKIE]||'';if(!/^[a-f0-9]{64}$/.test(token)){if(required)fail(401,'login_required');return null;}
  const row=await env.DB.prepare('SELECT u.*,s.created_at AS session_created FROM community_sessions s JOIN community_users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?').bind(await hash(token),Date.now()).first();
  if(!row&&required)fail(401,'login_required');return row;
 }
 function avatar(value){
  if(['sun','coral','leaf','star','wave','violet','bird','moon'].includes(value))return value;
  if(typeof value==='string'&&value.length<=44000&&/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(value)){
   let raw;try{raw=Uint8Array.from(atob(value.split(',')[1]),c=>c.charCodeAt(0));}catch{fail(400,'invalid_avatar');}
   const mime=value.slice(5,value.indexOf(';')),png=raw[0]===137&&raw[1]===80&&raw[2]===78&&raw[3]===71,jpg=raw[0]===255&&raw[1]===216&&raw[2]===255,webp=String.fromCharCode(...raw.slice(0,4))==='RIFF'&&String.fromCharCode(...raw.slice(8,12))==='WEBP';
   if(raw.length<=32768&&((mime==='image/png'&&png)||(mime==='image/jpeg'&&jpg)||(mime==='image/webp'&&webp)))return value;
  }fail(400,'invalid_avatar');
 }
 let googleKeys=null,googleKeysUntil=0;
 async function googleIdentity(token,audience,nonce){
  const decode=s=>{try{return Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));}catch{fail(401,'invalid_identity');}};
  const part=s=>{try{return JSON.parse(new TextDecoder().decode(decode(s)));}catch{fail(401,'invalid_identity');}};
  if(typeof token!=='string'||token.length>20000)fail(401,'invalid_identity');const parts=token.split('.');if(parts.length!==3)fail(401,'invalid_identity');
  const h=part(parts[0]),c=part(parts[1]),now=Date.now()/1000;
  if(h?.alg!=='RS256'||typeof h.kid!=='string'||!c||!['https://accounts.google.com','accounts.google.com'].includes(c.iss)||c.aud!==audience||c.nonce!==nonce||!Number.isFinite(c.exp)||c.exp<=now||!Number.isFinite(c.iat)||c.iat>now+60||c.iat<now-3600||typeof c.sub!=='string'||!c.sub||c.sub.length>255||c.azp&&c.azp!==audience||c.email_verified!==true||typeof c.email!=='string'||c.email.length>254||!/^\S+@\S+\.\S+$/.test(c.email))fail(401,'invalid_identity');
  if(!googleKeys||Date.now()>googleKeysUntil||!googleKeys.some(k=>k.kid===h.kid)){
   let r;try{r=await fetch('https://www.googleapis.com/oauth2/v3/certs',{redirect:'manual',signal:AbortSignal.timeout(10000)});}catch{fail(503,'google_unavailable');}
   if(!r.ok)fail(503,'google_unavailable');const body=await r.json();if(!Array.isArray(body.keys))fail(503,'google_unavailable');googleKeys=body.keys;googleKeysUntil=Date.now()+3600000;
  }
  const jwk=googleKeys.find(k=>k.kid===h.kid&&k.kty==='RSA'&&k.alg==='RS256'&&(!k.use||k.use==='sig'));if(!jwk)fail(401,'invalid_identity');
  try{const key=await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);if(!await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,decode(parts[2]),enc.encode(parts[0]+'.'+parts[1])))fail(401,'invalid_identity');}catch{fail(401,'invalid_identity');}return c;
 }
 const newsletterRoutes=createNewsletterRoutes({read,rate,session,fail,json});
 const emailRoutes=createEmailAuth({read,rate,session,ownUser,random,hash,cookie,COOKIE,fail,json});
 const summary=r=>({id:r.id,title:r.title,city:r.city,department:r.department,timezone:r.timezone,timings:r.timings,sourceUrl:r.sourceUrl});
 return async function communityRoutes(req,env,getEvent){
  const url=new URL(req.url),path=url.pathname;
  if(!path.startsWith('/api/community/'))return null;
  try{
   if(env.APP_ORIGIN&&url.origin!==env.APP_ORIGIN)fail(403,'origin_forbidden');
   const origin=req.headers.get('Origin');if(origin&&origin!==url.origin)fail(403,'origin_forbidden');
   if(!['GET','HEAD'].includes(req.method)&&origin!==url.origin)fail(403,'origin_required');
   if(path==='/api/community/config'&&req.method==='GET')return json({google:ready(env),clientId:ready(env)?env.GOOGLE_CLIENT_ID:null,email:emailReady(env)});
   if(!env.DB)fail(503,'community_unavailable');
   const emailResponse=await emailRoutes(req,env,path);if(emailResponse)return emailResponse;
   const newsletterResponse=await newsletterRoutes(req,env,path);if(newsletterResponse)return newsletterResponse;
   if(path==='/api/community/me'&&req.method==='GET'){const u=await session(req,env,false);return json({user:u?ownUser(u,env):null});}
   if(path==='/api/community/google/challenge'&&req.method==='POST'){
    if(!ready(env))fail(503,'google_not_configured');await read(req);await rate(env,'login:'+ (req.headers.get('CF-Connecting-IP')||'unknown'),20,600000);
    const nonce=random(),browser=random();await env.DB.batch([env.DB.prepare('DELETE FROM community_challenges WHERE expires_at<?').bind(Date.now()),env.DB.prepare('DELETE FROM community_sessions WHERE expires_at<?').bind(Date.now()),env.DB.prepare('DELETE FROM community_limits WHERE expires_at<?').bind(Date.now()),env.DB.prepare('INSERT INTO community_challenges(nonce_hash,browser_hash,expires_at) VALUES(?,?,?)').bind(await hash(nonce),await hash(browser),Date.now()+600000)]);
    return json({nonce,clientId:env.GOOGLE_CLIENT_ID},200,{'Set-Cookie':cookie(CHALLENGE,browser,600)});
   }
   if(path==='/api/community/google'&&req.method==='POST'){
    if(!ready(env))fail(503,'google_not_configured');await rate(env,'verify:'+(req.headers.get('CF-Connecting-IP')||'unknown'),30,600000);const d=await read(req),browser=cookies(req)[CHALLENGE]||'';
    if(!/^[a-f0-9]{64}$/.test(d.nonce||'')||!/^[a-f0-9]{64}$/.test(browser))fail(401,'invalid_challenge');
    const transaction=await env.DB.prepare('SELECT nonce_hash FROM community_challenges WHERE nonce_hash=? AND browser_hash=? AND expires_at>?').bind(await hash(d.nonce),await hash(browser),Date.now()).first();if(!transaction)fail(401,'invalid_challenge');
    const claims=await googleIdentity(d.credential,env.GOOGLE_CLIENT_ID,d.nonce);
    if(!await env.DB.prepare('DELETE FROM community_challenges WHERE nonce_hash=? AND browser_hash=? AND expires_at>? RETURNING nonce_hash').bind(await hash(d.nonce),await hash(browser),Date.now()).first())fail(401,'invalid_challenge');
    const id=crypto.randomUUID(),now=Date.now();await env.DB.prepare("INSERT INTO community_users(id,google_sub,email,pseudo,avatar,created_at) VALUES(?,?,?,?,'sun',?) ON CONFLICT(google_sub) DO UPDATE SET email=excluded.email").bind(id,claims.sub,claims.email.trim().toLowerCase(),'Cap '+id.slice(0,6),now).run();
    const u=await env.DB.prepare('SELECT * FROM community_users WHERE google_sub=?').bind(claims.sub).first(),token=random();
    await env.DB.prepare('INSERT INTO community_sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)').bind(await hash(token),u.id,now,now+30*DAY).run();
    const response=json({user:ownUser(u,env)},200,{'Set-Cookie':cookie(COOKIE,token,30*86400)});response.headers.append('Set-Cookie',cookie(CHALLENGE,'',0));return response;
   }
   if(path==='/api/community/logout'&&req.method==='POST'){await read(req);const token=cookies(req)[COOKIE]||'';await env.DB.prepare('DELETE FROM community_sessions WHERE token_hash=?').bind(await hash(token)).run();return json({ok:true},200,{'Set-Cookie':cookie(COOKIE,'',0)});}
   if(path==='/api/community/preferences'&&req.method==='PATCH'){
    const u=await session(req,env),d=await read(req);await rate(env,'preferences:'+u.id,30);if(typeof d.autoFilter!=='boolean')fail(400,'invalid_preference');await env.DB.prepare('UPDATE community_users SET auto_filter=? WHERE id=?').bind(+d.autoFilter,u.id).run();return json({user:ownUser({...u,auto_filter:+d.autoFilter},env)});
   }
   if(path==='/api/community/profile'&&req.method==='PATCH'){
    const u=await session(req,env),d=await read(req);await rate(env,'profile:'+u.id,10);
    const pseudo=typeof d.pseudo==='string'?d.pseudo.replace(/[\u0000-\u001f\u007f]/g,'').trim():'';if(pseudo.length<2||pseudo.length>40)fail(400,'invalid_pseudo');
    const image=d.avatar===undefined?u.avatar:avatar(d.avatar);
    const allowed=['motor','hearing','visual','mental','autism','psychic'];let needs=JSON.parse(u.needs_json||'[]'),consent=u.needs_consent_at||null;
    if(d.needs!==undefined){if(!Array.isArray(d.needs)||d.needs.length>6||d.needs.some(n=>!allowed.includes(n))||new Set(d.needs).size!==d.needs.length)fail(400,'invalid_needs');if(d.needs.length&&d.needsConsent!==true)fail(400,'needs_consent_required');needs=allowed.filter(n=>d.needs.includes(n));consent=needs.length?(consent||Date.now()):null;}
    const needsJSON=JSON.stringify(needs);await env.DB.prepare('UPDATE community_users SET pseudo=?,avatar=?,profile_complete=1,needs_json=?,needs_consent_at=? WHERE id=?').bind(pseudo,image,needsJSON,consent,u.id).run();return json({user:ownUser({...u,pseudo,avatar:image,profile_complete:1,needs_json:needsJSON,needs_consent_at:consent},env)});
   }
   if(path==='/api/community/profile'&&req.method==='DELETE'){
    const u=await session(req,env),d=await read(req);if(d.confirm!=='SUPPRIMER')fail(400,'confirmation_required');if(u.session_created<Date.now()-15*60000)fail(401,'recent_login_required');
    await env.DB.batch([env.DB.prepare('DELETE FROM community_email_tokens WHERE user_id=?').bind(u.id),env.DB.prepare('DELETE FROM community_users WHERE id=?').bind(u.id)]);return json({ok:true},200,{'Set-Cookie':cookie(COOKIE,'',0)});
   }
   if(path==='/api/community/marks'&&req.method==='GET'){
    const u=await session(req,env),offset=Math.min(10000,Math.max(0,Number(url.searchParams.get('offset'))||0));
    const rows=(await env.DB.prepare('SELECT event_summary,favorite,interested,visible FROM community_marks WHERE user_id=? AND (favorite=1 OR interested=1) ORDER BY updated_at DESC LIMIT 51 OFFSET ?').bind(u.id,Math.floor(offset)).all()).results;
    return json({items:rows.slice(0,50).map(r=>({...JSON.parse(r.event_summary),favorite:!!r.favorite,interested:!!r.interested,visible:!!r.visible})),more:rows.length>50});
   }
   if(path==='/api/community/blocks'&&req.method==='GET'){
    const u=await session(req,env),rows=(await env.DB.prepare('SELECT u.id,u.pseudo,u.avatar FROM community_blocks b JOIN community_users u ON u.id=b.blocked_id WHERE b.user_id=? ORDER BY b.created_at DESC LIMIT 200').bind(u.id).all()).results;return json({items:rows});
   }
   if(path==='/api/community/blocks'&&req.method==='POST'){
    const u=await session(req,env),d=await read(req);await rate(env,'block:'+u.id,15);if(!validId(d.userId)||d.userId===u.id||typeof d.blocked!=='boolean')fail(400,'invalid_member');
    if(d.blocked){if(!await env.DB.prepare('SELECT id FROM community_users WHERE id=?').bind(d.userId).first())fail(404,'member_not_found');await env.DB.prepare('INSERT OR IGNORE INTO community_blocks(user_id,blocked_id,created_at) VALUES(?,?,?)').bind(u.id,d.userId,Date.now()).run();}else await env.DB.prepare('DELETE FROM community_blocks WHERE user_id=? AND blocked_id=?').bind(u.id,d.userId).run();return json({ok:true});
   }
   if(path==='/api/community/moderation'&&req.method==='GET'){
    const u=await session(req,env);if(!admin(u,env))fail(403,'admin_required');const rows=(await env.DB.prepare('SELECT c.id,c.event_id,c.body,c.hidden,u.pseudo,COUNT(r.user_id) AS reports FROM community_reports r JOIN community_comments c ON c.id=r.comment_id JOIN community_users u ON u.id=c.user_id GROUP BY c.id ORDER BY c.id DESC LIMIT 100').all()).results;return json({items:rows});
   }
   if(path==='/api/community/moderation'&&req.method==='POST'){
    const u=await session(req,env);if(!admin(u,env))fail(403,'admin_required');const d=await read(req);if(!Number.isSafeInteger(d.commentId)||typeof d.hidden!=='boolean')fail(400,'invalid_comment');await env.DB.prepare('UPDATE community_comments SET hidden=? WHERE id=?').bind(+d.hidden,d.commentId).run();return json({ok:true});
   }
   const commentPath=/^\/api\/community\/comments\/(\d+)(\/report)?$/.exec(path);
   if(commentPath){
    const u=await session(req,env),id=Number(commentPath[1]);if(!Number.isSafeInteger(id))fail(400,'invalid_comment');
    if(commentPath[2]&&req.method==='POST'){
     const d=await read(req);await rate(env,'report:'+u.id,5,3600000);if(typeof d.reason!=='string'||d.reason.trim().length<3||d.reason.length>300)fail(400,'invalid_reason');if(!await env.DB.prepare('SELECT id FROM community_comments WHERE id=? AND hidden=0').bind(id).first())fail(404,'comment_not_found');await env.DB.prepare('INSERT OR IGNORE INTO community_reports(comment_id,user_id,reason,created_at) VALUES(?,?,?,?)').bind(id,u.id,d.reason.trim(),Date.now()).run();return json({ok:true});
    }
    if(!commentPath[2]&&req.method==='DELETE'){
     await read(req);const result=admin(u,env)?await env.DB.prepare('DELETE FROM community_comments WHERE id=?').bind(id).run():await env.DB.prepare('DELETE FROM community_comments WHERE id=? AND user_id=?').bind(id,u.id).run();if(!result.meta.changes)fail(404,'comment_not_found');return json({ok:true});
    }fail(405,'method_not_allowed');
   }
   if(path==='/api/community/stats'&&req.method==='POST'){
    const d=await read(req);if(!Array.isArray(d.ids)||d.ids.length>100||d.ids.some(id=>!validId(id)))fail(400,'invalid_events');
    const ids=[...new Set(d.ids)];if(!ids.length)return json({items:[]});await rate(env,'stats:'+(req.headers.get('CF-Connecting-IP')||'unknown'),120);
    const placeholders=ids.map(()=>'?').join(',');
    const marks=(await env.DB.prepare('SELECT event_id,SUM(interested) AS interested,SUM(favorite) AS favorites FROM community_marks WHERE event_id IN ('+placeholders+') GROUP BY event_id').bind(...ids).all()).results;
    const comments=(await env.DB.prepare('SELECT event_id,COUNT(*) AS comments FROM community_comments WHERE hidden=0 AND event_id IN ('+placeholders+') GROUP BY event_id').bind(...ids).all()).results;
    const counts=new Map(ids.map(id=>[id,{id,interested:0,favorites:0,comments:0}]));for(const row of marks)Object.assign(counts.get(row.event_id),{interested:row.interested,favorites:row.favorites});for(const row of comments)counts.get(row.event_id).comments=row.comments;
    return json({items:[...counts.values()]});
   }
   if(path==='/api/community/event'){
    const id=url.searchParams.get('id');if(!validId(id))fail(400,'invalid_event');
    if(req.method==='GET'){
     const u=await session(req,env,false),before=Number(url.searchParams.get('before')||Number.MAX_SAFE_INTEGER);if(!Number.isSafeInteger(before)||before<1)fail(400,'invalid_cursor');
     const mark=u?await env.DB.prepare('SELECT favorite,interested,visible FROM community_marks WHERE user_id=? AND event_id=?').bind(u.id,id).first():null;
     const total=await env.DB.prepare('SELECT COUNT(*) AS n FROM community_marks WHERE event_id=? AND interested=1').bind(id).first();
     const uid=u?.id||'';
     const exclusion='NOT EXISTS(SELECT 1 FROM community_blocks b WHERE (b.user_id=? AND b.blocked_id=u.id) OR (b.user_id=u.id AND b.blocked_id=?))';
     const rows=(await env.DB.prepare(`SELECT c.id,c.body,c.created_at,u.id AS user_id,u.pseudo,u.avatar FROM community_comments c JOIN community_users u ON u.id=c.user_id WHERE c.event_id=? AND c.hidden=0 AND c.id<? AND ${exclusion} ORDER BY c.id DESC LIMIT 31`).bind(id,before,uid,uid).all()).results;
     const participants=(await env.DB.prepare(`SELECT u.id,u.pseudo,u.avatar FROM community_marks m JOIN community_users u ON u.id=m.user_id WHERE m.event_id=? AND m.interested=1 AND m.visible=1 AND ${exclusion} ORDER BY m.updated_at DESC LIMIT 20`).bind(id,uid,uid).all()).results;
     return json({favorite:!!mark?.favorite,interested:!!mark?.interested,visible:!!mark?.visible,interestedCount:total.n,participants,comments:rows.slice(0,30).reverse().map(r=>({id:r.id,body:r.body,createdAt:r.created_at,user:{id:r.user_id,pseudo:r.pseudo,avatar:r.avatar},mine:r.user_id===uid})),before:rows.length>30?rows[29].id:null});
    }
    const u=await session(req,env),d=await read(req);await rate(env,'event-write:'+u.id,30);
    let event;
    if(req.method==='PATCH'){
     for(const k of ['favorite','interested','visible'])if(typeof d[k]!=='boolean')fail(400,'invalid_mark');
     if(d.favorite||d.interested){event=await getEvent(id);if(!event||event.type!=='event'){const previous=await env.DB.prepare('SELECT favorite,interested,visible,event_summary FROM community_marks WHERE user_id=? AND event_id=?').bind(u.id,id).first();if(!previous||d.favorite&&!previous.favorite||d.interested&&!previous.interested||d.visible&&!previous.visible)fail(404,'event_not_found');event=JSON.parse(previous.event_summary);}}
     if(!d.favorite&&!d.interested)await env.DB.prepare('DELETE FROM community_marks WHERE user_id=? AND event_id=?').bind(u.id,id).run();
     else await env.DB.prepare('INSERT INTO community_marks(user_id,event_id,favorite,interested,visible,event_summary,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_id,event_id) DO UPDATE SET favorite=excluded.favorite,interested=excluded.interested,visible=excluded.visible,event_summary=excluded.event_summary,updated_at=excluded.updated_at').bind(u.id,id,+d.favorite,+d.interested,+(d.interested&&d.visible),JSON.stringify(summary(event)),Date.now()).run();return json({ok:true});
    }
    if(req.method==='POST'){
     event=await getEvent(id);if(!event||event.type!=='event')fail(404,'event_not_found');
     if(!u.profile_complete)fail(403,'profile_required');const text=typeof d.body==='string'?d.body.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g,'').trim():'';if(!text||text.length>2000)fail(400,'invalid_message');
     await rate(env,'comment:'+u.id,5);await rate(env,'comment-day:'+u.id,100,DAY);
     const row=await env.DB.prepare('INSERT INTO community_comments(event_id,user_id,body,created_at) VALUES(?,?,?,?) RETURNING id').bind(id,u.id,text,Date.now()).first();return json({ok:true,id:row.id},201);
    }fail(405,'method_not_allowed');
   }
   fail(404,'not_found');
  }catch(e){return json({error:e.status?e.message:'community_unavailable'},e.status||503);}
 };
}
