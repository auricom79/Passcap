import {sendMail,securityMail} from './mail.mjs';
// Email credentials remain separate from Google subjects. Linking requires an
// authenticated member plus confirmation in their current account's mailbox.
export const emailReady=env=>!!env.RESEND_API_KEY&&/^Pass Cap <[^<>\s]+@passcap\.org>$/.test(env.ACCOUNT_EMAIL_FROM||'')&&(env.PASSWORD_PEPPER||'').length>=32;
const encoder=new TextEncoder();
export async function passwordDigest(password,salt,pepper){
 const hmac=await crypto.subtle.importKey('raw',encoder.encode(pepper),{name:'HMAC',hash:'SHA-256'},false,['sign']);
 const material=await crypto.subtle.sign('HMAC',hmac,encoder.encode(password));
 const key=await crypto.subtle.importKey('raw',material,'PBKDF2',false,['deriveBits']);
 // Workers supports at most 100,000 PBKDF2 iterations. A separate 256-bit server
 // pepper prevents offline guessing from a database-only compromise.
 return Array.from(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:encoder.encode(salt),iterations:100000},key,256)),b=>b.toString(16).padStart(2,'0')).join('');
}
const equal=(a,b)=>{if(a.length!==b.length)return false;let n=0;for(let i=0;i<a.length;i++)n|=a.charCodeAt(i)^b.charCodeAt(i);return n===0;};
export function createEmailAuth({read,rate,session,ownUser,random,hash,cookie,COOKIE,fail,json}){
 const email=value=>{const v=typeof value==='string'?value.trim().toLowerCase():'';if(v.length>254||!/^([^\s@]+)@([^\s@]+)\.[^\s@]+$/.test(v))fail(400,'invalid_email');return v;};
 const password=value=>{if(typeof value!=='string'||[...value].length<12||value.length>128)fail(400,'invalid_password');return value;};
 async function send(env,to,kind,token){
  const link=env.APP_ORIGIN+'/#account='+kind+(token?'&token='+token:'');
  try{await sendMail(env,to,securityMail(kind,link),token?'security-'+await hash(token):undefined);}catch{fail(503,'mail_unavailable');}
 }
 async function issue(env,kind,id,address,digest=null,salt=null){
  const token=random(),tokenHash=await hash(token),now=Date.now();await env.DB.batch([env.DB.prepare('DELETE FROM community_email_tokens WHERE expires_at<? OR (email=? AND kind=?)').bind(now,address,kind),env.DB.prepare('INSERT INTO community_email_tokens(token_hash,kind,user_id,email,password_hash,salt,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?)').bind(tokenHash,kind,id,address,digest,salt,now,now+1800000)]);
  try{await send(env,address,kind==='reset'?'reset':'verify',token);}catch(e){await env.DB.prepare('DELETE FROM community_email_tokens WHERE token_hash=?').bind(tokenHash).run();throw e;}
 }
 async function signedIn(env,id){
  const u=await env.DB.prepare('SELECT * FROM community_users WHERE id=?').bind(id).first();if(!u)fail(400,'invalid_email_link');
  const token=random(),now=Date.now();await env.DB.prepare('INSERT INTO community_sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)').bind(await hash(token),id,now,now+30*86400000).run();
  return json({user:ownUser(u,env)},200,{'Set-Cookie':cookie(COOKIE,token,30*86400)});
 }
 return async(req,env,path)=>{
  if(!path.startsWith('/api/community/email/'))return null;
  if(req.method!=='POST')fail(405,'method_not_allowed');if(!emailReady(env))fail(503,'email_not_configured');
  const action=path.slice('/api/community/email/'.length),d=await read(req),ip=req.headers.get('CF-Connecting-IP')||'unknown';
  await rate(env,'email:'+action+':'+ip,action==='login'?20:8,600000);
  if(action==='register'||action==='forgot'||action==='password'){
   const u=action==='password'?await session(req,env):null,address=email(u?u.email:d.email);
   if(u&&u.session_created<Date.now()-15*60000)fail(401,'recent_login_required');
   const plain=action==='forgot'?null:password(d.password);await rate(env,'email-target:'+address,5,3600000);
   if(action==='forgot'){
    const row=await env.DB.prepare('SELECT user_id FROM community_passwords WHERE email=?').bind(address).first();if(row)await issue(env,'reset',row.user_id,address);
    return json({ok:true});
   }
   if(action==='register'){
    const existing=await env.DB.prepare('SELECT id FROM community_users WHERE lower(email)=? LIMIT 1').bind(address).first();
    if(existing){await send(env,address,'existing');return json({ok:true});}
   }
   const salt=random(),digest=await passwordDigest(plain,salt,env.PASSWORD_PEPPER);await issue(env,u?'password':'signup',u?.id||crypto.randomUUID(),address,digest,salt);return json({ok:true});
  }
  if(action==='login'){
   const address=email(d.email),plain=typeof d.password==='string'&&d.password.length<=128?d.password:'';await rate(env,'email-login:'+address,12,600000);
   const row=await env.DB.prepare('SELECT * FROM community_passwords WHERE email=?').bind(address).first();
   const digest=await passwordDigest(plain,row?.salt||'passcap-invalid-credentials',env.PASSWORD_PEPPER);
   if(!row||!equal(digest,row.password_hash))fail(401,'invalid_credentials');return signedIn(env,row.user_id);
  }
  if(action==='verify'||action==='reset'){
   if(!/^[a-f0-9]{64}$/.test(d.token||''))fail(400,'invalid_email_link');
   const tokenHash=await hash(d.token),now=Date.now(),row=await env.DB.prepare('SELECT * FROM community_email_tokens WHERE token_hash=? AND expires_at>?').bind(tokenHash,now).first();
   if(!row||(action==='reset')!==(row.kind==='reset'))fail(400,'invalid_email_link');
   let digest=row.password_hash,salt=row.salt;if(action==='reset'){salt=random();digest=await passwordDigest(password(d.password),salt,env.PASSWORD_PEPPER);}
   // All writes are in one atomic D1 batch. Each mutation is conditional on the
   // still-live token; concurrent replays cannot overwrite credentials.
   const active='EXISTS(SELECT 1 FROM community_email_tokens WHERE token_hash=? AND expires_at>?)';
   const statements=[];
   if(row.kind==='signup')statements.push(env.DB.prepare("INSERT INTO community_users(id,google_sub,email,pseudo,avatar,created_at) SELECT ?,?,?,?,'sun',? WHERE "+active+" AND NOT EXISTS(SELECT 1 FROM community_users WHERE lower(email)=?) ON CONFLICT(id) DO NOTHING").bind(row.user_id,'email:'+row.user_id,row.email,'Cap '+row.user_id.slice(0,6),now,tokenHash,now,row.email));
   statements.push(env.DB.prepare('INSERT INTO community_passwords(user_id,email,password_hash,salt,verified_at) SELECT ?,?,?,?,? WHERE '+active+' AND EXISTS(SELECT 1 FROM community_users WHERE id=?) ON CONFLICT(user_id) DO UPDATE SET password_hash=excluded.password_hash,salt=excluded.salt,verified_at=excluded.verified_at').bind(row.user_id,row.email,digest,salt,now,tokenHash,now,row.user_id));
   statements.push(env.DB.prepare('DELETE FROM community_sessions WHERE user_id=? AND '+active).bind(row.user_id,tokenHash,now));
   statements.push(env.DB.prepare('DELETE FROM community_email_tokens WHERE token_hash=? AND expires_at>? RETURNING token_hash').bind(tokenHash,now));
   const results=await env.DB.batch(statements);if(results.at(-1).meta?.changes!==1)fail(400,'invalid_email_link');
   await env.DB.prepare('DELETE FROM community_email_tokens WHERE user_id=?').bind(row.user_id).run();
   try{await sendMail(env,row.email,securityMail(row.kind==='signup'?'welcome':'changed',env.APP_ORIGIN),'completed-'+tokenHash);}catch{console.warn('account_notification_delivery_failed');}
   return signedIn(env,row.user_id);
  }
  fail(404,'not_found');
 };
}
